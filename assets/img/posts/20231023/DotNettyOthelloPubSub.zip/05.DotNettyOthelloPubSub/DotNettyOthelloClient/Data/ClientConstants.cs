﻿namespace DotNettyOthelloClient.Data
{
    public class ClientConstants
    {

    }

    public enum E_UI
    {
        NONE = 0,
        LOBBY = 1,
        SINGLE_PLAY = 2,
        BATTLE_PLAY = 3,
        BATTLE_ROOM = 4,
        BATTLE_JOIN = 5,
    }
}
