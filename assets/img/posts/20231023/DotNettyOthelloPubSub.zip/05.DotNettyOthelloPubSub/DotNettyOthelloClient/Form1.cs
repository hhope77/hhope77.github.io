using DotNettyOthelloClient.Data;
using DotNettyOthelloClient.Handlers;
using DotNettyOthelloClient.Models;
using DotNettyOthelloLib.Helpers;
using Snowpipe;

namespace DotNettyOthelloClient
{
    public partial class frmClient : Form, IFormHandler
    {
        GameClient _gameClient = null;

        E_PLAY_TYPE _gamePlayType = E_PLAY_TYPE.NONE;
        E_STONE_TYPE[,] _stoneDatas = null;
        E_STONE_TYPE _myStoneType = E_STONE_TYPE.NONE;
        E_STONE_TYPE _pvpLastPlayStoneType = E_STONE_TYPE.NONE;
        long _battleId;


        public frmClient()
        {
            InitializeComponent();
            ConfigHelper.Load();
            _InitUI();
            _gameClient = new GameClient(this);
        }

        /// <summary>
        ///  UI �ʱ�ȭ
        /// </summary>
        private void _InitUI()
        {
            ShowHideGroupBox(E_UI.NONE);

            txtServerIP.Text = ConfigHelper.ServerIP;
            txtServerPort.Text = ConfigHelper.ServerPort.ToString();
        }

        public void ShowAlertMessage(string message)
        {
            MessageBox.Show(message);
        }

        private void Wait(int milliseconds)
        {
            var timer = new System.Windows.Forms.Timer();
            if (milliseconds == 0 || milliseconds < 0) return;

            timer.Interval = milliseconds;
            timer.Enabled = true;
            timer.Start();

            timer.Tick += (s, e) =>
            {
                timer.Enabled = false;
                timer.Stop();
            };

            while (timer.Enabled)
            {
                Application.DoEvents();
            }
        }

        public void NotifyMessage(string message)
        {
            if (lblNotify.InvokeRequired)
            {
                lblNotify.Invoke(new MethodInvoker(delegate
                {
                    lblNotify.Text = $" {message}";
                    Wait(2000);
                    lblNotify.Text = "";
                }));
            }
            else
            {
                lblNotify.Text = $" {message}";
                Wait(2000);
                lblNotify.Text = "";
            }

        }

        /// <summary>
        ///  �ܰ躰 �׷�ڽ� ����/�����
        /// </summary>
        public void ShowHideGroupBox(E_UI ui)
        {
            bool showGrpLobby = false;
            bool showGrpGameRoom = false;
            bool showGrpWaitingMode = false;
            bool showGrpPlay = false;

            bool enableBtnConect = false;
            bool enableBtnPlay = false;

            if (ui == E_UI.LOBBY)
            {
                showGrpLobby = true;
                enableBtnPlay = true;
            }
            else if (ui == E_UI.SINGLE_PLAY || ui == E_UI.BATTLE_JOIN)
            {
                showGrpPlay = true;
            }
            else if (ui == E_UI.BATTLE_PLAY)
            {
                showGrpGameRoom = true;
            }
            else if (ui == E_UI.BATTLE_ROOM)
            {
                showGrpWaitingMode = true;
            }
            else
            {
                enableBtnConect = true;
            }

            // groupbox
            if (grpLobby.InvokeRequired)
            {
                grpLobby.Invoke(new MethodInvoker(delegate
                {
                    grpLobby.Visible = showGrpLobby;
                }));
            }
            else
            {
                grpLobby.Visible = showGrpLobby;
            }

            if (grpGameRoom.InvokeRequired)
            {
                grpGameRoom.Invoke(new MethodInvoker(delegate
                {
                    grpGameRoom.Visible = showGrpGameRoom;
                }));
            }
            else
            {
                grpGameRoom.Visible = showGrpGameRoom;
            }

            if (grpWaitingMode.InvokeRequired)
            {
                grpWaitingMode.Invoke(new MethodInvoker(delegate
                {
                    grpWaitingMode.Visible = showGrpWaitingMode;
                }));
            }
            else
            {
                grpWaitingMode.Visible = showGrpWaitingMode;
            }

            if (grpPlay.InvokeRequired)
            {
                grpPlay.Invoke(new MethodInvoker(delegate
                {
                    grpPlay.Visible = showGrpPlay;
                }));
            }
            else
            {
                grpPlay.Visible = showGrpPlay;
            }

            // button
            if (btnConnect.InvokeRequired)
            {
                btnConnect.Invoke(new MethodInvoker(delegate
                {
                    btnConnect.Enabled = enableBtnConect;
                }));
            }
            else
            {
                btnConnect.Enabled = enableBtnConect;
            }

            if (btnDisConnect.InvokeRequired)
            {
                btnDisConnect.Invoke(new MethodInvoker(delegate
                {
                    btnDisConnect.Enabled = !enableBtnConect;
                }));
            }
            else
            {
                btnDisConnect.Enabled = !enableBtnConect;
            }

            if (btnPVE.InvokeRequired)
            {
                btnPVE.Invoke(new MethodInvoker(delegate
                {
                    btnPVE.Enabled = enableBtnPlay;
                }));
            }
            else
            {
                btnPVE.Enabled = enableBtnPlay;
            }

            if (btnPVP.InvokeRequired)
            {
                btnPVP.Invoke(new MethodInvoker(delegate
                {
                    btnPVP.Enabled = enableBtnPlay;
                }));
            }
            else
            {
                btnPVP.Enabled = enableBtnPlay;
            }
        }

        /// <summary>
        ///  ���� ����Ʈ
        /// </summary>
        public void InitWaitingList(List<UserInfo> waitingList)
        {
            if (lstWaiting.InvokeRequired)
            {
                lstWaiting.Invoke(new MethodInvoker(delegate
                {
                    lstWaiting.Items.Clear();
                }));
            }
            else
            {
                lstWaiting.Items.Clear();
            }

            if (waitingList.Count > 0)
            {
                foreach (var waitingUser in waitingList)
                {
                    AddWaitting(waitingUser);
                }
            }
        }

        /// <summary>
        ///  �ű� ���� �߰�
        /// </summary>
        public void AddWaitting(UserInfo waitingUser)
        {
            foreach (var item in lstWaiting.Items)
            {
                var data = item as ListBoxItem;
                if (data.Value == waitingUser.AccountId.ToString())
                {
                    return;
                }
            }

            if (lstWaiting.InvokeRequired)
            {
                lstWaiting.Invoke(new MethodInvoker(delegate
                {
                    lstWaiting.Items.Add(new ListBoxItem
                    {
                        Name = string.Format("{0} (Lv.{1})", waitingUser.NIckName, waitingUser.Level),
                        Value = waitingUser.AccountId.ToString()
                    });
                }));
            }
            else
            {
                lstWaiting.Items.Add(new ListBoxItem
                {
                    Name = string.Format("{0} (Lv.{1})", waitingUser.NIckName, waitingUser.Level),
                    Value = waitingUser.AccountId.ToString()
                });
            }
        }

        public void RemoveWaitting(long hostAccountId)
        {
            if (hostAccountId > 0)
            {
                foreach (var item in lstWaiting.Items)
                {
                    var data = item as ListBoxItem;
                    if (data.Value == hostAccountId.ToString())
                    {
                        if (lstWaiting.InvokeRequired)
                        {
                            lstWaiting.Invoke(new MethodInvoker(delegate
                            {
                                lstWaiting.Items.Remove(item);
                            }));
                        }
                        else
                        {
                            lstWaiting.Items.Remove(item);
                        }

                        break;
                    }
                }
            }
        }

        #region DataGridView - �����ǰ���
        private Color _GetStoneColor(E_STONE_TYPE stoneType)
        {
            if (stoneType == E_STONE_TYPE.BLACK)
            {
                return Color.Black;
            }
            else if (stoneType == E_STONE_TYPE.WHITE)
            {
                return Color.White;
            }

            return Color.FromArgb(244, 208, 12);
        }

        public void GenerateBoard(E_STONE_TYPE myStoneType, E_STONE_TYPE[,] stoneDatas)
        {
            if (dgvBoard.InvokeRequired)
            {
                dgvBoard.Invoke(new MethodInvoker(delegate
                {
                    dgvBoard.Rows.Clear();
                    dgvBoard.Columns.Clear();
                }));
            }
            else
            {
                dgvBoard.Rows.Clear();
                dgvBoard.Columns.Clear();
            }

            if (stoneDatas == null)
            {
                MessageBox.Show("[GenerateBoard] stoneDatas is NLLL");
                btnExitPlay.PerformClick();
                return;
            }

            int boardScale = stoneDatas.GetLength(0);
            int boardCellSize = 35; // ��ĭ ũ��
            if (dgvBoard.InvokeRequired)
            {
                dgvBoard.Invoke(new MethodInvoker(delegate
                {
                    dgvBoard.ColumnCount = boardScale;
                }));
            }
            else
            {
                dgvBoard.ColumnCount = boardScale;
            }

            string[] rowVal = { "" };
            for (int n = 0; n < boardScale; n++)
            {
                if (dgvBoard.InvokeRequired)
                {
                    dgvBoard.Invoke(new MethodInvoker(delegate
                    {
                        dgvBoard.Rows.Add(rowVal);
                        dgvBoard.Columns[n].Width = boardCellSize;
                        dgvBoard.Rows[n].Height = boardCellSize;
                    }));
                }
                else
                {
                    dgvBoard.Rows.Add(rowVal);
                    dgvBoard.Columns[n].Width = boardCellSize;
                    dgvBoard.Rows[n].Height = boardCellSize;
                }
            }

            dgvBoard.Width = boardCellSize * boardScale;
            dgvBoard.Height = boardCellSize * boardScale;

            _myStoneType = myStoneType;
            _stoneDatas = stoneDatas;

            for (int r = 0; r < stoneDatas.GetLength(0); r++)
            {
                for (int c = 0; c < stoneDatas.GetLength(1); c++)
                {
                    dgvBoard.Rows[r].Cells[c].Style.BackColor = _GetStoneColor(stoneDatas[r, c]);
                }
            }

            dgvBoard.ClearSelection();
        }

        private async void _ResetBoard()
        {
            await _gameClient.ResetSignPlayAsync();
        }

        public void DrawBoard(E_PLAY_TYPE playType, List<TurnInfo> turnInfoList)
        {
            int blackStoneCnt = 0, whiteStoneCnt = 0;
            foreach (var trunInfo in turnInfoList)
            {
                if (trunInfo.TurnResult == E_TURN_RESULT.PASS)
                {
                    MessageBox.Show($"[{trunInfo.StoneType}] PASS");
                    continue;
                }

                // �ش��Ͽ� ������ ���� ����
                for (int r = 0; r < trunInfo.TurnDatas.GetLength(0); r++)
                {
                    for (int c = 0; c < trunInfo.TurnDatas.GetLength(1); c++)
                    {
                        if (trunInfo.TurnDatas[r, c] == E_STONE_TYPE.NONE)
                        {
                            continue;
                        }
                        else if (trunInfo.TurnDatas[r, c] == E_STONE_TYPE.BLACK)
                        {
                            blackStoneCnt++;
                        }
                        else if (trunInfo.TurnDatas[r, c] == E_STONE_TYPE.WHITE)
                        {
                            whiteStoneCnt++;
                        }

                        dgvBoard.Rows[r].Cells[c].Style.BackColor = _GetStoneColor(trunInfo.TurnDatas[r, c]);
                    }
                }

                // ���ӿ��� üũ�� ���� �����ѵ� �޼���â ������ ���� ������ڿ� ��
                if (trunInfo.TurnResult == E_TURN_RESULT.GAME_OVER)
                {
                    string result = "GAME OVER - ";
                    if (blackStoneCnt == whiteStoneCnt)
                    {
                        result += "���º�";
                    }
                    else
                    {
                        if (blackStoneCnt > whiteStoneCnt && _myStoneType == E_STONE_TYPE.BLACK
                            || blackStoneCnt < whiteStoneCnt && _myStoneType == E_STONE_TYPE.WHITE)
                        {
                            result += "WIN";
                        }
                        else
                        {
                            result += "LOSE";
                        }
                    }
                    result += $"\nblack[{blackStoneCnt}], white[{whiteStoneCnt}], _myStone[{_myStoneType}]";

                    MessageBox.Show(result);
                    if (playType == E_PLAY_TYPE.SINGLE)
                    {
                        if (MessageBox.Show("�ٽ� �Ͻðڽ��ϱ�?", "�絵��", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            _ResetBoard();
                        }
                        else
                        {
                            if (btnExitPlay.InvokeRequired)
                            {
                                btnExitPlay.Invoke(new MethodInvoker(delegate
                                {
                                    btnExitPlay.PerformClick();
                                }));
                            }
                            else
                            {
                                btnExitPlay.PerformClick();
                            }
                        }
                    }
                    else
                    {
                        if (btnExitPlay.InvokeRequired)
                        {
                            btnExitPlay.Invoke(new MethodInvoker(delegate
                            {
                                btnExitPlay.PerformClick();
                            }));
                        }
                        else
                        {
                            btnExitPlay.PerformClick();
                        }
                    }

                    break;
                }

                if (turnInfoList.Count > 1)
                {
                    Wait(1000);
                }
            }
        }

        public void RollBackStone(PlayInfo playInfo)
        {
            MessageBox.Show("�����Ҽ����� ��ġ�Դϴ�.");
            dgvBoard.Rows[playInfo.IndexX].Cells[playInfo.IndexY].Style.BackColor = _GetStoneColor(E_STONE_TYPE.NONE);
        }

        public void SetBattleId(long battleId)
        {
            _battleId = battleId;
        }

        public void SetLastPlayStone(E_STONE_TYPE stoneType)
        {
            this._pvpLastPlayStoneType = stoneType;
        }

        private void dgvBoard_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (_stoneDatas == null)
            {
                MessageBox.Show("[!] Stone Data Error");
                return;
            }

            if (_stoneDatas[e.RowIndex, e.ColumnIndex] != E_STONE_TYPE.NONE)
            {
                MessageBox.Show("������ ���� ���Դϴ�\n �ٸ����� �������ּ���");
                return;
            }

            if (_gamePlayType == E_PLAY_TYPE.BATTLE && _pvpLastPlayStoneType == _myStoneType)
            {
                MessageBox.Show("��밡 ���� �����Դϴ�");
                return;
            }

            dgvBoard.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = _GetStoneColor(_myStoneType);
        }

        private async void dgvBoard_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            //WriteFormLog($"�������� - _myStoneType : {_myStoneType}, RowIndex :{e.RowIndex}, ColumnIndex :{e.ColumnIndex}");
            if (_gamePlayType == E_PLAY_TYPE.SINGLE)
            {
                await _gameClient.PutSignPlayStoneAsync(_myStoneType, e.RowIndex, e.ColumnIndex);
            }
            else if (_gamePlayType == E_PLAY_TYPE.BATTLE)
            {
                await _gameClient.PutBattlePlayStoneAsync(_battleId, _myStoneType, e.RowIndex, e.ColumnIndex);
            }
            else
            {
                WriteFormLog("�÷��� ����!");
            }
            dgvBoard.ClearSelection();
        }
        #endregion

        /// <summary>
        ///  �α׾���
        /// </summary>
        public void WriteFormLog(string logMessage)
        {
            if (txtLog.InvokeRequired)
            {
                txtLog.Invoke(new MethodInvoker(delegate
                {
                    txtLog.Text += logMessage + Environment.NewLine + Environment.NewLine;
                }));
            }
            else
            {
                txtLog.Text += logMessage + Environment.NewLine + Environment.NewLine;
            }
        }

        /// <summary>
        ///  �α������
        /// </summary>
        private void btnLogClear_Click(object sender, EventArgs e)
        {
            txtLog.Clear();
        }

        /// <summary>
        ///  �г��Ӱ� �б�
        /// </summary>
        public string ReadUserNickname()
        {
            return txtUserNickName.Text;
        }

        /// <summary>
        ///  ��������
        /// </summary>
        private async void btnConnect_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtServerIP.Text)
                || string.IsNullOrEmpty(txtServerPort.Text)
                || Int32.TryParse(txtServerPort.Text, out int targetServerPort) == false)
            {
                MessageBox.Show("�ùٸ� ���������� �Է����ּ���");
                return;
            }

            string userNickName = txtUserNickName.Text;
            if (string.IsNullOrEmpty(userNickName))
            {
                MessageBox.Show("���� �г����� �Է����ּ���");
                return;
            }

            await _gameClient.RunAsync();
        }

        /// <summary>
        ///  ������������
        /// </summary>
        private async void btnDisConnect_Click(object sender, EventArgs e)
        {
            await _gameClient.StopAsync();
        }

        /// <summary>
        ///  �̱��÷��� ����
        /// </summary>
        private async void btnPVE_Click(object sender, EventArgs e)
        {
            _gamePlayType = E_PLAY_TYPE.SINGLE;
            await _gameClient.EnterSinglePlayAsync();
        }

        /// <summary>
        ///  �÷��� ����
        /// </summary>
        private async void btnExitPlay_Click(object sender, EventArgs e)
        {
            if (_gamePlayType == E_PLAY_TYPE.SINGLE)
            {
                await _gameClient.ExitSignPlayAsync();
                _gamePlayType = E_PLAY_TYPE.NONE;
            }
            else if (_gamePlayType == E_PLAY_TYPE.BATTLE)
            {
                await _gameClient.ExitBattleJoinAsync(_battleId);
                _battleId = 0;
            }
        }

        /// <summary>
        ///  ���� ����
        /// </summary>
        private async void btnPVP_Click(object sender, EventArgs e)
        {
            _gamePlayType = E_PLAY_TYPE.BATTLE;
            _battleId = 0;
            await _gameClient.EnterBattlePlayAsync();
        }

        /// <summary>
        ///  ���� ����
        /// </summary>
        private void btnExitWaiting_Click(object sender, EventArgs e)
        {
            lstWaiting.Items.Clear();
            _gamePlayType = E_PLAY_TYPE.NONE;
            _battleId = 0;
            ShowHideGroupBox(E_UI.LOBBY);
        }

        /// <summary>
        /// ���� �����
        /// </summary>
        private async void btnCreateRoom_Click(object sender, EventArgs e)
        {
            await _gameClient.CreateBattleRoomAsync();
        }

        /// <summary>
        ///  ���� �������
        /// </summary>
        private async void btnCancelWaiting_Click(object sender, EventArgs e)
        {
            await _gameClient.ExitBattleRoomAsync();
        }

        /// <summary>
        ///  ���� ����
        /// </summary>
        private async void lstWaiting_Click(object sender, EventArgs e)
        {
            ListBox lb = sender as ListBox;
            if (lb != null)
            {
                ListBoxItem item = lb.SelectedItem as ListBoxItem;
                if (item != null)
                {
                    if (MessageBox.Show($"{item.Name} �� �÷��� �Ͻðڽ��ϱ�?", "���� ����", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        if (Int64.TryParse(item.Value, out long hostAccountId) != false)
                        {
                            await _gameClient.JoinBattleRoomAsync(hostAccountId);
                        }
                    }
                }
            }
        }
    }
}