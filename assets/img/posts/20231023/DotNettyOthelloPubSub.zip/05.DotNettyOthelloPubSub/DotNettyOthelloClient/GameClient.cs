﻿using DotNetty.Handlers.Tls;
using DotNetty.Transport.Bootstrapping;
using DotNetty.Transport.Channels;
using DotNetty.Transport.Channels.Sockets;
using DotNettyOthelloClient.Data;
using DotNettyOthelloClient.Handlers;
using DotNettyOthelloLib.Helpers;
using DotNettyOthelloLib.Log.FileLog;
using Newtonsoft.Json;
using Snowpipe;
using System.Net.Security;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using static Snowpipe.EnterSinglePlay;

namespace DotNettyOthelloClient
{
    public class GameClient
    {
        private IFormHandler _formHandler;
        private IChannel _bootstrapChannel;

        private string _sessionToken = null;
        private long _accountId = 0;

        public GameClient(IFormHandler formHandler)
        {
            _formHandler = formHandler;
        }

        public async Task RunAsync()
        {
            IEventLoopGroup group = new MultithreadEventLoopGroup();

            IDispatcherHandler.ClientDispatch clientDispatcher = gamePacket => _ClientDispatch(gamePacket);
            var packetEncoder = new PacketEncoder();
            var packetDecoder = new PacketDecoder();
            var _clientHandler = new ClientPacketHandler(clientDispatcher);

            X509Certificate2 cert = null;
            string targetHost = null;
            if (ConfigHelper.IsSSL)
            {
                cert = new X509Certificate2(Path.Combine(ConfigHelper.ProcessDirectory, "snowpipe.com.pfx"), "password");
                targetHost = cert.GetNameInfo(X509NameType.DnsName, false);
            }

            try
            {
                Bootstrap bootstrap = new Bootstrap();
                bootstrap
                .Group(group)
                    .Channel<TcpSocketChannel>()
                    .Option(ChannelOption.TcpNodelay, true)    // Do not buffer and send packages right away
                    .Handler(new ActionChannelInitializer<ISocketChannel>(channel =>
                    {
                        IChannelPipeline pipeline = channel.Pipeline;

                        if (cert != null)
                        {
                            pipeline.AddLast("tls", new TlsHandler(stream => new SslStream(stream, true, (sender, certificate, chain, errors) => true), new ClientTlsSettings(targetHost)));
                        }

                        pipeline.AddLast("encoder", packetEncoder);
                        pipeline.AddLast("decoder", packetDecoder);
                        pipeline.AddLast("handler", _clientHandler);
                    }));

                _bootstrapChannel = await bootstrap.ConnectAsync(
                    ConfigHelper.ServerIPAddress
                    , ConfigHelper.ServerPort
                    );

                // login game server
                await _UserLoginAsync();

                //Console.ReadLine();
                //await _bootstrapChannel.CloseAsync();
            }
            catch (Exception ex)
            {
                string exMessage = $"{ex.Message}\n{ex.StackTrace}";
                _formHandler.WriteFormLog(exMessage);
                FLogManager.Get().ServiceLog.AppendErrorLog(exMessage);
            }
            //finally
            //{
            //    group.ShutdownGracefullyAsync().Wait(1000); // 1초 대기후 종료
            //}
        }

        /// <summary>
        ///  연결종료
        /// </summary>
        public async Task StopAsync()
        {
            await _bootstrapChannel.CloseAsync();
            _formHandler.ShowHideGroupBox(E_UI.NONE);
        }

        /// <summary>
        ///  서버에서 메세지가 Publish 된 경우
        /// </summary>
        private void _ClientDispatch(GamePacket resGamePacket)
        {
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resGamePacket));

            string methodName = "_" + resGamePacket.PacketType.ToCamelCase();
            MethodInfo dynMethod = this.GetType().GetMethod(methodName, BindingFlags.NonPublic | BindingFlags.Instance);
            if (dynMethod != null)
            {
                dynMethod.Invoke(this, new object[] { resGamePacket.PacketBody });
            }
            else
            {
                _formHandler.WriteFormLog($"Not Found Method - {methodName}");
            }
        }

        #region 서버 로그인
        /// <summary>
        ///  소켓서버 로그인요청
        /// </summary>
        private async Task _UserLoginAsync()
        {
            try
            {
                ReqUserLogin reqUserLogin = new ReqUserLogin
                {
                    NickName = _formHandler.ReadUserNickname()
                };

                GamePacket gamePacket = new GamePacket
                {
                    PacketType = E_PACKET_TYPE.REQ_USER_LOGIN,
                    PacketBody = EncUtil.EncodeBase64(reqUserLogin)
                };

                await _bootstrapChannel.WriteAndFlushAsync(gamePacket);
            }
            catch (Exception ex)
            {
                string exMessage = $"{ex.Message}\n{ex.StackTrace}";
                _formHandler.WriteFormLog(exMessage);
                FLogManager.Get().ServiceLog.AppendErrorLog(exMessage);
            }
        }

        /// <summary>
        ///  소켓서버 로그인응답
        /// </summary>
        private void _ResUserLogin(string packetBody)
        {
            var resUserLogin = EncUtil.DecodeBase64<ResUserLogin>(packetBody);
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resUserLogin));

            _formHandler.ShowHideGroupBox(E_UI.LOBBY);
            _sessionToken = resUserLogin.Token;
            _accountId = resUserLogin.AccountId;
        }

        /// <summary>
        ///  유저 로그인 알림
        /// </summary>
        private async void _PsUserLogin(string packetBody)
        {
            ResUserLogin resUserLogin = EncUtil.DecodeBase64<ResUserLogin>(packetBody);
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resUserLogin));

            if (resUserLogin.ResponseCode == E_RESPONSE_CODE.SUCCESS)
            {
                _formHandler.NotifyMessage($"{resUserLogin.NickName}님이 로그인하셨습니다");

            }
            else if (resUserLogin.ResponseCode == E_RESPONSE_CODE.DEUPLCATE_LOGIN)
            {
                _formHandler.ShowAlertMessage("중복로그인 되었습니다");
                await StopAsync();
            }
        }
        #endregion

        #region 싱글플레이
        /// <summary>
        ///  싱글플레이 입장요청
        /// </summary>
        public async Task EnterSinglePlayAsync()
        {
            try
            {
                ReqEnterSinglePlay reqEnterSinglePlay = new ReqEnterSinglePlay
                {
                    Token = _sessionToken
                };

                GamePacket gamePacket = new GamePacket
                {
                    PacketType = E_PACKET_TYPE.REQ_ENTER_SINGLE_PLAY,
                    PacketBody = EncUtil.EncodeBase64(reqEnterSinglePlay)
                };

                await _bootstrapChannel.WriteAndFlushAsync(gamePacket);
            }
            catch (Exception ex)
            {
                string exMessage = $"{ex.Message}\n{ex.StackTrace}";
                _formHandler.WriteFormLog(exMessage);
                FLogManager.Get().ServiceLog.AppendErrorLog(exMessage);
            }
        }

        /// <summary>
        ///  싱글플레이 입장 응답
        /// </summary>
        /// <param name="packetBody"></param>
        private void _ResEnterSinglePlay(string packetBody)
        {
            var resEnterSinglePlay = EncUtil.DecodeBase64<ResEnterSinglePlay>(packetBody);
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resEnterSinglePlay));

            _formHandler.ShowHideGroupBox(E_UI.SINGLE_PLAY);
            _formHandler.GenerateBoard(resEnterSinglePlay.MyStoneType, resEnterSinglePlay.StoneDatas);
        }

        /// <summary>
        ///  싱글플레이 퇴장요청
        /// </summary>
        public async Task ExitSignPlayAsync()
        {
            try
            {
                ReqExitSinglePlay reqExitSinglePlay = new ReqExitSinglePlay
                {
                    Token = _sessionToken
                };

                GamePacket gamePacket = new GamePacket
                {
                    PacketType = E_PACKET_TYPE.REQ_EXIT_SINGLE_PLAY,
                    PacketBody = EncUtil.EncodeBase64(reqExitSinglePlay)
                };

                await _bootstrapChannel.WriteAndFlushAsync(gamePacket);
            }
            catch (Exception ex)
            {
                string exMessage = $"{ex.Message}\n{ex.StackTrace}";
                _formHandler.WriteFormLog(exMessage);
                FLogManager.Get().ServiceLog.AppendErrorLog(exMessage);
            }
        }

        /// <summary>
        ///  싱글플레이 퇴장응답
        /// </summary>
        private void _ResExitSinglePlay(string packetBody)
        {
            var resExitSinglePlay = EncUtil.DecodeBase64<ResExitSinglePlay>(packetBody);
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resExitSinglePlay));

            _formHandler.ShowHideGroupBox(E_UI.LOBBY);
        }

        /// <summary>
        ///  싱글플레이 착수요청
        /// </summary>
        public async Task PutSignPlayStoneAsync(E_STONE_TYPE stoneType, int x, int y)
        {
            try
            {
                ReqPutSinglePlayStone reqPutSinglePlayStone = new ReqPutSinglePlayStone
                {
                    Token = _sessionToken,
                    MyPlayInfo = new PlayInfo(stoneType, x, y)
                };

                GamePacket gamePacket = new GamePacket
                {
                    PacketType = E_PACKET_TYPE.REQ_PUT_SINGLE_PLAY_STONE,
                    PacketBody = EncUtil.EncodeBase64(reqPutSinglePlayStone)
                };

                await _bootstrapChannel.WriteAndFlushAsync(gamePacket);
            }
            catch (Exception ex)
            {
                string exMessage = $"{ex.Message}\n{ex.StackTrace}";
                _formHandler.WriteFormLog(exMessage);
                FLogManager.Get().ServiceLog.AppendErrorLog(exMessage);
            }
        }

        /// <summary>
        ///  싱글플레이 착수응답
        /// </summary>
        private void _ResPutSinglePlayStone(string packetBody)
        {
            var resPutSinglePlayStone = EncUtil.DecodeBase64<ResPutSinglePlayStone>(packetBody);
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resPutSinglePlayStone));

            if (resPutSinglePlayStone.ResponseCode == E_RESPONSE_CODE.SUCCESS)
            {
                _formHandler.DrawBoard(E_PLAY_TYPE.SINGLE, resPutSinglePlayStone.TurnInfoList);
            }
            else
            {
                _formHandler.RollBackStone(resPutSinglePlayStone.MyPlayInfo);
            }
        }

        /// <summary>
        ///  싱글플레이 리셋(재도전) 요청
        /// </summary>
        public async Task ResetSignPlayAsync()
        {
            try
            {
                ReqResetSinglePlay reqResetSinglePlay = new ReqResetSinglePlay
                {
                    Token = _sessionToken
                };

                GamePacket gamePacket = new GamePacket
                {
                    PacketType = E_PACKET_TYPE.REQ_RESET_SINGLE_PLAY,
                    PacketBody = EncUtil.EncodeBase64(reqResetSinglePlay)
                };

                await _bootstrapChannel.WriteAndFlushAsync(gamePacket);
            }
            catch (Exception ex)
            {
                string exMessage = $"{ex.Message}\n{ex.StackTrace}";
                _formHandler.WriteFormLog(exMessage);
                FLogManager.Get().ServiceLog.AppendErrorLog(exMessage);
            }
        }

        /// <summary>
        ///  싱글플레이 리셋(재도전) 응답
        /// </summary>
        private void _ResResetSinglePlay(string packetBody)
        {
            var resResetSinglePlay = EncUtil.DecodeBase64<ResResetSinglePlay>(packetBody);
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resResetSinglePlay));

            _formHandler.GenerateBoard(resResetSinglePlay.MyStoneType, resResetSinglePlay.StoneDatas);
        }
        #endregion

        #region 대전플레이
        /// <summary>
        ///  대전플레이 입장
        /// </summary>
        public async Task EnterBattlePlayAsync()
        {
            try
            {
                ReqEnterBattlePlay reqEnterBattlePlay = new ReqEnterBattlePlay
                {
                    Token = _sessionToken
                };

                GamePacket gamePacket = new GamePacket
                {
                    PacketType = E_PACKET_TYPE.REQ_ENTER_BATTLE_PLAY,
                    PacketBody = EncUtil.EncodeBase64(reqEnterBattlePlay)
                };

                await _bootstrapChannel.WriteAndFlushAsync(gamePacket);
            }
            catch (Exception ex)
            {
                string exMessage = $"{ex.Message}\n{ex.StackTrace}";
                _formHandler.WriteFormLog(exMessage);
                FLogManager.Get().ServiceLog.AppendErrorLog(exMessage);
            }
        }

        private void _ResEnterBattlePlay(string packetBody)
        {
            var resEnterBattlePlay = EncUtil.DecodeBase64<ResEnterBattlePlay>(packetBody);
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resEnterBattlePlay));

            _formHandler.ShowHideGroupBox(E_UI.BATTLE_PLAY);
            _formHandler.InitWaitingList(resEnterBattlePlay.WaitingList);
        }

        /// <summary>
        ///  대기방 만들기 요청
        /// </summary>
        public async Task CreateBattleRoomAsync()
        {
            try
            {
                ReqCreateBattleRoom reqCreateBattleRoom = new ReqCreateBattleRoom
                {
                    Token = _sessionToken
                };

                GamePacket gamePacket = new GamePacket
                {
                    PacketType = E_PACKET_TYPE.REQ_CREATE_BATTLE_ROOM,
                    PacketBody = EncUtil.EncodeBase64(reqCreateBattleRoom)
                };

                await _bootstrapChannel.WriteAndFlushAsync(gamePacket);
            }
            catch (Exception ex)
            {
                string exMessage = $"{ex.Message}\n{ex.StackTrace}";
                _formHandler.WriteFormLog(exMessage);
                FLogManager.Get().ServiceLog.AppendErrorLog(exMessage);
            }
        }

        private void _ResCreateBattleRoom(string packetBody)
        {
            var resCreateBattleRoom = EncUtil.DecodeBase64<ResCreateBattleRoom>(packetBody);
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resCreateBattleRoom));

            _formHandler.ShowHideGroupBox(E_UI.BATTLE_ROOM);
        }

        /// <summary>
        ///  대기방 생성 알림
        /// </summary>
        private void _PsCreateBattleRoom(string packetBody)
        {
            ResCreateBattleRoom resCreateBattleRoom = EncUtil.DecodeBase64<ResCreateBattleRoom>(packetBody);
            _formHandler.AddWaitting(resCreateBattleRoom.WaitingUser);
        }

        /// <summary>
        ///  대기취소
        /// </summary>
        public async Task ExitBattleRoomAsync()
        {
            try
            {
                ReqExitBattleRoom reqExitBattleRoom = new ReqExitBattleRoom
                {
                    Token = _sessionToken
                };

                GamePacket gamePacket = new GamePacket
                {
                    PacketType = E_PACKET_TYPE.REQ_EXIT_BATTLE_ROOM,
                    PacketBody = EncUtil.EncodeBase64(reqExitBattleRoom)
                };

                await _bootstrapChannel.WriteAndFlushAsync(gamePacket);
            }
            catch (Exception ex)
            {
                string exMessage = $"{ex.Message}\n{ex.StackTrace}";
                _formHandler.WriteFormLog(exMessage);
                FLogManager.Get().ServiceLog.AppendErrorLog(exMessage);
            }
        }

        private void _ResExitBattleRoom(string packetBody)
        {
            var resExitBattleRoom = EncUtil.DecodeBase64<ResExitBattleRoom>(packetBody);
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resExitBattleRoom));

            _formHandler.ShowHideGroupBox(E_UI.BATTLE_PLAY);
        }

        /// <summary>
        ///  대기취소 알림
        /// </summary>
        private void _PsExitBattleRoom(string packetBody)
        {
            ResExitBattleRoom resExitBattleRoom = EncUtil.DecodeBase64<ResExitBattleRoom>(packetBody);
            _formHandler.RemoveWaitting(resExitBattleRoom.WaitingUser.AccountId);
        }

        /// <summary>
        ///  대전시작 요청
        /// </summary>
        public async Task JoinBattleRoomAsync(long hostAccountId)
        {
            try
            {
                ReqJoinBattleRoom reqJoinBattleRoom = new ReqJoinBattleRoom
                {
                    Token = _sessionToken,
                    HostAccountId = hostAccountId,
                    OpponentAccountId = _accountId
                };

                GamePacket gamePacket = new GamePacket
                {
                    PacketType = E_PACKET_TYPE.REQ_JOIN_BATTLE_ROOM,
                    PacketBody = EncUtil.EncodeBase64(reqJoinBattleRoom)
                };

                await _bootstrapChannel.WriteAndFlushAsync(gamePacket);
            }
            catch (Exception ex)
            {
                string exMessage = $"{ex.Message}\n{ex.StackTrace}";
                _formHandler.WriteFormLog(exMessage);
                FLogManager.Get().ServiceLog.AppendErrorLog(exMessage);
            }
        }

        private void _ResJoinBattleRoom(string packetBody)
        {
            var resJoinBattleRoom = EncUtil.DecodeBase64<ResJoinBattleRoom>(packetBody);
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resJoinBattleRoom));

            if (resJoinBattleRoom.ResponseCode != E_RESPONSE_CODE.SUCCESS)
            {
                _formHandler.ShowAlertMessage(resJoinBattleRoom.ResponseCode.ToString());
            }
            else
            {
                _formHandler.ShowHideGroupBox(E_UI.BATTLE_JOIN);
                if (resJoinBattleRoom != null)
                {
                    long hostAccountId = resJoinBattleRoom.BattleInfo.BattleEntryList
                        .FirstOrDefault(x => x.IsHost == true).AccountId;

                    // 대기방삭제
                    _formHandler.RemoveWaitting(hostAccountId);

                    // 대전 플레이 초기화
                    E_STONE_TYPE myStoneType = resJoinBattleRoom.BattleInfo.BattleEntryList
                        .FirstOrDefault(x => x.AccountId == _accountId)
                        .StoneType;
                    _formHandler.GenerateBoard(myStoneType, resJoinBattleRoom.BattleInfo.StoneDatas);
                    _formHandler.SetLastPlayStone(resJoinBattleRoom.BattleInfo.LastPlayStoneType);
                    _formHandler.SetBattleId(resJoinBattleRoom.BattleInfo.BattleId);
                }
            }
        }

        /// <summary>
        ///  대전시작 알림
        /// </summary>
        private void _PsJoinBattleRoom(string packetBody)
        {
            ResJoinBattleRoom resJoinBattleRoom = EncUtil.DecodeBase64<ResJoinBattleRoom>(packetBody);
            if (resJoinBattleRoom != null)
            {
                long hostAccountId = resJoinBattleRoom.BattleInfo.BattleEntryList
                    .FirstOrDefault(d => d.IsHost == true).AccountId;
                long opponentAccountId = resJoinBattleRoom.BattleInfo.BattleEntryList
                    .FirstOrDefault(d => d.IsHost == false).AccountId;

                // 대기방삭제
                _formHandler.RemoveWaitting(hostAccountId);

                if (_accountId == hostAccountId || _accountId == opponentAccountId)
                {
                    // 대전 플레이 초기화
                    E_STONE_TYPE myStoneType = resJoinBattleRoom.BattleInfo.BattleEntryList
                        .FirstOrDefault(x => x.AccountId == _accountId).StoneType;
                    _formHandler.GenerateBoard(myStoneType, resJoinBattleRoom.BattleInfo.StoneDatas);
                    _formHandler.SetBattleId(resJoinBattleRoom.BattleInfo.BattleId);
                    _formHandler.SetLastPlayStone(resJoinBattleRoom.BattleInfo.LastPlayStoneType);

                    _formHandler.ShowHideGroupBox(E_UI.BATTLE_JOIN);
                }
            }
        }

        /// <summary>
        ///  대전 플레이 중지 요청
        /// </summary>
        public async Task ExitBattleJoinAsync(long battleId)
        {
            try
            {
                ReqExitBattleJoin reqExitBattleJoin = new ReqExitBattleJoin
                {
                    Token = _sessionToken,
                    BattleId = battleId
                };

                GamePacket gamePacket = new GamePacket
                {
                    PacketType = E_PACKET_TYPE.REQ_EXIT_BATTLE_JOIN,
                    PacketBody = EncUtil.EncodeBase64(reqExitBattleJoin)
                };

                await _bootstrapChannel.WriteAndFlushAsync(gamePacket);
            }
            catch (Exception ex)
            {
                string exMessage = $"{ex.Message}\n{ex.StackTrace}";
                _formHandler.WriteFormLog(exMessage);
                FLogManager.Get().ServiceLog.AppendErrorLog(exMessage);
            }
        }

        private void _ResExitBattleJoin(string packetBody)
        {
            var resExitBattleJoin = EncUtil.DecodeBase64<ResExitBattleJoin>(packetBody);
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resExitBattleJoin));

            _formHandler.ShowHideGroupBox(E_UI.BATTLE_PLAY);
        }

        /// <summary>
        ///  대전 플레이 중지 알림
        /// </summary>
        private void _PsExitBattleJoin(string packetBody)
        {
            ResExitBattleJoin resExitBattleJoin = EncUtil.DecodeBase64<ResExitBattleJoin>(packetBody);
            _formHandler.ShowHideGroupBox(E_UI.BATTLE_PLAY);
            if (resExitBattleJoin != null)
            {
                _formHandler.SetLastPlayStone(E_STONE_TYPE.NONE);
                _formHandler.SetBattleId(0);
            }
        }

        /// <summary>
        ///  대전 착수 요청
        /// </summary>
        public async Task PutBattlePlayStoneAsync(long battleId, E_STONE_TYPE stoneType, int x, int y)
        {
            try
            {
                ReqPutBattlePlayStone reqPutBattlePlayStone = new ReqPutBattlePlayStone
                {
                    Token = _sessionToken,
                    BattleId = battleId,
                    TurnPlayInfo = new PlayInfo(stoneType, x, y)
                };

                GamePacket gamePacket = new GamePacket
                {
                    PacketType = E_PACKET_TYPE.REQ_PUT_BATTLE_PLAY_STONE,
                    PacketBody = EncUtil.EncodeBase64(reqPutBattlePlayStone)
                };

                await _bootstrapChannel.WriteAndFlushAsync(gamePacket);
            }
            catch (Exception ex)
            {
                string exMessage = $"{ex.Message}\n{ex.StackTrace}";
                _formHandler.WriteFormLog(exMessage);
                FLogManager.Get().ServiceLog.AppendErrorLog(exMessage);
            }
        }

        private void _ResPutBattlePlayStone(string packetBody)
        {
            var resPutBattlePlayStone = EncUtil.DecodeBase64<ResPutBattlePlayStone>(packetBody);
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resPutBattlePlayStone));

            if (resPutBattlePlayStone.ResponseCode == E_RESPONSE_CODE.SUCCESS)
            {
                _formHandler.DrawBoard(E_PLAY_TYPE.BATTLE, resPutBattlePlayStone.TurnInfoList);
                _formHandler.SetLastPlayStone(resPutBattlePlayStone.LastPlayStoneType);
            }
            else
            {
                _formHandler.RollBackStone(resPutBattlePlayStone.TurnPlayInfo);
            }
        }

        /// <summary>
        ///  대전 착수 알림
        /// </summary>
        private void _PsPutBattlePlayStone(string packetBody)
        {
            ResPutBattlePlayStone resPutBattlePlayStone = EncUtil.DecodeBase64<ResPutBattlePlayStone>(packetBody);
            if (resPutBattlePlayStone != null)
            {
                _formHandler.DrawBoard(E_PLAY_TYPE.BATTLE, resPutBattlePlayStone.TurnInfoList);
                _formHandler.SetLastPlayStone(resPutBattlePlayStone.LastPlayStoneType);
            }
        }
        #endregion
    }
}
