﻿using DotNetty.Transport.Channels;
using DotNetty.Transport.Channels.Groups;
using DotNettyOthelloLib.Extensions;
using Snowpipe;

namespace DotNettyOthelloLib.Channel;

public static class ChannelManager
{
    private static volatile IChannelGroup _allChannelGroup; // For all connections
    private static volatile Dictionary<long/* AccountId */, IChannel> _userChannelDic = new Dictionary<long, IChannel>();
    private static volatile Dictionary<int/* ServerId */, IChannelGroup> _serverChannelGroupDic = new Dictionary<int, IChannelGroup>();

    private static volatile object _allChannelGroupLocker = new object();
    private static volatile Dictionary<int, object> _serverChannelGroupLockerDic = new Dictionary<int, object> { };

    private static Queue<IChannel> _duplcatedChannel = new Queue<IChannel>();

    static ChannelManager()
    {

    }

    /// <summary>
    ///  로그용 - 접속된 유저채널수
    /// </summary>
    public static int GetUserChannelCount()
    {
        return _userChannelDic.Count;
    }

    /// <summary>
    ///  로그용 - 같은서버내 접속된 채널수
    /// </summary>
    public static int GetServerChannelCount(int serverId)
    {
        int cnt = 0;
        if (_serverChannelGroupDic.TryGetValue(serverId, out var channelGroup))
        {
            cnt = channelGroup.Count;
        }
        return cnt;
    }

    /// <summary>
    ///  로그용 - 전체채널그룹내 채널수
    /// </summary>
    public static int GetAllChannelCount()
    {
        return _allChannelGroup.Count;
    }

    /// <summary>
    ///  유저채널 추가
    /// </summary>
    public static void AddUserChannel(IChannelHandlerContext context, long accountId)
    {
        // add in _userChannelDic
        if (!_userChannelDic.ContainsKey(accountId))
        {
            _userChannelDic.Add(accountId, context.Channel);
        }
        else
        {
            if (_userChannelDic[accountId].Id != context.Channel.Id)
            {
                var oldChannel = _userChannelDic[accountId];
                _duplcatedChannel.Enqueue(oldChannel);
                RemoveServerChannel(oldChannel, oldChannel.GetAttrServerId());
            }
            _userChannelDic[accountId] = context.Channel;
        }

        // add in _allChannelGroup
        IChannelGroup g = _allChannelGroup;
        if (_allChannelGroup == null)
        {
            lock (_allChannelGroupLocker)
            {
                if (_allChannelGroup == null)
                {
                    g = _allChannelGroup = new DefaultChannelGroup(context.Executor);
                }
            }
        }
        _allChannelGroup.Add(context.Channel);
    }

    /// <summary>
    ///  서버그룹에 채널추가
    /// </summary>
    public static void AddServerChannel(IChannelHandlerContext context, int serverId)
    {
        if (!_serverChannelGroupDic.ContainsKey(serverId))
        {
            if (_serverChannelGroupLockerDic.TryGetValue(serverId, out var serverLocker) == false)
            {
                serverLocker = new object();
                _serverChannelGroupLockerDic.Add(serverId, serverLocker);
            }

            lock (serverLocker)
            {
                if (!_serverChannelGroupDic.ContainsKey(serverId))
                {
                    _serverChannelGroupDic.Add(serverId, new DefaultChannelGroup(context.Executor));
                }
            }
        }

        _serverChannelGroupDic[serverId].Add(context.Channel);
    }

    /// <summary>
    ///  서버그룹내 채널삭제 - 중복접속시 만료채널 제거
    /// </summary>
    public static void RemoveServerChannel(IChannel channel, int serverId)
    {
        // 서버그룹에서 삭제
        if (_serverChannelGroupDic.ContainsKey(serverId))
        {
            _serverChannelGroupDic[serverId].Remove(channel);
        }

        // 전체그룹에서 삭제
        _allChannelGroup.Remove(channel);
    }

    public static void RemoveDuplcatedChannel()
    {
        if (_duplcatedChannel.Count > 0)
        {
            var resUserLogin = new ResUserLogin
            {
                ResponseCode = E_RESPONSE_CODE.DEUPLCATE_LOGIN
            };

            GamePacket gamePacket = new GamePacket
            {
                PacketType = E_PACKET_TYPE.PS_USER_LOGIN,
                PacketBody = EncUtil.EncodeBase64(resUserLogin)
            };

            IChannel channel = _duplcatedChannel.Dequeue();
            channel.WriteAndFlushAsync(gamePacket);
        }
    }

    public static void RemoveChannel(IChannelHandlerContext context)
    {
        int serverId = context.Channel.GetAttrServerId();
        long accountId = context.Channel.GetAttrAccountId();

        // 서버그룹에서 삭제
        if (serverId > 0 && _serverChannelGroupDic.ContainsKey(serverId))
        {
            _serverChannelGroupDic[serverId].Remove(context.Channel);
        }

        // 유저채널 삭제
        if (accountId > 0 && _userChannelDic.ContainsKey(accountId))
        {
            if (_userChannelDic[accountId].Id == context.Channel.Id)
            {
                _userChannelDic.Remove(accountId);
            }
        }

        // 전체채널그룹에서 삭제
        _allChannelGroup.Remove(context.Channel);
    }

    /// <summary>
    ///  나 포함 전체유저에게 응답
    /// </summary>
    public static void SendToEveryone(GamePacket gamePacket)
    {
        _allChannelGroup.WriteAndFlushAsync(gamePacket);
    }

    private class EveryoneButMe : IChannelMatcher
    {
        private readonly IChannelId _channelId;

        public EveryoneButMe(IChannelId channelId)
        {
            this._channelId = channelId;
        }

        public bool Matches(IChannel channel) => channel.Id != this._channelId;
    }

    /// <summary>
    ///  나를 뺀 전체유저에게 응답
    /// </summary>
    public static void SendToEveryoneButMe(long accountId, GamePacket gamePacket)
    {
        if (_userChannelDic.TryGetValue(accountId, out var userChannel))
        {
            _allChannelGroup.WriteAndFlushAsync(gamePacket, new EveryoneButMe(userChannel.Id));
        }
    }

    /// <summary>
    ///  서버그룹내 유저에게 응답
    /// </summary>
    public static void SendToServer(int serverId, GamePacket gamePacket)
    {
        if (_serverChannelGroupDic.TryGetValue(serverId, out var serverChannelGroup))
        {
            serverChannelGroup.WriteAndFlushAsync(gamePacket);
        }
    }

    /// <summary>
    ///  지정된 유저들에게 응답
    /// </summary>
    public static void SendToUserList(IEnumerable<long> userList, GamePacket gamePacket)
    {
        foreach (long accountId in userList)
        {
            if (_userChannelDic.ContainsKey(accountId))
            {
                _userChannelDic[accountId].WriteAndFlushAsync(gamePacket);
            }
        }
    }

    /// <summary>
    ///  특정유저에게 응답
    /// </summary>
    public static void SendToUser(long accountId, GamePacket gamePacket)
    {
        //Console.WriteLine($"Sent Packek - {JsonConvert.SerializeObject(gamePacket)}");
        if (_userChannelDic.ContainsKey(accountId))
        {
            _userChannelDic[accountId].WriteAndFlushAsync(gamePacket);
        }
    }
}
