﻿namespace Snowpipe
{
    public class GamePacket
    {
        private readonly string _delimiter = "|";

        public E_PACKET_TYPE PacketType { get; set; }
        public string PacketBody { get; set; }


        public GamePacket()
        {

        }

        public GamePacket(E_PACKET_TYPE packetType)
        {
            PacketType = packetType;
            PacketBody = null;
        }

        public GamePacket(E_PACKET_TYPE packetType, string packetBody)
        {
            PacketType = packetType;
            PacketBody = packetBody;
        }

        public string ConvertToString()
        {
            //return $"{PacketType}{_delimiter}{PacketBody.Length}{_delimiter}{PacketBody}{Environment.NewLine}";
            return $"{PacketType}{_delimiter}{PacketBody.Length}{_delimiter}{PacketBody}*";
        }

        public GamePacket Clone()
        {
            GamePacket copyGamePacket = new GamePacket
            {
                PacketType = this.PacketType,
                PacketBody = this.PacketBody
            };
            return copyGamePacket;
        }
    }
}
