﻿namespace DotNettyOthelloLib.Data;


public class RedisKeyConstants
{
    public static string SessionToken = "{0}:session_token";    // {accountId}
    public static string PubSubData = "publish";
}

public enum E_REDIS_DATABASE
{
    SESSION = 0,
    PUBSUB = 10,
}

public enum E_REDIS_EXPIRED
{
    FIVE_MINUTES = 300,
}
