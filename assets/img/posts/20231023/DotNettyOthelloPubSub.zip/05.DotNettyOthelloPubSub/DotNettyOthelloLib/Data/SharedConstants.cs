﻿namespace Snowpipe
{
    public class Constants
    {

    }

    public enum E_PACKET_TYPE
    {
        NONE = 0,
        REQ_USER_LOGIN = 1,
        RES_USER_LOGIN = 2,

        REQ_ENTER_SINGLE_PLAY = 10,
        RES_ENTER_SINGLE_PLAY = 11,
        REQ_EXIT_SINGLE_PLAY = 12,
        RES_EXIT_SINGLE_PLAY = 13,
        REQ_PUT_SINGLE_PLAY_STONE = 14,
        RES_PUT_SINGLE_PLAY_STONE = 15,
        REQ_RESET_SINGLE_PLAY = 16,
        RES_RESET_SINGLE_PLAY = 17,

        REQ_ENTER_BATTLE_PLAY = 20,
        RES_ENTER_BATTLE_PLAY = 21,
        REQ_CREATE_BATTLE_ROOM = 22,
        RES_CREATE_BATTLE_ROOM = 23,
        REQ_EXIT_BATTLE_ROOM = 24,
        RES_EXIT_BATTLE_ROOM = 25,
        REQ_JOIN_BATTLE_ROOM = 26,
        RES_JOIN_BATTLE_ROOM = 27,
        REQ_PUT_BATTLE_PLAY_STONE = 28,
        RES_PUT_BATTLE_PLAY_STONE = 29,
        REQ_EXIT_BATTLE_JOIN = 30,
        RES_EXIT_BATTLE_JOIN = 31,

        PS_USER_LOGIN = 100,
        PS_CREATE_BATTLE_ROOM = 101,
        PS_EXIT_BATTLE_ROOM = 102,
        PS_JOIN_BATTLE_ROOM = 103,
        PS_PUT_BATTLE_PLAY_STONE = 104,
        PS_EXIT_BATTLE_JOIN = 105,
    }

    public enum E_LOGIN_PLATFORM_TYPE
    {
        DEFAULT = 0,
        GOOGLE = 1,
        APPLE = 2,
        FACEBOOK = 3,
        TWITTER = 4
    }

    public enum E_RESPONSE_CODE
    {
        DEFAULT = 0,
        SUCCESS = 1,

        // channel
        INVALID_CHANNEL_ATTR = 101,

        // packet
        INVALID_PARAMETER = 201,
        FAIL_DESERIALIZE = 202,

        // session
        INVALID_SESSION = 301,
        NOT_EXIST_SESSION = 302,
        EXPIRED_SESSION = 303,
        DEUPLCATE_LOGIN = 304,

        // user
        NOT_EXIST_USER = 401,
        OFFLINE_USER = 402,

        // game
        NOT_PLAYING = 501,
        NOT_EMPTY_CELL = 502,
        GAME_OVER = 504,
        MUST_PASS = 505,
        ALREADY_EXIST_ROOM = 506,
        ALREADY_PLAYING_BATTLE = 507,
        INVALID_DATA = 508,
    }

    public enum E_PLAY_TYPE
    {
        NONE = 0,
        SINGLE = 1,
        BATTLE = 2
    }

    public enum E_STONE_TYPE
    {
        NONE = 0,
        BLACK = 1,
        WHITE = 2,
    }

    public enum E_TURN_RESULT
    {
        NONE = 0,
        NORMAL = 1,
        PASS = 2,
        GAME_OVER = 3,
    }
}