﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Query;

namespace DotNettyOthelloLib.Extensions;

public static class DatabaseFacadeExtension
{
    public static T ExecuteProcedure<T>(this DatabaseFacade database, [NotParameterized] FormattableString sql)
    {
        return database.SqlQuery<T>(sql).ToList<T>().FirstOrDefault();
    }

    public static void ExecuteProcedure(this DatabaseFacade database, FormattableString sql)
    {
        database.ExecuteSql(sql);
    }
}
