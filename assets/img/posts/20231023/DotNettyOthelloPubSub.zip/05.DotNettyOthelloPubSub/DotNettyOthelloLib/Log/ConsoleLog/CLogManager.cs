﻿using DotNetty.Common.Internal.Logging;
using Microsoft.Extensions.Logging;

namespace DotNettyOthelloLib.Log.ConsoleLog;

public static class CLogManager
{
    public static void SetConsoleLogger() => InternalLoggerFactory.DefaultFactory = LoggerFactory.Create(builder => builder.AddConsole());
}
