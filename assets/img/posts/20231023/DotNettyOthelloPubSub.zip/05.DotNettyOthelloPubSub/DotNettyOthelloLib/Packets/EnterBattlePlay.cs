﻿namespace Snowpipe
{
    public class ReqEnterBattlePlay : ReqBase
    {

    }

    public class ResEnterBattlePlay : ResBase
    {
        public List<UserInfo> WaitingList { get; set; }

        public ResEnterBattlePlay() : base()
        {

        }
    }
}
