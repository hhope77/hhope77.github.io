﻿namespace Snowpipe
{
    public class EnterSinglePlay
    {
        public class ReqEnterSinglePlay : ReqBase
        {

        }

        public class ResEnterSinglePlay : ResBase
        {
            public E_STONE_TYPE MyStoneType { get; set; }
            public E_STONE_TYPE[,] StoneDatas { get; set; }

            public ResEnterSinglePlay() : base()
            {

            }
        }
    }
}
