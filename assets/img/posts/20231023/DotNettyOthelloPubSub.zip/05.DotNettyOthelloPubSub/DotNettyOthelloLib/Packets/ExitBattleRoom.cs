﻿namespace Snowpipe
{
    public class ReqExitBattleRoom : ReqBase
    {

    }

    public class ResExitBattleRoom : ResBase
    {
        public UserInfo WaitingUser { get; set; }

        public ResExitBattleRoom() : base()
        {

        }
    }
}
