﻿namespace Snowpipe
{
    public class ReqExitSinglePlay : ReqBase
    {

    }

    public class ResExitSinglePlay : ResBase
    {
        public ResExitSinglePlay() : base()
        {

        }
    }
}
