﻿namespace Snowpipe
{
    public class ReqBase
    {
        public string Token { get; set; }

        public ReqBase()
        {

        }
    }

    public class ResBase
    {
        public E_RESPONSE_CODE ResponseCode { get; set; }

        public ResBase()
        {
            ResponseCode = E_RESPONSE_CODE.DEFAULT;
        }
    }
}
