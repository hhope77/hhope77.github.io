﻿namespace Snowpipe
{
    public class ReqPutBattlePlayStone : ReqBase
    {
        public long BattleId { get; set; }
        public PlayInfo TurnPlayInfo { get; set; }
    }

    public class ResPutBattlePlayStone : ResBase
    {
        public long BattleId { get; set; }
        public E_STONE_TYPE LastPlayStoneType { get; set; }
        public PlayInfo TurnPlayInfo { get; set; }
        public List<TurnInfo> TurnInfoList { get; set; }

        public ResPutBattlePlayStone() : base()
        {
            TurnInfoList = new List<TurnInfo>();
        }
    }
}
