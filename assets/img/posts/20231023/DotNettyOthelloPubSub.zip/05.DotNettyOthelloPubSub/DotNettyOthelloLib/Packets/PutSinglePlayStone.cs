﻿namespace Snowpipe
{
    public class ReqPutSinglePlayStone : ReqBase
    {
        public PlayInfo MyPlayInfo { get; set; }
    }

    public class ResPutSinglePlayStone : ResBase
    {
        public PlayInfo MyPlayInfo { get; set; }
        public List<TurnInfo> TurnInfoList { get; set; }

        public ResPutSinglePlayStone() : base()
        {
            TurnInfoList = new List<TurnInfo>();
        }
    }
}
