﻿namespace Snowpipe
{
    public class BattleEntry
    {
        public long AccountId { get; set; }
        public E_STONE_TYPE StoneType { get; set; }
        public bool IsHost { get; set; }

        public BattleEntry()
        {

        }

        public BattleEntry(long accountId, E_STONE_TYPE stoneType, bool isHost)
        {
            this.AccountId = accountId;
            this.StoneType = stoneType;
            this.IsHost = isHost;
        }
    }
}
