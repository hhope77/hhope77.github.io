﻿namespace Snowpipe
{
    public class BattleInfo
    {
        public long BattleId { get; set; }
        public E_STONE_TYPE LastPlayStoneType { get; set; }
        public List<BattleEntry> BattleEntryList { get; set; }
        public E_STONE_TYPE[,] StoneDatas { get; set; }

        public BattleInfo()
        {
            BattleEntryList = new List<BattleEntry> { };
        }
    }
}
