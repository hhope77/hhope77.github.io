﻿namespace Snowpipe
{
    public class PlayInfo
    {
        public E_STONE_TYPE StoneType { get; set; }
        public int IndexX { get; set; }
        public int IndexY { get; set; }

        public PlayInfo(E_STONE_TYPE stoneType, int indexX, int indexY)
        {
            StoneType = stoneType;
            IndexX = indexX;
            IndexY = indexY;
        }
    }
}
