﻿using DotNettyOthelloLib.Data;
using DotNettyOthelloLib.Log.FileLog;
using StackExchange.Redis;

namespace DotNettyOthelloLib.SRedis;

public class RedisContext
{
    private static Lazy<ConnectionMultiplexer> _lazyConnection;
    private static readonly object _connectLocker = new object();
    private static readonly object _reconnectLocker = new object();
    private readonly string _connectionString;
    protected IDatabase _db;

    protected ConnectionMultiplexer Connection { get { return _lazyConnection.Value; } }

    public RedisContext(string connectionString, E_REDIS_DATABASE redisDbType)
    {
        _connectionString = connectionString;
        CreateConnection(redisDbType);
    }

    private void CreateConnection(E_REDIS_DATABASE redisDbType)
    {
        lock (_connectLocker)
        {
            if (_lazyConnection == null)
            {
                _lazyConnection = new Lazy<ConnectionMultiplexer>(() => ConnectionMultiplexer.Connect(_connectionString));
                _db = _lazyConnection.Value.GetDatabase((int)redisDbType);
            }
        }
    }

    protected void ForceReconnect(E_REDIS_DATABASE redisDbType)
    {
        lock (_reconnectLocker)
        {
            this.CloseConnection();
            this.CreateConnection(redisDbType);
        }
    }

    private void CloseConnection()
    {
        if (_lazyConnection != null)
        {
            try
            {
                _lazyConnection.Value.Close();
            }
            catch (Exception ex)
            {
                FLogManager.Get().ServiceLog.AppendFatalLog("ConnectionMultiplexer Close error", ex);
            }
        }
    }

    #region Redis COMMON http://redisgate.kr/redis/command/common.php
    protected void Expire(string key, int expireSecond)
    {
        _db.KeyExpire(key, new TimeSpan(0, 0, expireSecond));
    }
    #endregion

    #region Redis Strings http://redisgate.kr/redis/command/strings.php
    protected void Set(string key, string value)
    {
        _db.StringSet(key, value);
    }

    protected void SetEx(string key, string value, int expireSecond)
    {
        _db.StringSet(key, value, new TimeSpan(0, 0, expireSecond));
    }

    protected string Get(string key)
    {
        return _db.StringGet(key);
    }

    protected T Get<T>(string key)
    {
        var value = Get(key);
        return value == null ? default : System.Text.Json.JsonSerializer.Deserialize<T>(value);
    }
    #endregion

    #region Redis HASHES http://redisgate.kr/redis/command/hashes.php
    protected string HGet(string key, string field)
    {
        return _db.HashGet(key, field).ToString();
    }
    protected void HSet(string key, RedisValue field, RedisValue value)
    {
        _db.HashSet(key, field, value);
    }

    #endregion
}