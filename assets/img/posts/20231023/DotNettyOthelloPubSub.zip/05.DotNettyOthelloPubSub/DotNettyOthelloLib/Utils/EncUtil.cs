﻿using Newtonsoft.Json;
using System.Text;

namespace Snowpipe
{
    public class EncUtil
    {
        public static string EncodeBase64<T>(T req)
        {
            return EncodeBase64(JsonConvert.SerializeObject(req));
        }

        public static T DecodeBase64<T>(string data)
        {
            string body = DecodeBase64(data);
            return JsonConvert.DeserializeObject<T>(body);
        }

        public static string EncodeBase64(string data)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(data);
            return Convert.ToBase64String(bytes);
            //return data;
        }

        public static string DecodeBase64(string data)
        {
            byte[] bytes = Convert.FromBase64String(data);
            return Encoding.UTF8.GetString(bytes);
            //return data;
        }
    }
}
