﻿using DotNetty.Transport.Channels;
using DotNettyOthelloLib.Channel;
using DotNettyOthelloLib.Data;
using DotNettyOthelloLib.Db;
using DotNettyOthelloLib.Extensions;
using DotNettyOthelloLib.Log.FileLog;
using DotNettyOthelloLib.SRedis;
using DotNettyOthelloLib.SRedis.PubSub;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Snowpipe;
using System.Reflection;
using static Snowpipe.EnterSinglePlay;

namespace DotNettyOthelloServer.Handlers;

public partial class ServerPacketHandler
{
    private readonly int _boardScale = 8;
    private Dictionary<long/* AccountId */, E_STONE_TYPE[,]> _singleGameDB = new Dictionary<long, E_STONE_TYPE[,]>();
    private Dictionary<long/* AccountId */, UserInfo> _battleWaitingDB = new Dictionary<long, UserInfo>();
    private Dictionary<long/* BattleId */, BattleInfo> _battleGameDB = new Dictionary<long, BattleInfo>();

    private readonly AccountDbContext _accountDbContext;
    private readonly SessionRedisContext _sessionRedisContext;
    private readonly PubsubRedisContext _pubsubRedisContext;
    private int _serverId;

    public ServerPacketHandler(IServiceProvider serviceProvider)
    {
        _sessionRedisContext = serviceProvider.GetRequiredService<SessionRedisContext>();
        _pubsubRedisContext = serviceProvider.GetRequiredService<PubsubRedisContext>();
        _accountDbContext = serviceProvider.GetRequiredService<AccountDbContext>();

        SetServerId();
    }

    private void SetServerId()
    {
        // TODO
        // 웹서버와 소켓서버를 함께사용하면 웹서버에서 ServerId를 할당
        // 웹서버없이 소켓서버만으로 사용한다면 로그인용 서버와 게임소켓서버를 분리 후
        // 로그인시 CCU가 가장 적은 게임서버를 할당하고 로그인서버는 연결종료
        // 현재는 임시 할당
        _serverId = 123;
    }

    private void _ServerDispatch(IChannelHandlerContext context, GamePacket reqGamePacket)
    {
        string methodName = "_" + reqGamePacket.PacketType.ToCamelCase();
        MethodInfo dynMethod = this.GetType().GetMethod(methodName, BindingFlags.NonPublic | BindingFlags.Instance);
        if (dynMethod != null)
        {
            dynMethod.Invoke(this, new object[] { context, reqGamePacket.PacketBody });
        }
    }

    #region 레디스 데이터 관련
    /// <summary>
    ///  세션토큰 생성
    ///  TODO - jwt webtoken 을 받아서 세션토큰으로 사용하는걸 검토!
    /// </summary>
    private string _SetRedisUserSession(AccountTB accountDto)
    {
        // session token
        string tokenData = $"{accountDto.AccountId}-{accountDto.Nickname}";
        string token = EncUtil.EncodeBase64(tokenData);

        _sessionRedisContext.SetSessionToken(accountDto.AccountId, token);

        return token;
    }

    /// <summary>
    ///  세션체크
    /// </summary>
    private E_RESPONSE_CODE _CheckSession(long accountId, string token)
    {
        if (accountId == 0)
        {
            return E_RESPONSE_CODE.INVALID_SESSION;
        }

        if (!_sessionRedisContext.CheckSessionToken(accountId, token))
        {
            return E_RESPONSE_CODE.EXPIRED_SESSION;
        }

        // 세션 타임아웃 연장
        _sessionRedisContext.UpdateSessionTokenExpiry(accountId);

        return E_RESPONSE_CODE.SUCCESS;
    }

    /// <summary>
    ///  레디스 퍼블리시
    /// </summary>
    private void _MessagePublish(
        E_BROADCAST_TYPE broadcastType, object broadcastTarget,
        E_PACKET_TYPE pubsubPacketType, GamePacket resGamePacket
        )
    {
        var pubsubPacket = resGamePacket.Clone();
        pubsubPacket.PacketType = pubsubPacketType;
        var pubsubData = new PubSubDataModel(broadcastType, broadcastTarget, pubsubPacket);
        var pubsubDataJson = JsonConvert.SerializeObject(pubsubData);

        var listen = _pubsubRedisContext.Connection.GetSubscriber();
        listen.Publish(RedisKeyConstants.PubSubData, pubsubDataJson);
    }
    #endregion

    #region 로그인관련
    /// <summary>
    ///  유저로그인
    /// </summary>
    private void _ReqUserLogin(IChannelHandlerContext context, string packetBody)
    {
        GamePacket resPacket = new GamePacket(E_PACKET_TYPE.RES_USER_LOGIN);
        ResUserLogin resUserLogin = new ResUserLogin();

        if (string.IsNullOrEmpty(packetBody))
        {
            resUserLogin.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resUserLogin);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        ReqUserLogin reqUserLogin = EncUtil.DecodeBase64<ReqUserLogin>(packetBody);
        if (reqUserLogin == null)
        {
            resUserLogin.ResponseCode = E_RESPONSE_CODE.FAIL_DESERIALIZE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resUserLogin);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // 닉네임으로 계정조회
        var accountDto = _accountDbContext.SelectAccount(reqUserLogin.NickName);
        if (accountDto == null)
        {
            long accountId = _accountDbContext.InsertAccount(reqUserLogin.NickName);
            accountDto = _accountDbContext.SelectAccount(accountId);
        }

        // 세션토큰 생성
        string userToken = _SetRedisUserSession(accountDto);

        // 채널추가정보 저장
        context.Channel.SetAttrAccountId(accountDto.AccountId);
        context.Channel.SetAttrServerId(_serverId);
        ChannelManager.AddUserChannel(context, accountDto.AccountId);
        ChannelManager.AddServerChannel(context, _serverId);

        // 응답
        resUserLogin = new ResUserLogin
        {
            ResponseCode = E_RESPONSE_CODE.SUCCESS,
            AccountId = accountDto.AccountId,
            Token = userToken,
            NickName = accountDto.Nickname
        };

        resPacket.PacketBody = EncUtil.EncodeBase64(resUserLogin);
        ChannelManager.SendToUser(accountDto.AccountId, resPacket);

        // 중복세션 종료
        ChannelManager.RemoveDuplcatedChannel();

        // publish
        _MessagePublish(
            E_BROADCAST_TYPE.EVERYONE, null,
            E_PACKET_TYPE.PS_USER_LOGIN, resPacket
            );
    }
    #endregion

    #region 오델로 플레이공용 관련
    /// <summary>
    ///  오델로 보드판초기화
    /// </summary>
    private E_STONE_TYPE[,] _InitGameBoard()
    {
        E_STONE_TYPE[,] othello = new E_STONE_TYPE[_boardScale, _boardScale];

        for (int r = 0; r < _boardScale; r++)
        {
            for (int c = 0; c < _boardScale; c++)
            {
                // 초기세팅 바둑돌
                if ((r == 3 && c == 3) || (r == 4 && c == 4))
                {
                    othello[r, c] = E_STONE_TYPE.WHITE;
                }
                else if ((r == 3 && c == 4) || (r == 4 && c == 3))
                {
                    othello[r, c] = E_STONE_TYPE.BLACK;
                }
                else
                {
                    // 빈 바둑판으로 초기화
                    othello[r, c] = E_STONE_TYPE.NONE;
                }
            }
        }

        return othello;
    }

    /// <summary>
    ///  빈공간이 있는지 게임오버 체크
    /// </summary>
    private E_RESPONSE_CODE _CheckGameOver(E_PLAY_TYPE playType, long playingId)
    {
        // 게임중 체크
        E_STONE_TYPE[,] othello;
        if (playType == E_PLAY_TYPE.SINGLE)
        {
            if (!_singleGameDB.ContainsKey(playingId))
            {
                return E_RESPONSE_CODE.NOT_PLAYING;
            }

            othello = _singleGameDB[playingId].Clone() as E_STONE_TYPE[,];
        }
        else if (playType == E_PLAY_TYPE.BATTLE)
        {
            if (!_battleGameDB.ContainsKey(playingId))
            {
                return E_RESPONSE_CODE.NOT_PLAYING;
            }

            othello = _battleGameDB[playingId].StoneDatas.Clone() as E_STONE_TYPE[,];
        }
        else
        {
            return E_RESPONSE_CODE.INVALID_DATA;
        }

        for (int r = 0; r < othello.GetLength(0); r++)
        {
            for (int c = 0; c < othello.GetLength(1); c++)
            {
                if (othello[r, c] == E_STONE_TYPE.NONE)
                {
                    return E_RESPONSE_CODE.SUCCESS;
                }
            }
        }
        return E_RESPONSE_CODE.GAME_OVER;
    }

    /// <summary>
    ///  둘곳이 없는지 패스 체크
    /// </summary>
    /// <param name="stoneType">바둑돌 타입</param>
    private E_RESPONSE_CODE _CheckPass(E_PLAY_TYPE playType, long playingId, E_STONE_TYPE stoneType)
    {
        // 게임중 체크
        E_STONE_TYPE[,] othello;
        if (playType == E_PLAY_TYPE.SINGLE)
        {
            if (!_singleGameDB.ContainsKey(playingId))
            {
                return E_RESPONSE_CODE.NOT_PLAYING;
            }

            othello = _singleGameDB[playingId].Clone() as E_STONE_TYPE[,];
        }
        else if (playType == E_PLAY_TYPE.BATTLE)
        {
            if (!_battleGameDB.ContainsKey(playingId))
            {
                return E_RESPONSE_CODE.NOT_PLAYING;
            }

            othello = _battleGameDB[playingId].StoneDatas.Clone() as E_STONE_TYPE[,];
        }
        else
        {
            return E_RESPONSE_CODE.INVALID_DATA;
        }

        for (int r = 0; r < othello.GetLength(0); r++)
        {
            for (int c = 0; c < othello.GetLength(1); c++)
            {
                if (othello[r, c] != E_STONE_TYPE.NONE)
                {
                    continue;
                }

                if (_CheckCanReverse(playType, playingId, stoneType, r, c))
                {
                    return E_RESPONSE_CODE.SUCCESS;
                }
            }
        }

        return E_RESPONSE_CODE.MUST_PASS;
    }

    /// <summary>
    ///  방향별 뒤집기 가능한 바둑돌 수 계산
    /// </summary>
    /// <param name="direction">방향</param>
    /// <param name="stoneType">바둑돌 타입</param>
    /// <param name="indexX">2차원 행렬 인덱스 X</param>
    /// <param name="indexY">2차원 행렬 인덱스 Y</param>
    /// <param name="incX">행 증가값</param>
    /// <param name="incY">열 증가값</param>
    private int _GetReverseCnt(
        E_PLAY_TYPE playType, long playingId,
        E_DIRECTION direction, E_STONE_TYPE stoneType,
        int indexX, int indexY,
        int incX, int incY
        )
    {
        int reversedCnt = 0;
        int startX, startY, len;

        // 게임중 체크
        E_STONE_TYPE[,] othello;
        if (playType == E_PLAY_TYPE.SINGLE)
        {
            if (!_singleGameDB.ContainsKey(playingId))
            {
                return 0;
            }

            othello = _singleGameDB[playingId].Clone() as E_STONE_TYPE[,];
        }
        else if (playType == E_PLAY_TYPE.BATTLE)
        {
            if (!_battleGameDB.ContainsKey(playingId))
            {
                return 0;
            }

            othello = _battleGameDB[playingId].StoneDatas.Clone() as E_STONE_TYPE[,];
        }
        else
        {
            return 0;
        }

        // 바로옆돌은 빈칸이거나 같은색이 아니여야한다.
        if (indexX + incX < 0 || indexX + incX >= _boardScale
            || indexY + incY < 0 || indexY + incY >= _boardScale
            || othello[indexX + incX, indexY + incY] == stoneType
            || othello[indexX + incX, indexY + incY] == E_STONE_TYPE.NONE)
        {
            return reversedCnt;
        }

        // 바로옆돌의 다음돌부터 같은돌찾기
        switch (direction)
        {
            case E_DIRECTION.NORTH:
                startX = indexX - 2;
                startY = indexY;
                len = startX + 1;
                break;

            case E_DIRECTION.SOUTH:
                startX = indexX + 2;
                startY = indexY;
                len = _boardScale - startX;
                break;

            case E_DIRECTION.EAST:
                startX = indexX;
                startY = indexY + 2;
                len = _boardScale - startY;
                break;

            case E_DIRECTION.WEST:
                startX = indexX;
                startY = indexY - 2;
                len = startY + 1;
                break;

            case E_DIRECTION.NORTH_EAST:
                startX = indexX - 2;
                startY = indexY + 2;
                len = Math.Min(startX + 1, _boardScale - startY);
                break;

            case E_DIRECTION.SOUTH_WEST:
                startX = indexX + 2;
                startY = indexY - 2;
                len = Math.Min(_boardScale - startX, startY + 1);
                break;

            case E_DIRECTION.NORTH_WEST:
                startX = indexX - 2;
                startY = indexY - 2;
                len = Math.Min(startX + 1, startY + 1);
                break;

            case E_DIRECTION.SOUTH_EAST:
                startX = indexX + 2;
                startY = indexY + 2;
                len = Math.Min(_boardScale - startX, _boardScale - startY);
                break;
            default:
                return reversedCnt;
        }

        int targetX, targetY;
        for (int t = 0; t < len; t++)
        {
            targetX = startX + incX * t;
            targetY = startY + incY * t;

            reversedCnt++;

            if (othello[targetX, targetY] == stoneType)
            {
                return reversedCnt;
            }
            else if (othello[targetX, targetY] == E_STONE_TYPE.NONE)
            {
                // 같은색돌보다 빈칸을 먼저 만나면 뒤집을 수 없음.
                break;
            }
        }

        return 0;
    }

    /// <summary>
    /// 뒤집기 가능여부 확인
    /// </summary>
    /// <param name="stoneType">바둑돌 타입</param>
    /// <param name="indexX">2차원 행렬 인덱스 X</param>
    /// <param name="indexY">2차원 행렬 인덱스 Y</param>
    private bool _CheckCanReverse(
        E_PLAY_TYPE playType, long playingId
        , E_STONE_TYPE stoneType, int indexX, int indexY
        )
    {
        // 정북방향 체크
        if (_GetReverseCnt(playType, playingId, E_DIRECTION.NORTH, stoneType, indexX, indexY, -1, 0) > 0)
        {
            return true;
        }

        // 정남방향 체크
        if (_GetReverseCnt(playType, playingId, E_DIRECTION.SOUTH, stoneType, indexX, indexY, 1, 0) > 0)
        {
            return true;
        }

        // 정동방향 체크
        if (_GetReverseCnt(playType, playingId, E_DIRECTION.EAST, stoneType, indexX, indexY, 0, 1) > 0)
        {
            return true;
        }

        // 정서방향 체크
        if (_GetReverseCnt(playType, playingId, E_DIRECTION.WEST, stoneType, indexX, indexY, 0, -1) > 0)
        {
            return true;
        }

        // 북동 대각선방향 체크
        if (_GetReverseCnt(playType, playingId, E_DIRECTION.NORTH_EAST, stoneType, indexX, indexY, -1, 1) > 0)
        {
            return true;
        }

        // 남서 대각선방향 체크
        if (_GetReverseCnt(playType, playingId, E_DIRECTION.SOUTH_WEST, stoneType, indexX, indexY, 1, -1) > 0)
        {
            return true;
        }

        // 북서 대각선방향 체크
        if (_GetReverseCnt(playType, playingId, E_DIRECTION.NORTH_WEST, stoneType, indexX, indexY, -1, -1) > 0)
        {
            return true;
        }

        // 남동 대각선방향 체크
        if (_GetReverseCnt(playType, playingId, E_DIRECTION.SOUTH_EAST, stoneType, indexX, indexY, 1, 1) > 0)
        {
            return true;
        }

        return false;
    }

    /// <summary>
    ///  착수가능여부 체크
    /// </summary>
    private E_RESPONSE_CODE _CheckStoneLocation(
        E_PLAY_TYPE playType, long playingId
        , E_STONE_TYPE stoneType, int indexX, int indexY
        )
    {
        // 게임중 체크
        E_STONE_TYPE[,] othello;
        if (playType == E_PLAY_TYPE.SINGLE)
        {
            if (!_singleGameDB.ContainsKey(playingId))
            {
                return E_RESPONSE_CODE.NOT_PLAYING;
            }

            othello = _singleGameDB[playingId].Clone() as E_STONE_TYPE[,];
        }
        else if (playType == E_PLAY_TYPE.BATTLE)
        {
            if (!_battleGameDB.ContainsKey(playingId))
            {
                return E_RESPONSE_CODE.NOT_PLAYING;
            }

            othello = _battleGameDB[playingId].StoneDatas.Clone() as E_STONE_TYPE[,];
        }
        else
        {
            return E_RESPONSE_CODE.INVALID_DATA;
        }

        // 좌표 입력값 체크
        if (othello[indexX, indexY] != E_STONE_TYPE.NONE
            || _CheckCanReverse(playType, playingId, stoneType, indexX, indexY) == false)
        {
            return E_RESPONSE_CODE.NOT_EMPTY_CELL;
        }


        return E_RESPONSE_CODE.SUCCESS;
    }

    /// <summary>
    ///  방향별 바둑돌 뒤집기
    /// </summary>
    /// <param name="direction">방향</param>
    /// <param name="stoneType">바둑돌 타입</param>
    /// <param name="indexX">2차원 행렬 인덱스 X</param>
    /// <param name="indexY">2차원 행렬 인덱스 Y</param>
    /// <param name="incX">행 증가값</param>
    /// <param name="incY">열 증가값</param>
    private int _ReverseStoneToward(
        E_PLAY_TYPE playType, long playingId,
        E_DIRECTION direction, E_STONE_TYPE stoneType,
        int indexX, int indexY,
        int incX, int incY
        )
    {
        int reversedCnt = 0;
        int startX, startY, len;

        // 게임중 체크
        E_STONE_TYPE[,] othello;
        if (playType == E_PLAY_TYPE.SINGLE)
        {
            if (!_singleGameDB.ContainsKey(playingId))
            {
                return reversedCnt;
            }

            othello = _singleGameDB[playingId].Clone() as E_STONE_TYPE[,];
        }
        else if (playType == E_PLAY_TYPE.BATTLE)
        {
            if (!_battleGameDB.ContainsKey(playingId))
            {
                return reversedCnt;
            }

            othello = _battleGameDB[playingId].StoneDatas.Clone() as E_STONE_TYPE[,];
        }
        else
        {
            return reversedCnt;
        }

        // 바로옆돌은 빈칸이거나 같은색이 아니여야한다.
        if (indexX + incX < 0 || indexX + incX >= _boardScale
            || indexY + incY < 0 || indexY + incY >= _boardScale
            || othello[indexX + incX, indexY + incY] == stoneType
            || othello[indexX + incX, indexY + incY] == E_STONE_TYPE.NONE)
        {
            return reversedCnt;
        }

        // 바로옆돌의 다음돌부터 뒤집기
        switch (direction)
        {
            case E_DIRECTION.NORTH:
                startX = indexX - 2;
                startY = indexY;
                len = startX + 1;
                break;

            case E_DIRECTION.SOUTH:
                startX = indexX + 2;
                startY = indexY;
                len = _boardScale - startX;
                break;

            case E_DIRECTION.EAST:
                startX = indexX;
                startY = indexY + 2;
                len = _boardScale - startY;
                break;

            case E_DIRECTION.WEST:
                startX = indexX;
                startY = indexY - 2;
                len = startY + 1;
                break;

            case E_DIRECTION.NORTH_EAST:
                startX = indexX - 2;
                startY = indexY + 2;
                len = Math.Min(startX + 1, _boardScale - startY);
                break;

            case E_DIRECTION.SOUTH_WEST:
                startX = indexX + 2;
                startY = indexY - 2;
                len = Math.Min(_boardScale - startX, startY + 1);
                break;

            case E_DIRECTION.NORTH_WEST:
                startX = indexX - 2;
                startY = indexY - 2;
                len = Math.Min(startX + 1, startY + 1);
                break;

            case E_DIRECTION.SOUTH_EAST:
                startX = indexX + 2;
                startY = indexY + 2;
                len = Math.Min(_boardScale - startX, _boardScale - startY);
                break;
            default:
                return reversedCnt;
        }

        // 뒤집을 바둑돌 좌표 저장 리스트
        List<(int, int)> targetReverseList = new List<(int, int)>();
        targetReverseList.Add((indexX + incX, indexY + incY));  // 바로옆돌

        bool canReserve = false;
        int targetX, targetY;
        for (int t = 0; t < len; t++)
        {
            targetX = startX + incX * t;
            targetY = startY + incY * t;

            if (othello[targetX, targetY] == stoneType)
            {
                // 같은돌 이면 루프중지
                canReserve = true;
                break;
            }
            else if (othello[targetX, targetY] == E_STONE_TYPE.NONE)
            {
                // 같은색돌보다 빈칸을 먼저 만나면 뒤집을 수 없음.
                break;
            }

            targetReverseList.Add((targetX, targetY));
        }

        // 대상 바둑돌 뒤집기
        if (canReserve)
        {
            foreach (var (x, y) in targetReverseList)
            {
                othello[x, y] = stoneType;
                reversedCnt++;
            }

            if (playType == E_PLAY_TYPE.SINGLE)
            {
                _singleGameDB[playingId] = othello;
            }
            else if (playType == E_PLAY_TYPE.BATTLE)
            {
                _battleGameDB[playingId].StoneDatas = othello;
            }
        }

        return reversedCnt;
    }

    /// <summary>
    ///  모든 바둑돌 뒤집기
    /// </summary>
    /// <param name="stoneType">바둑돌 타입</param>
    /// <param name="indexX">2차원 행렬 인덱스 X</param>
    /// <param name="indexY">2차원 행렬 인덱스 Y</param>
    private int _ReverseAllStone(
        E_PLAY_TYPE playType, long playingId
        , E_STONE_TYPE stoneType, int indexX, int indexY
        )
    {
        int totalReversedCnt = 0;

        // 정북방향 뒤집기
        totalReversedCnt += _ReverseStoneToward(playType, playingId, E_DIRECTION.NORTH, stoneType, indexX, indexY, -1, 0);

        // 정남방향 뒤집기
        totalReversedCnt += _ReverseStoneToward(playType, playingId, E_DIRECTION.SOUTH, stoneType, indexX, indexY, 1, 0);

        // 정동방향 뒤집기
        totalReversedCnt += _ReverseStoneToward(playType, playingId, E_DIRECTION.EAST, stoneType, indexX, indexY, 0, 1);

        // 정서방향 뒤집기
        totalReversedCnt += _ReverseStoneToward(playType, playingId, E_DIRECTION.WEST, stoneType, indexX, indexY, 0, -1);

        // 북동 대각선방향 뒤집기
        totalReversedCnt += _ReverseStoneToward(playType, playingId, E_DIRECTION.NORTH_EAST, stoneType, indexX, indexY, -1, 1);

        // 남서 대각선방향 뒤집기
        totalReversedCnt += _ReverseStoneToward(playType, playingId, E_DIRECTION.SOUTH_WEST, stoneType, indexX, indexY, 1, -1);

        // 북서 대각선방향 뒤집기
        totalReversedCnt += _ReverseStoneToward(playType, playingId, E_DIRECTION.NORTH_WEST, stoneType, indexX, indexY, -1, -1);

        // 남동 대각선방향 뒤집기
        totalReversedCnt += _ReverseStoneToward(playType, playingId, E_DIRECTION.SOUTH_EAST, stoneType, indexX, indexY, 1, 1);

        return totalReversedCnt;
    }

    /// <summary>
    /// 뒤집기 가능한 전체 바둑돌 수 계산 - For AI
    /// </summary>
    /// <param name="stoneType">바둑돌 타입</param>
    /// <param name="indexX">2차원 행렬 인덱스 X</param>
    /// <param name="indexY">2차원 행렬 인덱스 Y</param>
    private int _GetTotalReverseCnt(E_PLAY_TYPE playType, long playingId, E_STONE_TYPE stoneType, int indexX, int indexY)
    {
        int totalReversedCnt = 0;

        // 정북방향 뒤집기 가능 수
        totalReversedCnt += _GetReverseCnt(playType, playingId, E_DIRECTION.NORTH, stoneType, indexX, indexY, -1, 0);

        // 정남방향 뒤집기 가능 수
        totalReversedCnt += _GetReverseCnt(playType, playingId, E_DIRECTION.SOUTH, stoneType, indexX, indexY, 1, 0);

        // 정동방향 뒤집기 가능 수
        totalReversedCnt += _GetReverseCnt(playType, playingId, E_DIRECTION.EAST, stoneType, indexX, indexY, 0, 1);

        // 정서방향 뒤집기 가능 수
        totalReversedCnt += _GetReverseCnt(playType, playingId, E_DIRECTION.WEST, stoneType, indexX, indexY, 0, -1);

        // 북동 대각선방향 뒤집기 가능 수
        totalReversedCnt += _GetReverseCnt(playType, playingId, E_DIRECTION.NORTH_EAST, stoneType, indexX, indexY, -1, 1);

        // 남서 대각선방향 뒤집기 가능 수
        totalReversedCnt += _GetReverseCnt(playType, playingId, E_DIRECTION.SOUTH_WEST, stoneType, indexX, indexY, 1, -1);

        // 북서 대각선방향 뒤집기 가능 수
        totalReversedCnt += _GetReverseCnt(playType, playingId, E_DIRECTION.NORTH_WEST, stoneType, indexX, indexY, -1, -1);

        // 남동 대각선방향 뒤집기 가능 수
        totalReversedCnt += _GetReverseCnt(playType, playingId, E_DIRECTION.SOUTH_EAST, stoneType, indexX, indexY, 1, 1);

        return totalReversedCnt;
    }

    /// <summary>
    ///  가장 많이 뒤집을 수 있는 최상의 좌표값 조회 - For AI
    /// </summary>
    /// <param name="stoneType">바둑돌 타입</param>
    private (int, int) GetBestCoordinate(E_PLAY_TYPE playType, long playingId, E_STONE_TYPE stoneType)
    {
        int bestIndexX = -1;
        int bestIndexY = -1;
        int bestReversedCnt = 0;
        int reversedCnt;

        // 게임중 체크
        E_STONE_TYPE[,] othello;
        if (playType == E_PLAY_TYPE.SINGLE)
        {
            if (!_singleGameDB.ContainsKey(playingId))
            {
                return (bestIndexX, bestIndexY);
            }

            othello = _singleGameDB[playingId].Clone() as E_STONE_TYPE[,];
        }
        else if (playType == E_PLAY_TYPE.SINGLE)
        {
            if (!_battleGameDB.ContainsKey(playingId))
            {
                return (bestIndexX, bestIndexY);
            }

            othello = _battleGameDB[playingId].StoneDatas.Clone() as E_STONE_TYPE[,];
        }
        else
        {
            return (bestIndexX, bestIndexY);
        }

        for (int r = 0; r < othello.GetLength(0); r++)
        {
            for (int c = 0; c < othello.GetLength(1); c++)
            {
                if (othello[r, c] != E_STONE_TYPE.NONE)
                {
                    continue;
                }

                reversedCnt = _GetTotalReverseCnt(playType, playingId, stoneType, r, c);

                if (reversedCnt > bestReversedCnt)
                {
                    bestIndexX = r;
                    bestIndexY = c;
                    bestReversedCnt = reversedCnt;
                }
            }
        }

        return (bestIndexX, bestIndexY);
    }

    /// <summary>
    ///  상대 스톤타입 조회
    /// </summary>
    private E_STONE_TYPE GetOpponentStoneType(E_STONE_TYPE myStoneType)
    {
        if (myStoneType == E_STONE_TYPE.BLACK)
        {
            return E_STONE_TYPE.WHITE;
        }
        else if (myStoneType == E_STONE_TYPE.WHITE)
        {
            return E_STONE_TYPE.BLACK;
        }
        return E_STONE_TYPE.NONE;
    }

    private E_RESPONSE_CODE _PlayTurn(
        E_PLAY_TYPE playType, long playingId
        , E_STONE_TYPE stoneType, int indexX, int indexY
        )
    {
        // 해당위치 착수가능 체크
        E_RESPONSE_CODE resultCode = _CheckStoneLocation(
            playType
            , playingId
            , stoneType
            , indexX
            , indexY
           );

        if (resultCode != E_RESPONSE_CODE.SUCCESS)
        {
            return resultCode;
        }

        // 착수 및 돌 뒤집기
        if (playType == E_PLAY_TYPE.SINGLE)
        {
            _singleGameDB[playingId][indexX, indexY] = stoneType;
            _ReverseAllStone(playType, playingId, stoneType, indexX, indexY);
        }
        else if (playType == E_PLAY_TYPE.BATTLE)
        {
            _battleGameDB[playingId].StoneDatas[indexX, indexY] = stoneType;
            _ReverseAllStone(playType, playingId, stoneType, indexX, indexY);
        }


        return resultCode;
    }
    #endregion

    #region 오델로 싱글플레이 관련
    /// <summary>
    ///  싱글플레이 초기화
    /// </summary>
    private E_STONE_TYPE[,] _InitSignleGame(long accountId)
    {
        E_STONE_TYPE[,] othello = _InitGameBoard();
        if (_singleGameDB.ContainsKey(accountId))
        {
            _singleGameDB[accountId] = othello;
        }
        else
        {
            _singleGameDB.Add(accountId, othello);
        }

        return othello;
    }

    /// <summary>
    ///  싱글플레이 입장
    /// </summary>
    private void _ReqEnterSinglePlay(IChannelHandlerContext context, string packetBody)
    {
        GamePacket resPacket = new GamePacket(E_PACKET_TYPE.RES_ENTER_SINGLE_PLAY);
        ResEnterSinglePlay resEnterSinglePlay = new ResEnterSinglePlay();

        if (string.IsNullOrEmpty(packetBody))
        {
            resEnterSinglePlay.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resEnterSinglePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        if (string.IsNullOrEmpty(packetBody))
        {
            resEnterSinglePlay.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resEnterSinglePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        ReqEnterSinglePlay reqEnterSinglePlay = EncUtil.DecodeBase64<ReqEnterSinglePlay>(packetBody);
        if (reqEnterSinglePlay == null)
        {
            resEnterSinglePlay.ResponseCode = E_RESPONSE_CODE.FAIL_DESERIALIZE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resEnterSinglePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        long accountId = context.Channel.GetAttrAccountId();
        if (accountId == 0)
        {
            resEnterSinglePlay.ResponseCode = E_RESPONSE_CODE.INVALID_CHANNEL_ATTR;
            resPacket.PacketBody = EncUtil.EncodeBase64(resEnterSinglePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // session check
        E_RESPONSE_CODE sessionResult = _CheckSession(accountId, reqEnterSinglePlay.Token);
        if (sessionResult != E_RESPONSE_CODE.SUCCESS)
        {
            resEnterSinglePlay.ResponseCode = sessionResult;
            resPacket.PacketBody = EncUtil.EncodeBase64(resEnterSinglePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        var stoneDatas = _InitSignleGame(accountId);

        resEnterSinglePlay = new ResEnterSinglePlay
        {
            ResponseCode = E_RESPONSE_CODE.SUCCESS,
            MyStoneType = E_STONE_TYPE.BLACK,   // 싱글게임은 유저가 흑돌!
            StoneDatas = stoneDatas
        };

        resPacket.PacketBody = EncUtil.EncodeBase64(resEnterSinglePlay);
        ChannelManager.SendToUser(accountId, resPacket);
    }

    /// <summary>
    ///  싱글게임 퇴장
    /// </summary>
    private void _ReqExitSinglePlay(IChannelHandlerContext context, string packetBody)
    {
        GamePacket resPacket = new GamePacket(E_PACKET_TYPE.RES_EXIT_SINGLE_PLAY);
        ResExitSinglePlay resExitSinglePlay = new ResExitSinglePlay();

        if (string.IsNullOrEmpty(packetBody))
        {
            resExitSinglePlay.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitSinglePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        ReqExitSinglePlay reqExitSinglePlay = EncUtil.DecodeBase64<ReqExitSinglePlay>(packetBody);
        if (reqExitSinglePlay == null)
        {
            resExitSinglePlay.ResponseCode = E_RESPONSE_CODE.FAIL_DESERIALIZE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitSinglePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        long accountId = context.Channel.GetAttrAccountId();
        if (accountId == 0)
        {
            resExitSinglePlay.ResponseCode = E_RESPONSE_CODE.INVALID_CHANNEL_ATTR;
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitSinglePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // session check
        E_RESPONSE_CODE sessionResult = _CheckSession(accountId, reqExitSinglePlay.Token);
        if (sessionResult != E_RESPONSE_CODE.SUCCESS)
        {
            resExitSinglePlay.ResponseCode = sessionResult;
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitSinglePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        if (_singleGameDB.ContainsKey(accountId))
        {
            _singleGameDB.Remove(accountId);
        }

        resExitSinglePlay.ResponseCode = E_RESPONSE_CODE.SUCCESS;
        resPacket.PacketBody = EncUtil.EncodeBase64(resExitSinglePlay);
        ChannelManager.SendToUser(accountId, resPacket);
    }

    /// <summary>
    ///  싱글플레이 착수
    /// </summary>
    private void _ReqPutSinglePlayStone(IChannelHandlerContext context, string packetBody)
    {
        E_RESPONSE_CODE resultCode;

        GamePacket resPacket = new GamePacket(E_PACKET_TYPE.RES_PUT_SINGLE_PLAY_STONE);
        ResPutSinglePlayStone resPutSinglePlayStone = new ResPutSinglePlayStone();

        if (string.IsNullOrEmpty(packetBody))
        {
            resPutSinglePlayStone.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resPutSinglePlayStone);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        ReqPutSinglePlayStone reqPutSinglePlayStone = EncUtil.DecodeBase64<ReqPutSinglePlayStone>(packetBody);
        if (reqPutSinglePlayStone == null)
        {
            resPutSinglePlayStone.ResponseCode = E_RESPONSE_CODE.FAIL_DESERIALIZE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resPutSinglePlayStone);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        var myPlayInfo = reqPutSinglePlayStone.MyPlayInfo;
        resPutSinglePlayStone.MyPlayInfo = myPlayInfo;

        if (myPlayInfo.IndexX + 1 > _boardScale || myPlayInfo.IndexY + 1 > _boardScale)
        {
            resPutSinglePlayStone.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resPutSinglePlayStone);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        long accountId = context.Channel.GetAttrAccountId();
        if (accountId == 0)
        {
            resPutSinglePlayStone.ResponseCode = E_RESPONSE_CODE.INVALID_CHANNEL_ATTR;
            resPacket.PacketBody = EncUtil.EncodeBase64(resPutSinglePlayStone);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // session check
        E_RESPONSE_CODE sessionResult = _CheckSession(accountId, reqPutSinglePlayStone.Token);
        if (sessionResult != E_RESPONSE_CODE.SUCCESS)
        {
            resPutSinglePlayStone.ResponseCode = sessionResult;
            resPacket.PacketBody = EncUtil.EncodeBase64(resPutSinglePlayStone);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // 턴 플레이
        bool isUserTurn = true;
        E_STONE_TYPE stoneType;
        int indexX, indexY, turnCount = 0;
        for (; ; )
        {
            if (isUserTurn)
            {
                stoneType = myPlayInfo.StoneType;
                if (turnCount == 0)
                {
                    indexX = myPlayInfo.IndexX;
                    indexY = myPlayInfo.IndexY;
                }
                else
                {
                    indexX = indexY = -1;
                }
            }
            else
            {
                stoneType = GetOpponentStoneType(myPlayInfo.StoneType);

                // 최대로 뒤집을 수 있는 위치 조회
                (indexX, indexY) = GetBestCoordinate(E_PLAY_TYPE.SINGLE, accountId, stoneType);
            }

            TurnInfo turnInfo = new TurnInfo(stoneType, indexX, indexY);

            // 패스 체크
            resultCode = _CheckPass(E_PLAY_TYPE.SINGLE, accountId, stoneType);
            FLogManager.Get().ServiceLog.AppendInfoLog($"[_PutSinglePlayStone] stoneType [{stoneType}], indexX [{indexX}], indexY [{indexY}], Pass [{resultCode}]");
            if (resultCode != E_RESPONSE_CODE.SUCCESS)
            {
                turnInfo.TurnResult = E_TURN_RESULT.PASS;
                resPutSinglePlayStone.TurnInfoList.Add(turnInfo);
            }
            else
            {
                if (indexX >= 0 && indexY >= 0)
                {
                    // 착수 및 뒤집기
                    resultCode = _PlayTurn(E_PLAY_TYPE.SINGLE, accountId, stoneType, indexX, indexY);
                    if (resultCode != E_RESPONSE_CODE.SUCCESS)
                    {
                        resPutSinglePlayStone.ResponseCode = resultCode;
                        resPacket.PacketBody = EncUtil.EncodeBase64(resPutSinglePlayStone);
                        context.Channel.WriteAndFlushAsync(resPacket);
                        return;
                    }

                    turnInfo.TurnResult = E_TURN_RESULT.NORMAL;
                    turnInfo.TurnDatas = _singleGameDB[accountId].Clone() as E_STONE_TYPE[,];

                    //resPutSinglePlayStone.TurnInfoList.Add(turnInfo);
                }
            }

            // 게임오버 체크
            resultCode = _CheckGameOver(E_PLAY_TYPE.SINGLE, accountId);
            if (resultCode != E_RESPONSE_CODE.SUCCESS)
            {
                turnInfo.TurnResult = E_TURN_RESULT.GAME_OVER;
                //resPutSinglePlayStone.TurnInfoList.Add(turnInfo);
            }

            if (indexX < 0 || indexY < 0)
            {
                break;
            }

            resPutSinglePlayStone.TurnInfoList.Add(turnInfo);
            turnCount++;
            isUserTurn = !isUserTurn;
        }

        resPutSinglePlayStone.ResponseCode = E_RESPONSE_CODE.SUCCESS;

        resPacket.PacketBody = EncUtil.EncodeBase64(resPutSinglePlayStone);
        ChannelManager.SendToUser(accountId, resPacket);
    }

    /// <summary>
    ///  싱글플레이 재도전
    /// </summary>
    private void _ReqResetSinglePlay(IChannelHandlerContext context, string packetBody)
    {
        GamePacket resPacket = new GamePacket(E_PACKET_TYPE.RES_RESET_SINGLE_PLAY);
        ResResetSinglePlay resResetSinglePlay = new ResResetSinglePlay();

        if (string.IsNullOrEmpty(packetBody))
        {
            resResetSinglePlay.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resResetSinglePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        ReqResetSinglePlay reqResetSinglePlay = EncUtil.DecodeBase64<ReqResetSinglePlay>(packetBody);
        if (reqResetSinglePlay == null)
        {
            resResetSinglePlay.ResponseCode = E_RESPONSE_CODE.FAIL_DESERIALIZE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resResetSinglePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        long accountId = context.Channel.GetAttrAccountId();
        if (accountId == 0)
        {
            resResetSinglePlay.ResponseCode = E_RESPONSE_CODE.INVALID_CHANNEL_ATTR;
            resPacket.PacketBody = EncUtil.EncodeBase64(resResetSinglePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // session check
        E_RESPONSE_CODE sessionResult = _CheckSession(accountId, reqResetSinglePlay.Token);
        if (sessionResult != E_RESPONSE_CODE.SUCCESS)
        {
            resResetSinglePlay.ResponseCode = sessionResult;
            resPacket.PacketBody = EncUtil.EncodeBase64(resResetSinglePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        var stoneDatas = _InitSignleGame(accountId);

        resResetSinglePlay = new ResResetSinglePlay()
        {
            ResponseCode = E_RESPONSE_CODE.SUCCESS,
            MyStoneType = E_STONE_TYPE.BLACK,   // 싱글게임은 유저가 흑돌!
            StoneDatas = stoneDatas
        };

        resPacket.PacketBody = EncUtil.EncodeBase64(resResetSinglePlay);
        ChannelManager.SendToUser(accountId, resPacket);
    }
    #endregion

    #region 대전플레이 관련
    /// <summary>
    ///  대전유니크키 생성
    /// </summary>
    private long _GenerateBattleId()
    {
        if (_battleGameDB.Count > 0)
        {
            return _battleGameDB.Keys.Max() + 1;
        }

        return 1;
    }

    /// <summary>
    ///  대전중인지 체크
    /// </summary>
    private BattleInfo _GetPlayingBattle(long accountIdList)
    {
        return _battleGameDB.Values.FirstOrDefault(v => v.BattleEntryList.Where(d => d.AccountId == accountIdList).Count() > 0);
    }

    /// <summary>
    ///  대전 초기화
    /// </summary>
    private BattleInfo _InitBattleGame(long hostAccountId, long opponentAccountId)
    {
        if (_battleGameDB.Values.Where(v => v.BattleEntryList.Where(d => d.AccountId == hostAccountId || d.AccountId == opponentAccountId).Count() > 0).Count() > 0)
        {
            return null;
        }

        long battleId = _GenerateBattleId();
        E_STONE_TYPE[,] othello = _InitGameBoard();
        List<BattleEntry> battleEntryList = new List<BattleEntry>
        {
            new BattleEntry(hostAccountId, E_STONE_TYPE.BLACK, true), // 대전게임은 호스트가 흑돌!
            new BattleEntry(opponentAccountId, E_STONE_TYPE.WHITE, false)
        };

        BattleInfo battleInfo = new BattleInfo
        {
            BattleId = battleId,
            LastPlayStoneType = E_STONE_TYPE.WHITE,    // 흑돌먼저 시작하므로 흰돌로 세팅
            BattleEntryList = battleEntryList,
            StoneDatas = othello
        };
        _battleGameDB.Add(battleId, battleInfo);

        return battleInfo;
    }

    /// <summary>
    ///  대전플레이 입장
    /// </summary>
    private void _ReqEnterBattlePlay(IChannelHandlerContext context, string packetBody)
    {
        GamePacket resPacket = new GamePacket(E_PACKET_TYPE.RES_ENTER_BATTLE_PLAY);
        ResEnterBattlePlay resEnterBattlePlay = new ResEnterBattlePlay();

        if (string.IsNullOrEmpty(packetBody))
        {
            resEnterBattlePlay.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resEnterBattlePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        ReqEnterBattlePlay reqEnterBattlePlay = EncUtil.DecodeBase64<ReqEnterBattlePlay>(packetBody);
        if (reqEnterBattlePlay == null)
        {
            resEnterBattlePlay.ResponseCode = E_RESPONSE_CODE.FAIL_DESERIALIZE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resEnterBattlePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        long accountId = context.Channel.GetAttrAccountId();
        if (accountId == 0)
        {
            resEnterBattlePlay.ResponseCode = E_RESPONSE_CODE.INVALID_CHANNEL_ATTR;
            resPacket.PacketBody = EncUtil.EncodeBase64(resEnterBattlePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // session check
        E_RESPONSE_CODE sessionResult = _CheckSession(accountId, reqEnterBattlePlay.Token);
        if (sessionResult != E_RESPONSE_CODE.SUCCESS)
        {
            resEnterBattlePlay.ResponseCode = sessionResult;
            resPacket.PacketBody = EncUtil.EncodeBase64(resEnterBattlePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        resEnterBattlePlay = new ResEnterBattlePlay
        {
            ResponseCode = E_RESPONSE_CODE.SUCCESS,
            WaitingList = _battleWaitingDB.Values.ToList()
        };

        resPacket.PacketBody = EncUtil.EncodeBase64(resEnterBattlePlay);
        ChannelManager.SendToUser(accountId, resPacket);
    }

    /// <summary>
    ///  대기방 생성
    /// </summary>
    private void _ReqCreateBattleRoom(IChannelHandlerContext context, string packetBody)
    {
        GamePacket resPacket = new GamePacket(E_PACKET_TYPE.RES_CREATE_BATTLE_ROOM);
        ResCreateBattleRoom resCreateBattleRoom = new ResCreateBattleRoom();

        if (string.IsNullOrEmpty(packetBody))
        {
            resCreateBattleRoom.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resCreateBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        ReqCreateBattleRoom reqCreateBattleRoom = EncUtil.DecodeBase64<ReqCreateBattleRoom>(packetBody);
        if (reqCreateBattleRoom == null)
        {
            resCreateBattleRoom.ResponseCode = E_RESPONSE_CODE.FAIL_DESERIALIZE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resCreateBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        long accountId = context.Channel.GetAttrAccountId();
        int serverId = context.Channel.GetAttrServerId();
        if (accountId == 0 || serverId == 0)
        {
            resCreateBattleRoom.ResponseCode = E_RESPONSE_CODE.INVALID_CHANNEL_ATTR;
            resPacket.PacketBody = EncUtil.EncodeBase64(resCreateBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // session check
        E_RESPONSE_CODE sessionResult = _CheckSession(accountId, reqCreateBattleRoom.Token);
        if (sessionResult != E_RESPONSE_CODE.SUCCESS)
        {
            resCreateBattleRoom.ResponseCode = sessionResult;
            resPacket.PacketBody = EncUtil.EncodeBase64(resCreateBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        AccountTB accountDto = _accountDbContext.SelectAccount(accountId);
        if (accountDto == null)
        {
            resCreateBattleRoom.ResponseCode = E_RESPONSE_CODE.NOT_EXIST_USER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resCreateBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        if (_battleWaitingDB.ContainsKey(accountId))
        {
            resCreateBattleRoom.ResponseCode = E_RESPONSE_CODE.ALREADY_EXIST_ROOM;
            resPacket.PacketBody = EncUtil.EncodeBase64(resCreateBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        var newWaitting = new UserInfo
        {
            AccountId = accountId,
            NIckName = accountDto.Nickname,
            Level = 1
        };
        _battleWaitingDB.Add(accountId, newWaitting);

        resCreateBattleRoom = new ResCreateBattleRoom
        {
            ResponseCode = E_RESPONSE_CODE.SUCCESS,
            WaitingUser = newWaitting
        };

        resPacket.PacketBody = EncUtil.EncodeBase64(resCreateBattleRoom);
        ChannelManager.SendToUser(accountId, resPacket);

        // publish
        _MessagePublish(
            E_BROADCAST_TYPE.SERVER, serverId,
            E_PACKET_TYPE.PS_CREATE_BATTLE_ROOM, resPacket
            );
    }

    /// <summary>
    ///  대기종료
    /// </summary>
    private void _ReqExitBattleRoom(IChannelHandlerContext context, string packetBody)
    {
        GamePacket resPacket = new GamePacket(E_PACKET_TYPE.RES_EXIT_BATTLE_ROOM);
        ResExitBattleRoom resExitBattleRoom = new ResExitBattleRoom();

        if (string.IsNullOrEmpty(packetBody))
        {
            resExitBattleRoom.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        ReqExitBattleRoom reqExitBattleRoom = EncUtil.DecodeBase64<ReqExitBattleRoom>(packetBody);
        if (reqExitBattleRoom == null)
        {
            resExitBattleRoom.ResponseCode = E_RESPONSE_CODE.FAIL_DESERIALIZE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        long accountId = context.Channel.GetAttrAccountId();
        int serverId = context.Channel.GetAttrServerId();
        if (accountId == 0 || serverId == 0)
        {
            resExitBattleRoom.ResponseCode = E_RESPONSE_CODE.INVALID_CHANNEL_ATTR;
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // session check
        E_RESPONSE_CODE sessionResult = _CheckSession(accountId, reqExitBattleRoom.Token);
        if (sessionResult != E_RESPONSE_CODE.SUCCESS)
        {
            resExitBattleRoom.ResponseCode = sessionResult;
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        UserInfo waitingUser = null;
        if (_battleWaitingDB.ContainsKey(accountId))
        {
            waitingUser = _battleWaitingDB[accountId];
            _battleWaitingDB.Remove(accountId);
        }

        resExitBattleRoom = new ResExitBattleRoom
        {
            ResponseCode = E_RESPONSE_CODE.SUCCESS,
            WaitingUser = waitingUser
        };

        resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleRoom);
        ChannelManager.SendToUser(accountId, resPacket);

        // publish
        _MessagePublish(
            E_BROADCAST_TYPE.SERVER, serverId,
            E_PACKET_TYPE.PS_EXIT_BATTLE_ROOM, resPacket
            );
    }

    /// <summary>
    ///  대전시작
    /// </summary>
    private void _ReqJoinBattleRoom(IChannelHandlerContext context, string packetBody)
    {
        GamePacket resPacket = new GamePacket(E_PACKET_TYPE.RES_JOIN_BATTLE_ROOM);
        ResJoinBattleRoom resJoinBattleRoom = new ResJoinBattleRoom();

        if (string.IsNullOrEmpty(packetBody))
        {
            resJoinBattleRoom.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resJoinBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        ReqJoinBattleRoom reqJoinBattleRoom = EncUtil.DecodeBase64<ReqJoinBattleRoom>(packetBody);
        if (reqJoinBattleRoom == null)
        {
            resJoinBattleRoom.ResponseCode = E_RESPONSE_CODE.FAIL_DESERIALIZE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resJoinBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        long accountId = context.Channel.GetAttrAccountId();
        int serverId = context.Channel.GetAttrServerId();
        if (accountId == 0 || serverId == 0)
        {
            resJoinBattleRoom.ResponseCode = E_RESPONSE_CODE.INVALID_CHANNEL_ATTR;
            resPacket.PacketBody = EncUtil.EncodeBase64(resJoinBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // session check
        E_RESPONSE_CODE sessionResult = _CheckSession(accountId, reqJoinBattleRoom.Token);
        if (sessionResult != E_RESPONSE_CODE.SUCCESS)
        {
            resJoinBattleRoom.ResponseCode = sessionResult;
            resPacket.PacketBody = EncUtil.EncodeBase64(resJoinBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        if (reqJoinBattleRoom.HostAccountId <= 0 ||
            reqJoinBattleRoom.OpponentAccountId <= 0 ||
            reqJoinBattleRoom.HostAccountId == reqJoinBattleRoom.OpponentAccountId)
        {
            resJoinBattleRoom.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resJoinBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        var battleInfo = _InitBattleGame(reqJoinBattleRoom.HostAccountId, reqJoinBattleRoom.OpponentAccountId);
        if (battleInfo == null)
        {
            resJoinBattleRoom.ResponseCode = E_RESPONSE_CODE.ALREADY_PLAYING_BATTLE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resJoinBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        long subscribeAccountId = reqJoinBattleRoom.HostAccountId;
        if (accountId == reqJoinBattleRoom.HostAccountId)
        {
            subscribeAccountId = reqJoinBattleRoom.OpponentAccountId;
        }

        // 게임이 시작됐으므로 대기목록에서 삭제
        ResExitBattleRoom resExitBattleRoom = null;
        if (_battleWaitingDB.ContainsKey(reqJoinBattleRoom.HostAccountId))
        {
            UserInfo waitingUser = _battleWaitingDB[reqJoinBattleRoom.HostAccountId];
            resExitBattleRoom = new ResExitBattleRoom
            {
                ResponseCode = E_RESPONSE_CODE.SUCCESS,
                WaitingUser = waitingUser
            };

            _battleWaitingDB.Remove(reqJoinBattleRoom.HostAccountId);
        }

        resJoinBattleRoom = new ResJoinBattleRoom
        {
            ResponseCode = E_RESPONSE_CODE.SUCCESS,
            BattleInfo = battleInfo,
        };

        resPacket.PacketBody = EncUtil.EncodeBase64(resJoinBattleRoom);
        ChannelManager.SendToUser(accountId, resPacket);

        // publish (대전시작)
        _MessagePublish(
            E_BROADCAST_TYPE.USER, subscribeAccountId,
            E_PACKET_TYPE.RES_JOIN_BATTLE_ROOM, resPacket
            );

        // publish (대기방삭제)
        if (resExitBattleRoom != null)
        {
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleRoom);

            _MessagePublish(
                E_BROADCAST_TYPE.SERVER, serverId,
                E_PACKET_TYPE.PS_EXIT_BATTLE_ROOM, resPacket
                );
        }
    }

    /// <summary>
    ///  대전 플레이 중지
    /// </summary>
    private void _ReqExitBattleJoin(IChannelHandlerContext context, string packetBody)
    {
        GamePacket resPacket = new GamePacket(E_PACKET_TYPE.RES_EXIT_BATTLE_JOIN);
        ResExitBattleJoin resExitBattleJoin = new ResExitBattleJoin();
        long subscribeAccountId = 0;

        if (string.IsNullOrEmpty(packetBody))
        {
            resExitBattleJoin.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleJoin);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        ReqExitBattleJoin reqExitBattleJoin = EncUtil.DecodeBase64<ReqExitBattleJoin>(packetBody);
        if (reqExitBattleJoin == null)
        {
            resExitBattleJoin.ResponseCode = E_RESPONSE_CODE.FAIL_DESERIALIZE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleJoin);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        if (reqExitBattleJoin.BattleId == 0)
        {
            resExitBattleJoin.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleJoin);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        long accountId = context.Channel.GetAttrAccountId();
        if (accountId == 0)
        {
            resExitBattleJoin.ResponseCode = E_RESPONSE_CODE.INVALID_CHANNEL_ATTR;
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleJoin);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // session check
        E_RESPONSE_CODE sessionResult = _CheckSession(accountId, reqExitBattleJoin.Token);
        if (sessionResult != E_RESPONSE_CODE.SUCCESS)
        {
            resExitBattleJoin.ResponseCode = sessionResult;
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleJoin);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // 대전정보 삭제
        if (_battleGameDB.ContainsKey(reqExitBattleJoin.BattleId))
        {
            subscribeAccountId = _battleGameDB[reqExitBattleJoin.BattleId].BattleEntryList.FirstOrDefault(d => d.AccountId != accountId).AccountId;
            _battleGameDB.Remove(reqExitBattleJoin.BattleId);
        }

        resExitBattleJoin = new ResExitBattleJoin
        {
            ResponseCode = E_RESPONSE_CODE.SUCCESS
        };

        resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleJoin);
        ChannelManager.SendToUser(accountId, resPacket);

        // publish
        if (subscribeAccountId > 0)
        {
            _MessagePublish(
                E_BROADCAST_TYPE.USER, subscribeAccountId,
                E_PACKET_TYPE.PS_EXIT_BATTLE_JOIN, resPacket
                );
        }
    }

    /// <summary>
    ///  대전 플레이 착수
    /// </summary>
    private void _ReqPutBattlePlayStone(IChannelHandlerContext context, string packetBody)
    {
        GamePacket resPacket = new GamePacket(E_PACKET_TYPE.RES_PUT_BATTLE_PLAY_STONE);
        ResPutBattlePlayStone resPutBattlePlayStone = new ResPutBattlePlayStone();

        if (string.IsNullOrEmpty(packetBody))
        {
            resPutBattlePlayStone.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resPutBattlePlayStone);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        ReqPutBattlePlayStone reqPutBattlePlayStone = EncUtil.DecodeBase64<ReqPutBattlePlayStone>(packetBody);
        if (reqPutBattlePlayStone == null)
        {
            resPutBattlePlayStone.ResponseCode = E_RESPONSE_CODE.FAIL_DESERIALIZE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resPutBattlePlayStone);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        if (reqPutBattlePlayStone.BattleId == 0)
        {
            resPutBattlePlayStone.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resPutBattlePlayStone);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        var lastPlayStoneType = reqPutBattlePlayStone.TurnPlayInfo.StoneType;
        var turnPlayInfo = reqPutBattlePlayStone.TurnPlayInfo;
        resPutBattlePlayStone.TurnPlayInfo = turnPlayInfo;

        if (turnPlayInfo.IndexX + 1 > _boardScale || turnPlayInfo.IndexY + 1 > _boardScale)
        {
            resPutBattlePlayStone.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resPutBattlePlayStone);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        long accountId = context.Channel.GetAttrAccountId();
        if (accountId == 0)
        {
            resPutBattlePlayStone.ResponseCode = E_RESPONSE_CODE.INVALID_CHANNEL_ATTR;
            resPacket.PacketBody = EncUtil.EncodeBase64(resPutBattlePlayStone);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // session check
        E_RESPONSE_CODE sessionResult = _CheckSession(accountId, reqPutBattlePlayStone.Token);
        if (sessionResult != E_RESPONSE_CODE.SUCCESS)
        {
            resPutBattlePlayStone.ResponseCode = sessionResult;
            resPacket.PacketBody = EncUtil.EncodeBase64(resPutBattlePlayStone);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // 턴 플레이
        bool isMyTurn = true;
        E_STONE_TYPE stoneType;
        int indexX, indexY;
        E_RESPONSE_CODE resultCode;
        for (; ; )
        {
            if (isMyTurn)
            {
                stoneType = turnPlayInfo.StoneType;
                indexX = turnPlayInfo.IndexX;
                indexY = turnPlayInfo.IndexY;
            }
            else
            {
                stoneType = GetOpponentStoneType(turnPlayInfo.StoneType);
                indexX = indexY = -1;
            }

            TurnInfo turnInfo = new TurnInfo(stoneType, indexX, indexY);

            // 패스 체크
            resultCode = _CheckPass(E_PLAY_TYPE.BATTLE, reqPutBattlePlayStone.BattleId, stoneType);
            FLogManager.Get().ServiceLog.AppendInfoLog($"[_ReqPutBattlePlayStone] stoneType [{stoneType}], indexX [{indexX}], indexY [{indexY}], Pass [{resultCode}]");
            if (resultCode != E_RESPONSE_CODE.SUCCESS)
            {
                turnInfo.TurnResult = E_TURN_RESULT.PASS;
                //resPutBattlePlayStone.TurnInfoList.Add(turnInfo);
            }
            else
            {
                if (indexX >= 0 && indexY >= 0)
                {
                    // 착수 및 뒤집기
                    resultCode = _PlayTurn(E_PLAY_TYPE.BATTLE, reqPutBattlePlayStone.BattleId, stoneType, indexX, indexY);
                    if (resultCode != E_RESPONSE_CODE.SUCCESS)
                    {
                        resPutBattlePlayStone.ResponseCode = resultCode;
                        resPacket.PacketBody = EncUtil.EncodeBase64(resPutBattlePlayStone);
                        context.Channel.WriteAndFlushAsync(resPacket);
                        return;
                    }

                    turnInfo.TurnResult = E_TURN_RESULT.NORMAL;
                    turnInfo.TurnDatas = _battleGameDB[reqPutBattlePlayStone.BattleId].StoneDatas.Clone() as E_STONE_TYPE[,];
                    //resPutBattlePlayStone.TurnInfoList.Add(turnInfo);

                    _battleGameDB[reqPutBattlePlayStone.BattleId].LastPlayStoneType = lastPlayStoneType;
                }
            }

            // 게임오버 체크
            resultCode = _CheckGameOver(E_PLAY_TYPE.BATTLE, reqPutBattlePlayStone.BattleId);
            if (resultCode != E_RESPONSE_CODE.SUCCESS)
            {
                turnInfo.TurnResult = E_TURN_RESULT.GAME_OVER;
                //resPutBattlePlayStone.TurnInfoList.Add(turnInfo);
            }

            if (indexX < 0 || indexY < 0)
            {
                break;
            }

            resPutBattlePlayStone.TurnInfoList.Add(turnInfo);
            isMyTurn = !isMyTurn;
        }

        long subscribeAccountId = _battleGameDB[reqPutBattlePlayStone.BattleId].BattleEntryList.FirstOrDefault(d => d.AccountId != accountId).AccountId;

        resPutBattlePlayStone.ResponseCode = E_RESPONSE_CODE.SUCCESS;
        resPutBattlePlayStone.BattleId = reqPutBattlePlayStone.BattleId;
        resPutBattlePlayStone.LastPlayStoneType = lastPlayStoneType;

        resPacket.PacketBody = EncUtil.EncodeBase64(resPutBattlePlayStone);
        ChannelManager.SendToUser(accountId, resPacket);

        // publish
        _MessagePublish(
            E_BROADCAST_TYPE.USER, subscribeAccountId,
            E_PACKET_TYPE.PS_PUT_BATTLE_PLAY_STONE, resPacket
            );
    }
    #endregion
}