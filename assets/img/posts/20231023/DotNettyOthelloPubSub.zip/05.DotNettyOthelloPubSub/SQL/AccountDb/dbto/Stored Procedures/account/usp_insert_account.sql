﻿CREATE PROCEDURE [dbo].[usp_insert_account]
    @nickname NVARCHAR(50),
    @reg_dt DATETIME
AS
    SET NOCOUNT ON;

	INSERT INTO dbo.account ([nickname], [reg_dt])
         VALUES (@nickname, @reg_dt);

    SELECT SCOPE_IDENTITY() AS accountId;
RETURN 0