﻿CREATE PROCEDURE [dbo].[usp_select_account_by_nickname]
    @nickname nvarchar(50)
AS
    SET NOCOUNT ON;

    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

    SELECT a.[id], a.[nickname], a.[level], a.[reg_dt]
      FROM dbo.account AS a
     WHERE a.[nickname] = @nickname;
RETURN 0