﻿CREATE TABLE [dbo].[account] (
    [id]            BIGINT        IDENTITY (1, 1) NOT NULL,
    [nickname]      NVARCHAR (50) NOT NULL,
    [level]         INT           DEFAULT (1) NOT NULL,
    [reg_dt]        DATETIME      DEFAULT (getdate()) NOT NULL,
    PRIMARY KEY CLUSTERED ([id] ASC)
);



