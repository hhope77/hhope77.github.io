﻿namespace DotNettyOthelloClient
{
    partial class frmClient
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            grpServerInfo = new GroupBox();
            txtUserNickName = new TextBox();
            lblUserNickName = new Label();
            btnDisConnect = new Button();
            btnConnect = new Button();
            txtServerPort = new TextBox();
            lblServerPort = new Label();
            lblServerIP = new Label();
            txtServerIP = new TextBox();
            lblNotify = new Label();
            grpLobby = new GroupBox();
            btnPVP = new Button();
            btnPVE = new Button();
            grpWaitingMode = new GroupBox();
            btnCancelWaiting = new Button();
            grpGameRoom = new GroupBox();
            btnExitWaiting = new Button();
            btnCreateRoom = new Button();
            lstWaiting = new ListBox();
            txtLog = new TextBox();
            grpPlay = new GroupBox();
            dgvBoard = new DataGridView();
            btnExitPlay = new Button();
            btnLogClear = new Button();
            grpServerInfo.SuspendLayout();
            grpLobby.SuspendLayout();
            grpWaitingMode.SuspendLayout();
            grpGameRoom.SuspendLayout();
            grpPlay.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvBoard).BeginInit();
            SuspendLayout();
            // 
            // grpServerInfo
            // 
            grpServerInfo.Controls.Add(txtUserNickName);
            grpServerInfo.Controls.Add(lblUserNickName);
            grpServerInfo.Controls.Add(btnDisConnect);
            grpServerInfo.Controls.Add(btnConnect);
            grpServerInfo.Controls.Add(txtServerPort);
            grpServerInfo.Controls.Add(lblServerPort);
            grpServerInfo.Controls.Add(lblServerIP);
            grpServerInfo.Controls.Add(txtServerIP);
            grpServerInfo.Location = new Point(9, 11);
            grpServerInfo.Name = "grpServerInfo";
            grpServerInfo.Size = new Size(269, 144);
            grpServerInfo.TabIndex = 0;
            grpServerInfo.TabStop = false;
            grpServerInfo.Text = "접속정보";
            // 
            // txtUserNickName
            // 
            txtUserNickName.Location = new Point(87, 77);
            txtUserNickName.Name = "txtUserNickName";
            txtUserNickName.Size = new Size(160, 23);
            txtUserNickName.TabIndex = 0;
            // 
            // lblUserNickName
            // 
            lblUserNickName.AutoSize = true;
            lblUserNickName.Location = new Point(12, 80);
            lblUserNickName.Name = "lblUserNickName";
            lblUserNickName.Size = new Size(68, 15);
            lblUserNickName.TabIndex = 4;
            lblUserNickName.Text = "Nickname :";
            // 
            // btnDisConnect
            // 
            btnDisConnect.Location = new Point(150, 109);
            btnDisConnect.Name = "btnDisConnect";
            btnDisConnect.Size = new Size(105, 30);
            btnDisConnect.TabIndex = 2;
            btnDisConnect.Text = "DisConnect";
            btnDisConnect.UseVisualStyleBackColor = true;
            btnDisConnect.Click += btnDisConnect_Click;
            // 
            // btnConnect
            // 
            btnConnect.Location = new Point(14, 109);
            btnConnect.Name = "btnConnect";
            btnConnect.Size = new Size(120, 30);
            btnConnect.TabIndex = 1;
            btnConnect.Text = "Connect";
            btnConnect.UseVisualStyleBackColor = true;
            btnConnect.Click += btnConnect_Click;
            // 
            // txtServerPort
            // 
            txtServerPort.Location = new Point(87, 48);
            txtServerPort.Name = "txtServerPort";
            txtServerPort.Size = new Size(80, 23);
            txtServerPort.TabIndex = 4;
            txtServerPort.TabStop = false;
            // 
            // lblServerPort
            // 
            lblServerPort.AutoSize = true;
            lblServerPort.Location = new Point(12, 48);
            lblServerPort.Name = "lblServerPort";
            lblServerPort.Size = new Size(69, 15);
            lblServerPort.TabIndex = 2;
            lblServerPort.Text = "ServerPort :";
            // 
            // lblServerIP
            // 
            lblServerIP.AutoSize = true;
            lblServerIP.Location = new Point(24, 22);
            lblServerIP.Name = "lblServerIP";
            lblServerIP.Size = new Size(57, 15);
            lblServerIP.TabIndex = 1;
            lblServerIP.Text = "ServerIP :";
            // 
            // txtServerIP
            // 
            txtServerIP.Location = new Point(87, 19);
            txtServerIP.Name = "txtServerIP";
            txtServerIP.Size = new Size(160, 23);
            txtServerIP.TabIndex = 3;
            // 
            // lblNotify
            // 
            lblNotify.BackColor = SystemColors.ControlLight;
            lblNotify.Location = new Point(5, 18);
            lblNotify.Name = "lblNotify";
            lblNotify.Size = new Size(350, 20);
            lblNotify.TabIndex = 1;
            // 
            // grpLobby
            // 
            grpLobby.Controls.Add(btnPVP);
            grpLobby.Controls.Add(btnPVE);
            grpLobby.Controls.Add(lblNotify);
            grpLobby.Location = new Point(290, 11);
            grpLobby.Name = "grpLobby";
            grpLobby.Size = new Size(360, 111);
            grpLobby.TabIndex = 2;
            grpLobby.TabStop = false;
            grpLobby.Text = "로비";
            // 
            // btnPVP
            // 
            btnPVP.Location = new Point(173, 48);
            btnPVP.Name = "btnPVP";
            btnPVP.Size = new Size(100, 45);
            btnPVP.TabIndex = 3;
            btnPVP.Text = "Battle Play";
            btnPVP.UseVisualStyleBackColor = true;
            btnPVP.Click += btnPVP_Click;
            // 
            // btnPVE
            // 
            btnPVE.Location = new Point(60, 48);
            btnPVE.Name = "btnPVE";
            btnPVE.Size = new Size(100, 45);
            btnPVE.TabIndex = 2;
            btnPVE.Text = "Single Play";
            btnPVE.UseVisualStyleBackColor = true;
            btnPVE.Click += btnPVE_Click;
            // 
            // grpWaitingMode
            // 
            grpWaitingMode.Controls.Add(btnCancelWaiting);
            grpWaitingMode.Location = new Point(308, 129);
            grpWaitingMode.Name = "grpWaitingMode";
            grpWaitingMode.Size = new Size(324, 57);
            grpWaitingMode.TabIndex = 7;
            grpWaitingMode.TabStop = false;
            grpWaitingMode.Text = "대전상대를 기다립니다...";
            // 
            // btnCancelWaiting
            // 
            btnCancelWaiting.Location = new Point(114, 22);
            btnCancelWaiting.Name = "btnCancelWaiting";
            btnCancelWaiting.Size = new Size(100, 24);
            btnCancelWaiting.TabIndex = 0;
            btnCancelWaiting.Text = "취소";
            btnCancelWaiting.UseVisualStyleBackColor = true;
            btnCancelWaiting.Click += btnCancelWaiting_Click;
            // 
            // grpGameRoom
            // 
            grpGameRoom.Controls.Add(btnExitWaiting);
            grpGameRoom.Controls.Add(btnCreateRoom);
            grpGameRoom.Controls.Add(lstWaiting);
            grpGameRoom.Location = new Point(660, 11);
            grpGameRoom.Name = "grpGameRoom";
            grpGameRoom.Size = new Size(150, 501);
            grpGameRoom.TabIndex = 3;
            grpGameRoom.TabStop = false;
            grpGameRoom.Text = "게임 대기방";
            // 
            // btnExitWaiting
            // 
            btnExitWaiting.Location = new Point(124, 27);
            btnExitWaiting.Name = "btnExitWaiting";
            btnExitWaiting.Size = new Size(20, 20);
            btnExitWaiting.TabIndex = 2;
            btnExitWaiting.Text = "X";
            btnExitWaiting.UseVisualStyleBackColor = true;
            btnExitWaiting.Click += btnExitWaiting_Click;
            // 
            // btnCreateRoom
            // 
            btnCreateRoom.Location = new Point(6, 25);
            btnCreateRoom.Name = "btnCreateRoom";
            btnCreateRoom.Size = new Size(92, 24);
            btnCreateRoom.TabIndex = 1;
            btnCreateRoom.Text = "방 만들기";
            btnCreateRoom.UseVisualStyleBackColor = true;
            btnCreateRoom.Click += btnCreateRoom_Click;
            // 
            // lstWaiting
            // 
            lstWaiting.FormattingEnabled = true;
            lstWaiting.ItemHeight = 15;
            lstWaiting.Location = new Point(6, 64);
            lstWaiting.Name = "lstWaiting";
            lstWaiting.Size = new Size(138, 424);
            lstWaiting.TabIndex = 0;
            lstWaiting.Click += lstWaiting_Click;
            // 
            // txtLog
            // 
            txtLog.Location = new Point(9, 161);
            txtLog.Multiline = true;
            txtLog.Name = "txtLog";
            txtLog.ReadOnly = true;
            txtLog.ScrollBars = ScrollBars.Vertical;
            txtLog.Size = new Size(269, 316);
            txtLog.TabIndex = 4;
            txtLog.TabStop = false;
            // 
            // grpPlay
            // 
            grpPlay.Controls.Add(dgvBoard);
            grpPlay.Controls.Add(btnExitPlay);
            grpPlay.Location = new Point(290, 191);
            grpPlay.Name = "grpPlay";
            grpPlay.Size = new Size(360, 321);
            grpPlay.TabIndex = 5;
            grpPlay.TabStop = false;
            grpPlay.Text = "대전";
            // 
            // dgvBoard
            // 
            dgvBoard.AllowUserToAddRows = false;
            dgvBoard.AllowUserToDeleteRows = false;
            dgvBoard.AllowUserToResizeColumns = false;
            dgvBoard.AllowUserToResizeRows = false;
            dgvBoard.BackgroundColor = Color.White;
            dgvBoard.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dgvBoard.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvBoard.ColumnHeadersVisible = false;
            dgvBoard.Cursor = Cursors.Hand;
            dgvBoard.GridColor = Color.Black;
            dgvBoard.Location = new Point(35, 24);
            dgvBoard.Margin = new Padding(5, 5, 5, 1);
            dgvBoard.MultiSelect = false;
            dgvBoard.Name = "dgvBoard";
            dgvBoard.ReadOnly = true;
            dgvBoard.RowHeadersVisible = false;
            dgvBoard.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dgvBoard.RowTemplate.Height = 25;
            dgvBoard.ScrollBars = ScrollBars.None;
            dgvBoard.SelectionMode = DataGridViewSelectionMode.CellSelect;
            dgvBoard.Size = new Size(280, 280);
            dgvBoard.TabIndex = 0;
            dgvBoard.TabStop = false;
            dgvBoard.CellMouseDown += dgvBoard_CellMouseDown;
            dgvBoard.CellMouseUp += dgvBoard_CellMouseUp;
            // 
            // btnExitPlay
            // 
            btnExitPlay.Location = new Point(336, 13);
            btnExitPlay.Margin = new Padding(0);
            btnExitPlay.Name = "btnExitPlay";
            btnExitPlay.Size = new Size(20, 20);
            btnExitPlay.TabIndex = 0;
            btnExitPlay.Text = "X";
            btnExitPlay.UseVisualStyleBackColor = true;
            btnExitPlay.Click += btnExitPlay_Click;
            // 
            // btnLogClear
            // 
            btnLogClear.Location = new Point(78, 483);
            btnLogClear.Name = "btnLogClear";
            btnLogClear.Size = new Size(118, 29);
            btnLogClear.TabIndex = 6;
            btnLogClear.Text = "Clear Log";
            btnLogClear.UseVisualStyleBackColor = true;
            btnLogClear.Click += btnLogClear_Click;
            // 
            // frmClient
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(815, 521);
            Controls.Add(grpWaitingMode);
            Controls.Add(btnLogClear);
            Controls.Add(grpPlay);
            Controls.Add(txtLog);
            Controls.Add(grpGameRoom);
            Controls.Add(grpLobby);
            Controls.Add(grpServerInfo);
            Name = "frmClient";
            Text = "Othello Game Client";
            grpServerInfo.ResumeLayout(false);
            grpServerInfo.PerformLayout();
            grpLobby.ResumeLayout(false);
            grpWaitingMode.ResumeLayout(false);
            grpGameRoom.ResumeLayout(false);
            grpPlay.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvBoard).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox grpServerInfo;
        private Button btnDisConnect;
        private Button btnConnect;
        private TextBox txtServerPort;
        private Label lblServerPort;
        private Label lblServerIP;
        private TextBox txtServerIP;
        private Label lblNotify;
        private GroupBox grpLobby;
        private Button btnPVP;
        private Button btnPVE;
        private GroupBox grpGameRoom;
        private ListBox lstWaiting;
        private TextBox txtLog;
        private TextBox txtUserNickName;
        private Label lblUserNickName;
        private GroupBox grpPlay;
        private Button btnExitPlay;
        private DataGridView dgvBoard;
        private Button btnLogClear;
        private Button btnCreateRoom;
        private Button btnExitWaiting;
        private GroupBox grpWaitingMode;
        private Button btnCancelWaiting;
    }
}