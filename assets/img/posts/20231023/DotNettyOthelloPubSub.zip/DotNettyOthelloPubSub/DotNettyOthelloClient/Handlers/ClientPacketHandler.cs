﻿using DotNetty.Transport.Channels;
using DotNettyOthelloLib.Log.FileLog;
using Snowpipe;

namespace DotNettyOthelloClient.Handlers
{
    public partial class ClientPacketHandler : SimpleChannelInboundHandler<GamePacket>
    {
        private readonly IDispatcherHandler.ClientDispatch _clientDispatch = null;

        public ClientPacketHandler()
        {

        }

        public ClientPacketHandler(IDispatcherHandler.ClientDispatch clientDispatch)
        {
            _clientDispatch = clientDispatch;
        }

        protected override void ChannelRead0(IChannelHandlerContext ctx, GamePacket gamePacket)
        {
            _clientDispatch(gamePacket);
        }

        public override void ChannelReadComplete(IChannelHandlerContext context)
        {

        }

        public override void ExceptionCaught(IChannelHandlerContext context, Exception ex)
        {
            string exMessage = $"{ex.Message}\n{ex.StackTrace}";
            FLogManager.Get().ServiceLog.AppendFatalLog(exMessage);
            context.CloseAsync();
        }
    }
}
