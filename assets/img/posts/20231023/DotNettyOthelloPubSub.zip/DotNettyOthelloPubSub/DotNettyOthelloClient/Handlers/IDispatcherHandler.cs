﻿using Snowpipe;

namespace DotNettyOthelloClient.Handlers
{
    public interface IDispatcherHandler
    {
        public delegate void ClientDispatch(GamePacket gamePacket);
    }
}
