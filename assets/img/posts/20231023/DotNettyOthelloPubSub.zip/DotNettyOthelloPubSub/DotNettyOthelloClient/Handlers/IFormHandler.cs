﻿using DotNettyOthelloClient.Data;
using Snowpipe;

namespace DotNettyOthelloClient.Handlers
{
    public interface IFormHandler
    {
        public void WriteFormLog(string logMessage);

        public string ReadUserNickname();

        public void ShowHideGroupBox(E_UI ui);

        public void ShowAlertMessage(string message);

        public void NotifyMessage(string message);

        public void GenerateBoard(E_STONE_TYPE myStoneType, E_STONE_TYPE[,] stoneDatas);

        public void DrawBoard(E_PLAY_TYPE playType, List<TurnInfo> turnInfoList);

        public void RollBackStone(PlayInfo playInfo);

        public void InitWaitingList(List<UserInfo> waitingList);

        public void AddWaitting(UserInfo newWaitting);

        public void RemoveWaitting(long hostAccountId);

        public void SetLastPlayStone(E_STONE_TYPE stoneType);

        public void SetBattleId(long battleId);
    }
}
