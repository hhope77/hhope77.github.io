﻿namespace DotNettyOthelloLib.Data;

public class ServerConstants
{

}

public enum E_BROADCAST_TYPE
{
    NONE = 0,
    EVERYONE = 1,
    EVERYONE_BUT_ME = 2,
    SERVER = 3,
    USER_LIST = 4,
    USER = 5,
}

public enum E_DIRECTION
{
    NORTH = 1,
    NORTH_EAST = 2,
    EAST = 3,
    SOUTH_EAST = 4,
    SOUTH = 5,
    SOUTH_WEST = 6,
    WEST = 7,
    NORTH_WEST = 8,
}
