﻿using DotNettyOthelloLib.Extensions;
using Microsoft.EntityFrameworkCore;

namespace DotNettyOthelloLib.Db;

public partial class AccountDbContext : DbContext
{
    #region DECLARE DbSet
    public virtual DbSet<AccountTB> Accounts { get; set; }
    #endregion

    public AccountDbContext(DbContextOptions<AccountDbContext> options)
        : base(options)
    {
        ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
    }

    #region Account 관련
    public AccountTB SelectAccount(long accountId)
    {
        return Accounts.FromSql($"dbo.[usp_select_account_by_id] {accountId}").ToList().FirstOrDefault();
    }

    public AccountTB SelectAccount(string nickname)
    {
        return Accounts.FromSql($"dbo.[usp_select_account_by_nickname] {nickname}").ToList().FirstOrDefault();
    }

    public long InsertAccount(string nickname)
    {
        var accountId = Database.ExecuteProcedure<decimal>($"dbo.[usp_insert_account] {nickname}, {Common.ServerDateTime.Now}");
        return Convert.ToInt64(accountId);
    }
    #endregion
}
