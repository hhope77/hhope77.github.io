﻿using DotNettyOthelloLib.Helpers;
using log4net.Config;

namespace DotNettyOthelloLib.Log.FileLog;

public class FLogManager
{
    private static FLogManager _instance;
    private static readonly object _locker = new object();
    public FLog ServiceLog = null;

    public static FLogManager Get()
    {
        lock (_locker)
        {
            if (_instance == null)
            {
                _instance = new FLogManager();
            }

            return _instance;
        }
    }

    public FLogManager()
    {
        string configPath = Path.Combine(ConfigHelper.ProcessDirectory, "config/log4netConfig.xml");

        if (string.IsNullOrEmpty(configPath))
        {
            Console.WriteLine("!!!!!!!!!! A fatal error was encountered - check log4net config file !!!!!!!!!!");
            return;
        }

        XmlConfigurator.Configure(new FileInfo(configPath));

        ServiceLog = new FLog("Service");
    }
}
