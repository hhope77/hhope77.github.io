﻿namespace Snowpipe
{
    public class ReqCreateBattleRoom : ReqBase
    {

    }

    public class ResCreateBattleRoom : ResBase
    {
        public UserInfo WaitingUser { get; set; }

        public ResCreateBattleRoom() : base()
        {

        }
    }
}
