﻿namespace Snowpipe
{
    public class ReqExitBattleJoin : ReqBase
    {
        public long BattleId { get; set; }
    }

    public class ResExitBattleJoin : ResBase
    {
        public ResExitBattleJoin() : base()
        {

        }
    }
}
