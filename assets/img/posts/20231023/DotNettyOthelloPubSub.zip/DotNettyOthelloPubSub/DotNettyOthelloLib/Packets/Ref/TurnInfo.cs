﻿namespace Snowpipe
{
    public class TurnInfo
    {
        public E_STONE_TYPE StoneType { get; set; }
        public int IndexX { get; set; }
        public int IndexY { get; set; }
        public E_TURN_RESULT TurnResult { get; set; }
        public E_STONE_TYPE[,] TurnDatas { get; set; }

        public TurnInfo()
        {

        }

        public TurnInfo(E_STONE_TYPE stoneType)
        {
            StoneType = stoneType;
            IndexX = -1;
            IndexY = -1;
            TurnResult = E_TURN_RESULT.NONE;
            TurnDatas = null;
        }

        public TurnInfo(
            E_STONE_TYPE stoneType, int indexX, int indexY
            )
        {
            StoneType = stoneType;
            IndexX = indexX;
            IndexY = indexY;
            TurnResult = E_TURN_RESULT.NONE;
            TurnDatas = null;
        }

        public TurnInfo(
            E_STONE_TYPE stoneType, int indexX, int indexY
            , E_TURN_RESULT trunResult
            , E_STONE_TYPE[,] turnDatas
            )
        {
            StoneType = stoneType;
            IndexX = indexX;
            IndexY = indexY;
            TurnResult = trunResult;
            TurnDatas = turnDatas;
        }
    }
}
