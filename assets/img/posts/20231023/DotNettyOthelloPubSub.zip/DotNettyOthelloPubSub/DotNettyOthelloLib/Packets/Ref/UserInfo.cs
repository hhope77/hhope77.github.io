﻿namespace Snowpipe
{
    public class UserInfo
    {
        public long AccountId { get; set; }
        public string NIckName { get; set; }
        public int Level { get; set; }
    }
}
