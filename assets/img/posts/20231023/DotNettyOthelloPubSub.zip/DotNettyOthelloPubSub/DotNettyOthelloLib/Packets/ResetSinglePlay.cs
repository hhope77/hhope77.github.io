﻿namespace Snowpipe
{
    public class ReqResetSinglePlay : ReqBase
    {

    }

    public class ResResetSinglePlay : ResBase
    {
        public E_STONE_TYPE MyStoneType { get; set; }
        public E_STONE_TYPE[,] StoneDatas { get; set; }

        public ResResetSinglePlay() : base()
        {

        }
    }
}
