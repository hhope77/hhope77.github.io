﻿namespace Snowpipe
{
    public class ReqUserLogin
    {
        public string NickName { get; set; }
    }

    public class ResUserLogin : ResBase
    {
        public long AccountId { get; set; }
        public string Token { get; set; }
        public string NickName { get; set; }

        public ResUserLogin() : base()
        {

        }
    }
}
