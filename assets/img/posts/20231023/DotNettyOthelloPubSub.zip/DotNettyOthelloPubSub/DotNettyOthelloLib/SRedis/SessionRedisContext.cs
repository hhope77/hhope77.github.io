﻿using DotNettyOthelloLib.Data;

namespace DotNettyOthelloLib.SRedis;

public class SessionRedisContext : RedisContext
{
    public SessionRedisContext(string connectionString)
        : base(connectionString, Data.E_REDIS_DATABASE.SESSION)
    {

    }

    public void SetSessionToken(long accountId, string sessionToken)
    {
        var redisKey = string.Format(RedisKeyConstants.SessionToken, accountId);
        SetEx(redisKey, sessionToken, (int)E_REDIS_EXPIRED.FIVE_MINUTES);
    }

    public bool CheckSessionToken(long accountId, string sessionToken)
    {
        var redisKey = string.Format(RedisKeyConstants.SessionToken, accountId);
        return Get(redisKey) == sessionToken;
    }

    public void UpdateSessionTokenExpiry(long accountId)
    {
        var redisKey = string.Format(RedisKeyConstants.SessionToken, accountId);
        Expire(redisKey, (int)E_REDIS_EXPIRED.FIVE_MINUTES);
    }
}
