﻿using DotNetty.Transport.Channels;
using DotNettyOthelloLib.Channel;
using DotNettyOthelloLib.Extensions;
using Snowpipe;

namespace DotNettyOthelloServer.Handlers;

public partial class ServerPacketHandler : SimpleChannelInboundHandler<GamePacket>
{
    private int _allConnectionCnt = 0;

    /// <summary>
    ///  클라이언트 접속시
    /// </summary>
    public override void ChannelActive(IChannelHandlerContext context)
    {
        _allConnectionCnt++;
        Console.WriteLine($"connected new client - allConnectionCnt [{_allConnectionCnt}]");
    }

    /// <summary>
    ///  클라이언트 접속종료시
    /// </summary>
    public override void ChannelInactive(IChannelHandlerContext context)
    {
        _allConnectionCnt--;

        long accountId = context.Channel.GetAttrAccountId();
        int serverId = context.Channel.GetAttrServerId();

        if (accountId > 0)
        {
            // 대기중인 PVP 가 있으면 삭제
            if (_battleWaitingDB.ContainsKey(serverId))
            {
                _battleWaitingDB.Remove(serverId);
            }

            // 대전중인 PVP가 있으면 삭제
            var battleInfo = this._GetPlayingBattle(serverId);
            if (battleInfo != null && battleInfo.BattleId > 0)
            {
                _battleGameDB.Remove(battleInfo.BattleId);
            }
        }

        ChannelManager.RemoveChannel(context);

        Console.WriteLine("disconnected client - " +
            $"_allConnection [{_allConnectionCnt}], " +
            $"_allConnectionGroup [{ChannelManager.GetAllChannelCount()}], " +
            $"_serverChannelGroupDic({serverId}) [{ChannelManager.GetServerChannelCount(serverId)}], " +
            $"_userChannelDic [{ChannelManager.GetUserChannelCount()}]"
            );
    }

    /// <summary>
    ///  메세지 수신시
    /// </summary>
    protected override void ChannelRead0(IChannelHandlerContext context, GamePacket reqGamePacket)
    {
        Console.WriteLine($"Received Packet - {reqGamePacket.PacketType} [{reqGamePacket.PacketBody}]");
        _ServerDispatch(context, reqGamePacket);
    }

    /// <summary>
    ///  메세지 수신완료시
    /// </summary>
    public override void ChannelReadComplete(IChannelHandlerContext context)
    {
        context.Flush();
    }

    /// <summary>
    ///  에러발생시
    /// </summary>
    public override void ExceptionCaught(IChannelHandlerContext context, Exception ex)
    {
        Console.WriteLine("!!!!!!!!!!!!!!! ExceptionCaught !!!!!!!!!!!!!!!");
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine($"{ex.Message}\n\n{ex.StackTrace}\n{ex.Source}");
        Console.ResetColor();
        context.CloseAsync();
    }

    public override bool IsSharable => true;
}