using CheckerboardClient.Data;
using CheckerboardClient.Handlers;
using CheckerboardClient.Models;
using Snowpipe;

namespace CheckerboardClient
{
    public partial class frmClient : Form, IFormHandler
    {
        GameClient _gameClient = null;

        int _myCharacterId, _myLp;
        long _battleId, _pvpLastPlayAccountId;
        BattleEntry _myEntry, _targetEntry;

        public frmClient()
        {
            InitializeComponent();
            ConfigHelper.Load();
            TableManager.Load();
            _InitUI();
            _gameClient = new GameClient(this);
        }

        /// <summary>
        ///  Set Interval 
        /// </summary>
        private void Wait(int milliseconds)
        {
            var timer = new System.Windows.Forms.Timer();
            if (milliseconds == 0 || milliseconds < 0) return;

            timer.Interval = milliseconds;
            timer.Enabled = true;
            timer.Start();

            timer.Tick += (s, e) =>
            {
                timer.Enabled = false;
                timer.Stop();
            };

            while (timer.Enabled)
            {
                Application.DoEvents();
            }
        }

        /// <summary>
        ///  UI �ʱ�ȭ
        /// </summary>
        private void _InitUI()
        {
            ShowHideGroupBox(E_UI.NONE);

            // ���Ӽ������� ����
            txtServerIP.Text = ConfigHelper.ServerIP;
            txtServerPort.Text = ConfigHelper.ServerPort.ToString();

            // ĳ���� ���� ����
            foreach (var CharBasicDT in TableManager.CharBasicMetaData.DicData.Values)
            {
                cboCharacter.Items.Add(new ListBoxItem
                {
                    Name = CharBasicDT.Name,
                    Value = CharBasicDT.Id.ToString(),
                });
            }
            cboCharacter.SelectedIndex = 0;
        }

        /// <summary>
        ///  �ܰ躰 �׷�ڽ� ����/�����
        /// </summary>
        public void ShowHideGroupBox(E_UI ui)
        {
            bool showGrpLobby = false;
            bool showGrpGameRoom = false;
            bool showGrpWaitingMode = false;
            bool showGrpPlay = false;

            bool enableBtnConect = false;
            bool enableBtnPlay = false;

            if (ui == E_UI.LOBBY)
            {
                showGrpLobby = true;
                enableBtnPlay = true;
            }
            else if (ui == E_UI.BATTLE_PLAY)
            {
                showGrpGameRoom = true;
            }
            else if (ui == E_UI.BATTLE_ROOM)
            {
                showGrpWaitingMode = true;
            }
            else if (ui == E_UI.BATTLE_JOIN)
            {
                showGrpPlay = true;
            }
            else
            {
                enableBtnConect = true;
            }

            // Lobby GroupBox
            if (grpLobby.InvokeRequired)
            {
                grpLobby.Invoke(new MethodInvoker(delegate
                {
                    grpLobby.Visible = showGrpLobby;
                }));
            }
            else
            {
                grpLobby.Visible = showGrpLobby;
            }

            // Battle Waitting List GroupBox
            if (grpGameRoom.InvokeRequired)
            {
                grpGameRoom.Invoke(new MethodInvoker(delegate
                {
                    grpGameRoom.Visible = showGrpGameRoom;
                }));
            }
            else
            {
                grpGameRoom.Visible = showGrpGameRoom;
            }

            // Battle Waitting GroupBox
            if (grpWaitingMode.InvokeRequired)
            {
                grpWaitingMode.Invoke(new MethodInvoker(delegate
                {
                    grpWaitingMode.Visible = showGrpWaitingMode;
                }));
            }
            else
            {
                grpWaitingMode.Visible = showGrpWaitingMode;
            }

            // Game Play GroupBox
            if (grpPlay.InvokeRequired)
            {
                grpPlay.Invoke(new MethodInvoker(delegate
                {
                    grpPlay.Visible = showGrpPlay;
                }));
            }
            else
            {
                grpPlay.Visible = showGrpPlay;
            }

            // Connect Button
            if (btnConnect.InvokeRequired)
            {
                btnConnect.Invoke(new MethodInvoker(delegate
                {
                    btnConnect.Enabled = enableBtnConect;
                }));
            }
            else
            {
                btnConnect.Enabled = enableBtnConect;
            }

            // Disconnect Button
            if (btnDisConnect.InvokeRequired)
            {
                btnDisConnect.Invoke(new MethodInvoker(delegate
                {
                    btnDisConnect.Enabled = !enableBtnConect;
                }));
            }
            else
            {
                btnDisConnect.Enabled = !enableBtnConect;
            }

            // Play Button
            if (btnPlay.InvokeRequired)
            {
                btnPlay.Invoke(new MethodInvoker(delegate
                {
                    btnPlay.Enabled = enableBtnPlay;
                }));
            }
            else
            {
                btnPlay.Enabled = enableBtnPlay;
            }
        }

        #region �������� ����
        public void ShowAlertMessage(string message)
        {
            MessageBox.Show(message);
        }

        public void NotifyMessage(string message)
        {
            if (lblNotify.InvokeRequired)
            {
                lblNotify.Invoke(new MethodInvoker(delegate
                {
                    lblNotify.Text = $" {message}";
                    Wait(2000);
                    lblNotify.Text = "";
                }));
            }
            else
            {
                lblNotify.Text = $" {message}";
                Wait(2000);
                lblNotify.Text = "";
            }
        }

        /// <summary>
        ///  ���� ����Ʈ
        /// </summary>
        public void InitWaitingList(List<UserInfo> waitingList)
        {
            if (lstWaiting.InvokeRequired)
            {
                lstWaiting.Invoke(new MethodInvoker(delegate
                {
                    lstWaiting.Items.Clear();
                }));
            }
            else
            {
                lstWaiting.Items.Clear();
            }

            if (waitingList.Count > 0)
            {
                foreach (var waitingUser in waitingList)
                {
                    AddWaitting(waitingUser);
                }
            }
        }

        /// <summary>
        ///  �ű� ���� �߰�
        /// </summary>
        public void AddWaitting(UserInfo waitingUser)
        {
            foreach (var item in lstWaiting.Items)
            {
                var data = item as ListBoxItem;
                if (data.Value == waitingUser.AccountId.ToString())
                {
                    return;
                }
            }

            string characterName = DataTableHelper.GetCharacterName(waitingUser.Character.CharacterId);

            if (lstWaiting.InvokeRequired)
            {
                lstWaiting.Invoke(new MethodInvoker(delegate
                {
                    lstWaiting.Items.Add(new ListBoxItem
                    {
                        Name = string.Format("{0} ({1} - Lv.{2})", waitingUser.NIckName, characterName, waitingUser.Level),
                        Value = waitingUser.AccountId.ToString()
                    });
                }));
            }
            else
            {
                lstWaiting.Items.Add(new ListBoxItem
                {
                    Name = string.Format("{0} ({1} - Lv.{2})", waitingUser.NIckName, characterName, waitingUser.Level),
                    Value = waitingUser.AccountId.ToString()
                });
            }
        }

        /// <summary>
        ///  ���� ����
        /// </summary>
        public void RemoveWaitting(long hostAccountId)
        {
            if (hostAccountId > 0)
            {
                foreach (var item in lstWaiting.Items)
                {
                    var data = item as ListBoxItem;
                    if (data.Value == hostAccountId.ToString())
                    {
                        if (lstWaiting.InvokeRequired)
                        {
                            lstWaiting.Invoke(new MethodInvoker(delegate
                            {
                                lstWaiting.Items.Remove(item);
                            }));
                        }
                        else
                        {
                            lstWaiting.Items.Remove(item);
                        }

                        break;
                    }
                }
            }
        }

        public void SetBattleId(long battleId)
        {
            _battleId = battleId;
        }

        public void SetLastPlayAccountId(long accountId)
        {
            this._pvpLastPlayAccountId = accountId;
        }

        public void SetBattleLP(bool isHost, E_BATTLE_RESULT battleResult, List<BattleEntry> battleEntryList)
        {
            //bool isWin = false;
            var hostEntry = battleEntryList.FirstOrDefault(x => x.IsHost == true);
            var opponentEntry = battleEntryList.FirstOrDefault(x => x.IsHost == false);
            string hostCharacterName = DataTableHelper.GetCharacterName(hostEntry.CharacterId);
            string opponentCharacterName = DataTableHelper.GetCharacterName(opponentEntry.CharacterId);

            if (isHost)
            {
                _myEntry = hostEntry;
                _targetEntry = opponentEntry;
            }
            else
            {
                _myEntry = opponentEntry;
                _targetEntry = hostEntry;
            }

            if (lblHostLp.InvokeRequired)
            {
                lblHostLp.Invoke(new MethodInvoker(delegate
                {
                    lblHostLp.Text = $"{hostCharacterName} : {hostEntry.BattleLp}";
                }));
            }
            else
            {
                lblHostLp.Text = $"{hostCharacterName} : {hostEntry.BattleLp}";
            }

            if (lblOpponentLp.InvokeRequired)
            {
                lblOpponentLp.Invoke(new MethodInvoker(delegate
                {
                    lblOpponentLp.Text = $"{opponentCharacterName} : {opponentEntry.BattleLp}";
                }));
            }
            else
            {
                lblOpponentLp.Text = $"{opponentCharacterName} : {opponentEntry.BattleLp}";
            }

            if (battleResult == E_BATTLE_RESULT.GAME_OVER)
            {
                string resultMsg = $"GAME OVER - {DataTableHelper.GetCharacterName(_myEntry.CharacterId)} {(_myEntry.BattleLp == 0 ? "LOSE" : "WIN")}";
                MessageBox.Show(resultMsg);

                if (btnExitPlay.InvokeRequired)
                {
                    btnExitPlay.Invoke(new MethodInvoker(delegate
                    {
                        btnExitPlay.PerformClick();
                    }));
                }
                else
                {
                    btnExitPlay.PerformClick();
                }
            }
            else
            {
                MessageBox.Show("����� �������� �������� �Ծ����ϴ�");
            }
        }

        public void SetLP(int lp)
        {
            _myLp = lp;

            if (lblLpValue.InvokeRequired)
            {
                lblLpValue.Invoke(new MethodInvoker(delegate
                {
                    lblLpValue.Text = lp.ToString();
                }));
            }
            else
            {
                lblLpValue.Text = lp.ToString();
            }
        }

        public void SetBattleGameOver()
        {
            _battleId = 0;
            _pvpLastPlayAccountId = 0;
            _myEntry = null;
            _targetEntry = null;

            ShowHideGroupBox(E_UI.BATTLE_PLAY);
        }
        #endregion

        #region �αװ���
        /// <summary>
        ///  �α׾���
        /// </summary>
        public void WriteFormLog(string logMessage)
        {
            if (txtLog.InvokeRequired)
            {
                txtLog.Invoke(new MethodInvoker(delegate
                {
                    txtLog.Text += logMessage + Environment.NewLine + Environment.NewLine;
                }));
            }
            else
            {
                txtLog.Text += logMessage + Environment.NewLine + Environment.NewLine;
            }
        }

        /// <summary>
        ///  �α������
        /// </summary>
        private void btnLogClear_Click(object sender, EventArgs e)
        {
            txtLog.Clear();
        }
        #endregion

        #region ���Ӱ���
        /// <summary>
        ///  �г��Ӱ� �б�
        /// </summary>
        public string ReadUserNickname()
        {
            return txtUserNickName.Text;
        }

        /// <summary>
        ///  ��������
        /// </summary>
        private async void btnConnect_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtServerIP.Text)
                || string.IsNullOrEmpty(txtServerPort.Text)
                || Int32.TryParse(txtServerPort.Text, out int targetServerPort) == false)
            {
                MessageBox.Show("�ùٸ� ���������� �Է����ּ���");
                return;
            }

            string userNickName = txtUserNickName.Text;
            if (string.IsNullOrEmpty(userNickName))
            {
                MessageBox.Show("���� �г����� �Է����ּ���");
                return;
            }

            await _gameClient.RunAsync();
        }

        /// <summary>
        ///  ������������
        /// </summary>
        private async void btnDisConnect_Click(object sender, EventArgs e)
        {
            await _gameClient.StopAsync();
        }
        #endregion

        #region �κ����
        /// <summary>
        ///  ���� ����
        /// </summary>
        private async void btnPlay_Click(object sender, EventArgs e)
        {
            ListBoxItem item = cboCharacter.SelectedItem as ListBoxItem;
            if (item != null)
            {
                if (Int32.TryParse(item.Value, out int characterId))
                {
                    if (characterId == 0)
                    {
                        MessageBox.Show("ĳ���͸� �������ּ���");
                        return;
                    }

                    _myCharacterId = characterId;
                    _battleId = 0;
                    await _gameClient.EnterBattlePlayAsync(_myCharacterId);
                }
            }
        }
        #endregion

        #region �������
        /// <summary>
        /// ���� �����
        /// </summary>
        private async void btnCreateRoom_Click(object sender, EventArgs e)
        {
            if (_myLp <= Constants.BATTLE_LP_GAUGE)
            {
                MessageBox.Show("LP�� �����մϴ�.");
                return;
            }

            await _gameClient.CreateBattleRoomAsync(_myCharacterId);
        }

        /// <summary>
        ///  ���� �������
        /// </summary>
        private async void btnCancelWaiting_Click(object sender, EventArgs e)
        {
            await _gameClient.ExitBattleRoomAsync();
        }

        /// <summary>
        ///  ���� ����
        /// </summary>
        private async void lstWaiting_Click(object sender, EventArgs e)
        {
            if (_myLp < Constants.BATTLE_LP_GAUGE)
            {
                MessageBox.Show("LP�� �����մϴ�.");
                return;
            }

            ListBox lb = sender as ListBox;
            if (lb != null)
            {
                ListBoxItem item = lb.SelectedItem as ListBoxItem;
                if (item != null)
                {
                    if (MessageBox.Show($"{item.Name} �� �÷��� �Ͻðڽ��ϱ�?", "���� ����", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        if (Int64.TryParse(item.Value, out long hostAccountId) != false)
                        {
                            await _gameClient.JoinBattleRoomAsync(hostAccountId, _myCharacterId);
                        }
                    }
                }
            }
        }
        #endregion

        #region �����÷��̰���
        /// <summary>
        /// ĳ���� ��ǥ������ȸ
        /// </summary>
        private Color _GetCharacterColor(int characterId)
        {
            switch (characterId)
            {
                case 1:
                    return Color.Black;

                case 2:
                    return Color.Yellow;

                case 3:
                    return Color.Green;

                case 4:
                    return Color.Blue;
            }

            return Color.FromArgb(244, 208, 12);
        }

        /// <summary>
        ///  ĳ���� �̵����ɿ��� ǥ�� ������ȸ
        /// </summary>
        private Color _GetMovementColor(int characterId)
        {
            switch (characterId)
            {
                case 1:
                    return Color.Gray;

                case 2:
                    return Color.LightYellow;

                case 3:
                    return Color.LightGreen;

                case 4:
                    return Color.LightBlue;
            }

            return Color.FromArgb(244, 208, 12);
        }

        /// <summary>
        ///  ������ ����/�ʱ�ȭ
        /// </summary>
        public void GenerateBoard(bool isHost, List<BattleEntry> battleEntryList)
        {
            if (dgvBoard.InvokeRequired)
            {
                dgvBoard.Invoke(new MethodInvoker(delegate
                {
                    dgvBoard.Rows.Clear();
                    dgvBoard.Columns.Clear();
                }));
            }
            else
            {
                dgvBoard.Rows.Clear();
                dgvBoard.Columns.Clear();
            }

            if (battleEntryList == null)
            {
                MessageBox.Show("[GenerateBoard] battleEntryList is NLLL");
                if (btnExitPlay.InvokeRequired)
                {
                    btnExitPlay.Invoke(new MethodInvoker(delegate
                    {
                        btnExitPlay.PerformClick();
                    }));
                }
                else
                {
                    btnExitPlay.PerformClick();
                }
                return;
            }

            int boardCellSize = 35; // ��ĭ ũ��
            if (dgvBoard.InvokeRequired)
            {
                dgvBoard.Invoke(new MethodInvoker(delegate
                {
                    dgvBoard.ColumnCount = Constants.BOARD_SCALE_W;
                }));
            }
            else
            {
                dgvBoard.ColumnCount = Constants.BOARD_SCALE_W;
            }

            string[] rowVal = { "" };
            for (int r = 0; r < Constants.BOARD_SCALE_H; r++)
            {
                if (dgvBoard.InvokeRequired)
                {
                    dgvBoard.Invoke(new MethodInvoker(delegate
                    {
                        dgvBoard.Rows.Add(rowVal);
                        dgvBoard.Rows[r].Height = boardCellSize;
                    }));
                }
                else
                {
                    dgvBoard.Rows.Add(rowVal);
                    dgvBoard.Rows[r].Height = boardCellSize;
                }

                for (int c = 0; c < Constants.BOARD_SCALE_W; c++)
                {
                    if (dgvBoard.InvokeRequired)
                    {
                        dgvBoard.Invoke(new MethodInvoker(delegate
                        {
                            dgvBoard.Columns[c].Width = boardCellSize;
                        }));
                    }
                    else
                    {
                        dgvBoard.Columns[c].Width = boardCellSize;
                    }
                }
            }

            var hostEntry = battleEntryList.FirstOrDefault(x => x.IsHost == true);
            var opponentEntry = battleEntryList.FirstOrDefault(x => x.IsHost == false);
            string hostCharacterName = DataTableHelper.GetCharacterName(hostEntry.CharacterId);
            string opponentCharacterName = DataTableHelper.GetCharacterName(opponentEntry.CharacterId);

            if (isHost)
            {
                _myEntry = hostEntry;
                _targetEntry = opponentEntry;
            }
            else
            {
                _myEntry = opponentEntry;
                _targetEntry = hostEntry;
            }

            if (dgvBoard.InvokeRequired)
            {
                dgvBoard.Invoke(new MethodInvoker(delegate
                {
                    lblHostLp.Text = $"{hostCharacterName} : {hostEntry.BattleLp}";
                    lblOpponentLp.Text = $"{opponentCharacterName} : {opponentEntry.BattleLp}";

                    dgvBoard.Width = boardCellSize * Constants.BOARD_SCALE_W;
                    dgvBoard.Height = boardCellSize * Constants.BOARD_SCALE_H;

                    dgvBoard.Rows[hostEntry.CoordR].Cells[hostEntry.CoordC].Style.BackColor = _GetCharacterColor(hostEntry.CharacterId);
                    dgvBoard.Rows[opponentEntry.CoordR].Cells[opponentEntry.CoordC].Style.BackColor = _GetCharacterColor(opponentEntry.CharacterId);

                    dgvBoard.ClearSelection();
                }));
            }
            else
            {
                lblHostLp.Text = $"{hostCharacterName} : {hostEntry.BattleLp}";
                lblOpponentLp.Text = $"{opponentCharacterName} : {opponentEntry.BattleLp}";

                dgvBoard.Width = boardCellSize * Constants.BOARD_SCALE_W;
                dgvBoard.Height = boardCellSize * Constants.BOARD_SCALE_H;

                dgvBoard.Rows[hostEntry.CoordR].Cells[hostEntry.CoordC].Style.BackColor = _GetCharacterColor(hostEntry.CharacterId);
                dgvBoard.Rows[opponentEntry.CoordR].Cells[opponentEntry.CoordC].Style.BackColor = _GetCharacterColor(opponentEntry.CharacterId);

                dgvBoard.ClearSelection();
            }
        }

        /// <summary>
        ///  ������ ������� ����
        /// </summary>
        public void DrawBoard(bool isHost, List<BattleEntry> battleEntryList)
        {
            if (battleEntryList == null)
            {
                MessageBox.Show("[DrawBoard] battleEntryList is NLLL");
                return;
            }

            // �̵��� ��� ������ǥ ó��
            if (dgvBoard.InvokeRequired)
            {
                dgvBoard.Invoke(new MethodInvoker(delegate
                {
                    dgvBoard.Rows[_myEntry.CoordR].Cells[_myEntry.CoordC].Style.BackColor = Color.White;
                    dgvBoard.Rows[_targetEntry.CoordR].Cells[_targetEntry.CoordC].Style.BackColor = Color.White;
                }));
            }
            else
            {
                dgvBoard.Rows[_myEntry.CoordR].Cells[_myEntry.CoordC].Style.BackColor = Color.White;
                dgvBoard.Rows[_targetEntry.CoordR].Cells[_targetEntry.CoordC].Style.BackColor = Color.White;
            }

            // �̵��� ����
            var hostEntry = battleEntryList.FirstOrDefault(x => x.IsHost == true);
            var opponentEntry = battleEntryList.FirstOrDefault(x => x.IsHost == false);
            string hostCharacterName = DataTableHelper.GetCharacterName(hostEntry.CharacterId);
            string opponentCharacterName = DataTableHelper.GetCharacterName(opponentEntry.CharacterId);


            if (isHost)
            {
                _myEntry = hostEntry;
                _targetEntry = opponentEntry;
            }
            else
            {
                _myEntry = opponentEntry;
                _targetEntry = hostEntry;
            }

            if (dgvBoard.InvokeRequired)
            {
                dgvBoard.Invoke(new MethodInvoker(delegate
                {
                    lblHostLp.Text = $"{hostCharacterName} : {hostEntry.BattleLp}";
                    lblOpponentLp.Text = $"{opponentCharacterName} : {opponentEntry.BattleLp}";

                    dgvBoard.Rows[hostEntry.CoordR].Cells[hostEntry.CoordC].Style.BackColor = _GetCharacterColor(hostEntry.CharacterId);
                    dgvBoard.Rows[opponentEntry.CoordR].Cells[opponentEntry.CoordC].Style.BackColor = _GetCharacterColor(opponentEntry.CharacterId);

                    dgvBoard.ClearSelection();
                }));
            }
            else
            {
                lblHostLp.Text = $"{hostCharacterName} : {hostEntry.BattleLp}";
                lblOpponentLp.Text = $"{opponentCharacterName} : {opponentEntry.BattleLp}";

                dgvBoard.Rows[hostEntry.CoordR].Cells[hostEntry.CoordC].Style.BackColor = _GetCharacterColor(hostEntry.CharacterId);
                dgvBoard.Rows[opponentEntry.CoordR].Cells[opponentEntry.CoordC].Style.BackColor = _GetCharacterColor(opponentEntry.CharacterId);

                dgvBoard.ClearSelection();
            }
        }

        /// <summary>
        ///  �� ���콺������ �̵����ɿ��� ǥ��
        /// </summary>
        private void dgvBoard_CellMouseMove(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (_myEntry == null)
            {
                return;
            }

            if (e.RowIndex == _myEntry.CoordR && e.ColumnIndex == _myEntry.CoordC)
            {
                List<(int, int)> areaList = BattleHelper.GetAvailableArea(_myEntry);
                foreach ((int r, int c) in areaList)
                {
                    if (!(r == _myEntry.CoordR && c == _myEntry.CoordC))
                    {
                        dgvBoard.Rows[r].Cells[c].Style.BackColor = _GetMovementColor(_myCharacterId);
                    }
                }
            }
        }

        /// <summary>
        ///  �� ���콺�ƿ��� �̵����ɿ��� ǥ������
        /// </summary>
        private void dgvBoard_CellMouseLeave(object sender, DataGridViewCellEventArgs e)
        {
            if (_myEntry == null)
            {
                return;
            }

            if (e.RowIndex == _myEntry.CoordR && e.ColumnIndex == _myEntry.CoordC)
            {
                List<(int, int)> areaList = BattleHelper.GetAvailableArea(_myEntry);
                foreach ((int r, int c) in areaList)
                {
                    if (r == _targetEntry.CoordR && c == _targetEntry.CoordC)
                    {
                        dgvBoard.Rows[r].Cells[c].Style.BackColor = _GetCharacterColor(_targetEntry.CharacterId);
                    }
                    else if (!(r == _myEntry.CoordR && c == _myEntry.CoordC))
                    {
                        dgvBoard.Rows[r].Cells[c].Style.BackColor = Color.White;
                    }
                }
            }
        }

        /// <summary>
        ///  ������ �ʱ�ȭ
        /// </summary>
        private void _ClearSection(int r, int c)
        {
            Color color = Color.White;
            if (r == _targetEntry.CoordR && c == _targetEntry.CoordC)
            {
                color = _GetCharacterColor(_targetEntry.CharacterId);
            }
            else if (r == _myEntry.CoordR && c == _myEntry.CoordC)
            {
                color = _GetCharacterColor(_myEntry.CharacterId);
            }
            if (dgvBoard.InvokeRequired)
            {
                dgvBoard.Invoke(new MethodInvoker(delegate
                {
                    dgvBoard.Rows[r].Cells[c].Style.BackColor = color;
                    dgvBoard.ClearSelection();
                }));
            }
            else
            {
                dgvBoard.Rows[r].Cells[c].Style.BackColor = color;
                dgvBoard.ClearSelection();
            }
        }

        /// <summary>
        ///  ��ġŬ�� - �̵� or  ���� 
        /// </summary>
        private async void dgvBoard_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex == _myEntry.CoordR && e.ColumnIndex == _myEntry.CoordC)
            {
                MessageBox.Show("������ġ�� �����մϴ�.\n�ٸ����� �������ּ���");
                _ClearSection(e.RowIndex, e.ColumnIndex);
                return;
            }

            List<(int, int)> areaList = BattleHelper.GetAvailableArea(_myEntry);
            if (!areaList.Contains((e.RowIndex, e.ColumnIndex)))
            {
                MessageBox.Show("�̵������� ��ġ�� �ƴմϴ�\n�ٸ����� �������ּ���");
                _ClearSection(e.RowIndex, e.ColumnIndex);
                return;
            }

            if (_pvpLastPlayAccountId == _myEntry.AccountId)
            {
                MessageBox.Show("��밡 �̵��� �����Դϴ�.");
                _ClearSection(e.RowIndex, e.ColumnIndex);
                return;
            }

            WriteFormLog($"Move -> BattleId [{_battleId}], RowIndex [{e.RowIndex}], ColumnIndex [{e.ColumnIndex}]");

            // ������ ��ġ�� ����� ��ġ��� �̵����� �������� �������� ������,
            // �׿ܴ� �̵���
            if (e.RowIndex == _targetEntry.CoordR && e.ColumnIndex == _targetEntry.CoordC)
            {
                await _gameClient.AttackBattleCharacterAsync(_battleId);
            }
            else
            {
                await _gameClient.MoveBattleCharacterAsync(_battleId, e.RowIndex, e.ColumnIndex);
            }

            dgvBoard.ClearSelection();
        }

        /// <summary>
        ///  �÷��� ����
        /// </summary>
        private async void btnExitPlay_Click(object sender, EventArgs e)
        {
            await _gameClient.ExitBattleJoinAsync(_battleId);
        }
        #endregion
    }
}