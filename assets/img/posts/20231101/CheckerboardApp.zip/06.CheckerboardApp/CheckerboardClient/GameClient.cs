﻿using CheckerboardClient.Data;
using CheckerboardClient.Handlers;
using CheckerboardLib.Data;
using DotNetty.Handlers.Tls;
using DotNetty.Transport.Bootstrapping;
using DotNetty.Transport.Channels;
using DotNetty.Transport.Channels.Sockets;
using Newtonsoft.Json;
using Snowpipe;
using System.Net.Security;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;

namespace CheckerboardClient
{
    public class GameClient
    {
        private IFormHandler _formHandler;
        private IChannel _bootstrapChannel;

        private string _sessionToken = null;
        private long _accountId = 0;

        public GameClient(IFormHandler formHandler)
        {
            _formHandler = formHandler;
        }

        /// <summary>
        ///  서버에서 메세지가 Publish 된 경우
        /// </summary>
        private void _ClientDispatch(GamePacket resGamePacket)
        {
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resGamePacket));

            string methodName = "_" + resGamePacket.PacketType.ToCamelCase();
            MethodInfo dynMethod = this.GetType().GetMethod(methodName, BindingFlags.NonPublic | BindingFlags.Instance);
            if (dynMethod != null)
            {
                dynMethod.Invoke(this, new object[] { resGamePacket.PacketBody });
            }
            else
            {
                _formHandler.WriteFormLog($"Not Found Method - {methodName}");
            }
        }

        /// <summary>
        ///  서버연결
        /// </summary>
        public async Task RunAsync()
        {
            IEventLoopGroup group = new MultithreadEventLoopGroup();

            IDispatcherHandler.ClientDispatch clientDispatcher = gamePacket => _ClientDispatch(gamePacket);
            var packetEncoder = new PacketEncoder();
            var packetDecoder = new PacketDecoder();
            var _clientHandler = new ClientPacketHandler(clientDispatcher);

            X509Certificate2 cert = null;
            string targetHost = null;
            if (ConfigHelper.IsSSL)
            {
                cert = new X509Certificate2(Path.Combine(ConfigHelper.ProcessDirectory, "snowpipe.com.pfx"), "password");
                targetHost = cert.GetNameInfo(X509NameType.DnsName, false);
            }

            try
            {
                Bootstrap bootstrap = new Bootstrap();
                bootstrap
                .Group(group)
                    .Channel<TcpSocketChannel>()
                    .Option(ChannelOption.TcpNodelay, true)    // Do not buffer and send packages right away
                    .Handler(new ActionChannelInitializer<ISocketChannel>(channel =>
                    {
                        IChannelPipeline pipeline = channel.Pipeline;

                        if (cert != null)
                        {
                            pipeline.AddLast("tls", new TlsHandler(stream => new SslStream(stream, true, (sender, certificate, chain, errors) => true), new ClientTlsSettings(targetHost)));
                        }

                        pipeline.AddLast("encoder", packetEncoder);
                        pipeline.AddLast("decoder", packetDecoder);
                        pipeline.AddLast("handler", _clientHandler);
                    }));

                _bootstrapChannel = await bootstrap.ConnectAsync(
                    ConfigHelper.ServerIPAddress
                    , ConfigHelper.ServerPort
                    );

                //// For Packet Encoder/Decoder TEST
                //await _DataTestAsync();

                // login game server
                await _UserLoginAsync();

                //Console.ReadLine();
                //await _bootstrapChannel.CloseAsync();
            }
            catch (Exception ex)
            {
                string exMessage = $"{ex.Message}\n{ex.StackTrace}";
                _formHandler.WriteFormLog(exMessage);
                FLogManager.Get().ServiceLog.AppendErrorLog(exMessage);
            }
            //finally
            //{
            //    group.ShutdownGracefullyAsync().Wait(1000); // 1초 대기후 종료
            //}
        }

        /// <summary>
        ///  연결종료
        /// </summary>
        public async Task StopAsync()
        {
            await _bootstrapChannel.CloseAsync();
            _formHandler.ShowHideGroupBox(E_UI.NONE);
        }

        #region 서버 로그인
        /// <summary>
        ///  소켓서버 로그인요청
        /// </summary>
        private async Task _UserLoginAsync()
        {
            try
            {
                ReqUserLogin reqUserLogin = new ReqUserLogin
                {
                    NickName = _formHandler.ReadUserNickname()
                };

                GamePacket gamePacket = new GamePacket
                {
                    PacketType = E_PACKET_TYPE.REQ_USER_LOGIN,
                    PacketBody = EncUtil.EncodeBase64(reqUserLogin)
                };

                await _bootstrapChannel.WriteAndFlushAsync(gamePacket);
            }
            catch (Exception ex)
            {
                string exMessage = $"{ex.Message}\n{ex.StackTrace}";
                _formHandler.WriteFormLog(exMessage);
                FLogManager.Get().ServiceLog.AppendErrorLog(exMessage);
            }
        }

        /// <summary>
        ///  소켓서버 로그인응답
        /// </summary>
        private void _ResUserLogin(string packetBody)
        {
            var resUserLogin = EncUtil.DecodeBase64<ResUserLogin>(packetBody);
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resUserLogin));

            _formHandler.ShowHideGroupBox(E_UI.LOBBY);
            _sessionToken = resUserLogin.Token;
            _accountId = resUserLogin.AccountId;
        }

        /// <summary>
        ///  유저 로그인 알림
        /// </summary>
        private async void _PsUserLogin(string packetBody)
        {
            ResUserLogin resUserLogin = EncUtil.DecodeBase64<ResUserLogin>(packetBody);
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resUserLogin));

            if (resUserLogin.ResponseCode == E_RESPONSE_CODE.SUCCESS)
            {
                _formHandler.NotifyMessage($"{resUserLogin.NickName}님이 로그인하셨습니다");

            }
            else if (resUserLogin.ResponseCode == E_RESPONSE_CODE.DEUPLCATE_LOGIN)
            {
                _formHandler.ShowAlertMessage("중복로그인 되었습니다");
                await StopAsync();
            }
            else
            {
                FLogManager.Get().ServiceLog.AppendErrorLog(JsonConvert.SerializeObject(resUserLogin));
            }
        }
        #endregion

        #region 대전플레이
        /// <summary>
        ///  대전플레이 입장 요청
        /// </summary>
        public async Task EnterBattlePlayAsync(int characterId)
        {
            try
            {
                ReqEnterBattlePlay reqEnterBattlePlay = new ReqEnterBattlePlay
                {
                    Token = _sessionToken,
                    CharacterId = characterId
                };

                GamePacket gamePacket = new GamePacket
                {
                    PacketType = E_PACKET_TYPE.REQ_ENTER_BATTLE_PLAY,
                    PacketBody = EncUtil.EncodeBase64(reqEnterBattlePlay)
                };

                await _bootstrapChannel.WriteAndFlushAsync(gamePacket);
            }
            catch (Exception ex)
            {
                string exMessage = $"{ex.Message}\n{ex.StackTrace}";
                _formHandler.WriteFormLog(exMessage);
                FLogManager.Get().ServiceLog.AppendErrorLog(exMessage);
            }
        }

        /// <summary>
        ///  대전플레이 입장 응답
        /// </summary>
        private void _ResEnterBattlePlay(string packetBody)
        {
            var resEnterBattlePlay = EncUtil.DecodeBase64<ResEnterBattlePlay>(packetBody);
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resEnterBattlePlay));

            _formHandler.ShowHideGroupBox(E_UI.BATTLE_PLAY);
            _formHandler.SetLP(resEnterBattlePlay.Character.LP);
            _formHandler.InitWaitingList(resEnterBattlePlay.WaitingList);
        }

        /// <summary>
        ///  대기방 만들기 요청
        /// </summary>
        public async Task CreateBattleRoomAsync(int characterId)
        {
            try
            {
                ReqCreateBattleRoom reqCreateBattleRoom = new ReqCreateBattleRoom
                {
                    Token = _sessionToken,
                    CharacterId = characterId
                };

                GamePacket gamePacket = new GamePacket
                {
                    PacketType = E_PACKET_TYPE.REQ_CREATE_BATTLE_ROOM,
                    PacketBody = EncUtil.EncodeBase64(reqCreateBattleRoom)
                };

                await _bootstrapChannel.WriteAndFlushAsync(gamePacket);
            }
            catch (Exception ex)
            {
                string exMessage = $"{ex.Message}\n{ex.StackTrace}";
                _formHandler.WriteFormLog(exMessage);
                FLogManager.Get().ServiceLog.AppendErrorLog(exMessage);
            }
        }

        /// <summary>
        ///  대기방 만들기 응답
        /// </summary>
        private void _ResCreateBattleRoom(string packetBody)
        {
            var resCreateBattleRoom = EncUtil.DecodeBase64<ResCreateBattleRoom>(packetBody);
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resCreateBattleRoom));

            _formHandler.ShowHideGroupBox(E_UI.BATTLE_ROOM);
        }

        /// <summary>
        ///  대기방 생성 알림
        /// </summary>
        private void _PsCreateBattleRoom(string packetBody)
        {
            ResCreateBattleRoom resCreateBattleRoom = EncUtil.DecodeBase64<ResCreateBattleRoom>(packetBody);
            _formHandler.AddWaitting(resCreateBattleRoom.WaitingUser);
        }

        /// <summary>
        ///  대기취소
        /// </summary>
        public async Task ExitBattleRoomAsync()
        {
            try
            {
                ReqExitBattleRoom reqExitBattleRoom = new ReqExitBattleRoom
                {
                    Token = _sessionToken
                };

                GamePacket gamePacket = new GamePacket
                {
                    PacketType = E_PACKET_TYPE.REQ_EXIT_BATTLE_ROOM,
                    PacketBody = EncUtil.EncodeBase64(reqExitBattleRoom)
                };

                await _bootstrapChannel.WriteAndFlushAsync(gamePacket);
            }
            catch (Exception ex)
            {
                string exMessage = $"{ex.Message}\n{ex.StackTrace}";
                _formHandler.WriteFormLog(exMessage);
                FLogManager.Get().ServiceLog.AppendErrorLog(exMessage);
            }
        }

        private void _ResExitBattleRoom(string packetBody)
        {
            var resExitBattleRoom = EncUtil.DecodeBase64<ResExitBattleRoom>(packetBody);
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resExitBattleRoom));

            _formHandler.ShowHideGroupBox(E_UI.BATTLE_PLAY);
        }

        /// <summary>
        ///  대기취소 알림
        /// </summary>
        private void _PsExitBattleRoom(string packetBody)
        {
            ResExitBattleRoom resExitBattleRoom = EncUtil.DecodeBase64<ResExitBattleRoom>(packetBody);
            _formHandler.RemoveWaitting(resExitBattleRoom.WaitingUser.AccountId);
        }

        /// <summary>
        ///  대전시작 요청
        /// </summary>
        public async Task JoinBattleRoomAsync(long hostAccountId, int characterId)
        {
            try
            {
                ReqJoinBattleRoom reqJoinBattleRoom = new ReqJoinBattleRoom
                {
                    Token = _sessionToken,
                    HostAccountId = hostAccountId,
                    OpponentAccountId = _accountId,
                    OpponentCharacterId = characterId
                };

                GamePacket gamePacket = new GamePacket
                {
                    PacketType = E_PACKET_TYPE.REQ_JOIN_BATTLE_ROOM,
                    PacketBody = EncUtil.EncodeBase64(reqJoinBattleRoom)
                };

                await _bootstrapChannel.WriteAndFlushAsync(gamePacket);
            }
            catch (Exception ex)
            {
                string exMessage = $"{ex.Message}\n{ex.StackTrace}";
                _formHandler.WriteFormLog(exMessage);
                FLogManager.Get().ServiceLog.AppendErrorLog(exMessage);
            }
        }

        /// <summary>
        ///  대전시작 응답
        /// </summary>
        private void _ResJoinBattleRoom(string packetBody)
        {
            var resJoinBattleRoom = EncUtil.DecodeBase64<ResJoinBattleRoom>(packetBody);
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resJoinBattleRoom));

            if (resJoinBattleRoom.ResponseCode != E_RESPONSE_CODE.SUCCESS)
            {
                _formHandler.ShowAlertMessage(resJoinBattleRoom.ResponseCode.ToString());
            }
            else
            {
                _formHandler.ShowHideGroupBox(E_UI.BATTLE_JOIN);
                if (resJoinBattleRoom != null)
                {
                    long hostAccountId = resJoinBattleRoom.BattleInfo.BattleEntryList
                        .FirstOrDefault(x => x.IsHost == true).AccountId;
                    bool isHost = (hostAccountId == _accountId);

                    // 대기방삭제
                    _formHandler.RemoveWaitting(hostAccountId);

                    // 대전 플레이 초기화
                    _formHandler.GenerateBoard(isHost, resJoinBattleRoom.BattleInfo.BattleEntryList);
                    _formHandler.SetLastPlayAccountId(resJoinBattleRoom.BattleInfo.LastPlayAccountId);
                    _formHandler.SetBattleId(resJoinBattleRoom.BattleInfo.BattleId);
                }
            }
        }

        /// <summary>
        ///  대전시작 알림
        /// </summary>
        private void _PsJoinBattleRoom(string packetBody)
        {
            ResJoinBattleRoom resJoinBattleRoom = EncUtil.DecodeBase64<ResJoinBattleRoom>(packetBody);
            if (resJoinBattleRoom != null)
            {
                long hostAccountId = resJoinBattleRoom.BattleInfo.BattleEntryList
                    .FirstOrDefault(d => d.IsHost == true).AccountId;
                long opponentAccountId = resJoinBattleRoom.BattleInfo.BattleEntryList
                    .FirstOrDefault(d => d.IsHost == false).AccountId;
                bool isHost = (hostAccountId == _accountId);

                // 대기방삭제
                _formHandler.RemoveWaitting(hostAccountId);

                if (_accountId == hostAccountId || _accountId == opponentAccountId)
                {
                    // 대전 플레이 초기화
                    _formHandler.GenerateBoard(isHost, resJoinBattleRoom.BattleInfo.BattleEntryList);
                    _formHandler.SetBattleId(resJoinBattleRoom.BattleInfo.BattleId);
                    _formHandler.SetLastPlayAccountId(resJoinBattleRoom.BattleInfo.LastPlayAccountId);

                    _formHandler.ShowHideGroupBox(E_UI.BATTLE_JOIN);
                }
            }
        }

        /// <summary>
        ///  캐릭터 위치이동 요청
        /// </summary>
        public async Task MoveBattleCharacterAsync(long battleId, int x, int y)
        {
            try
            {
                ReqMoveBattleCharacter reqMoveBattleCharacter = new ReqMoveBattleCharacter
                {
                    Token = _sessionToken,
                    BattleId = battleId,
                    DestCoordR = x,
                    DestCoordC = y
                };

                GamePacket gamePacket = new GamePacket
                {
                    PacketType = E_PACKET_TYPE.REQ_MOVE_BATTLE_CHARACTER,
                    PacketBody = EncUtil.EncodeBase64(reqMoveBattleCharacter)
                };

                await _bootstrapChannel.WriteAndFlushAsync(gamePacket);
            }
            catch (Exception ex)
            {
                string exMessage = $"{ex.Message}\n{ex.StackTrace}";
                _formHandler.WriteFormLog(exMessage);
                FLogManager.Get().ServiceLog.AppendErrorLog(exMessage);
            }
        }

        /// <summary>
        ///  캐릭터 위치이동 응답
        /// </summary>
        private void _ResMoveBattleCharacter(string packetBody)
        {
            var resMoveBattleCharacter = EncUtil.DecodeBase64<ResMoveBattleCharacter>(packetBody);
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resMoveBattleCharacter));

            if (resMoveBattleCharacter.ResponseCode == E_RESPONSE_CODE.SUCCESS)
            {
                long hostAccountId = resMoveBattleCharacter.BattleInfo.BattleEntryList
                        .FirstOrDefault(x => x.IsHost == true).AccountId;
                bool isHost = (hostAccountId == _accountId);

                _formHandler.DrawBoard(isHost, resMoveBattleCharacter.BattleInfo.BattleEntryList);
                _formHandler.SetLastPlayAccountId(resMoveBattleCharacter.BattleInfo.LastPlayAccountId);
            }
            else
            {
                FLogManager.Get().ServiceLog.AppendErrorLog(JsonConvert.SerializeObject(resMoveBattleCharacter));
            }
        }

        /// <summary>
        ///  캐릭터 위치이동 알림
        /// </summary>
        private void _PsMoveBattleCharacter(string packetBody)
        {
            ResMoveBattleCharacter resMoveBattleCharacter = EncUtil.DecodeBase64<ResMoveBattleCharacter>(packetBody);
            if (resMoveBattleCharacter != null)
            {
                long hostAccountId = resMoveBattleCharacter.BattleInfo.BattleEntryList
                    .FirstOrDefault(d => d.IsHost == true).AccountId;
                bool isHost = (hostAccountId == _accountId);

                _formHandler.DrawBoard(isHost, resMoveBattleCharacter.BattleInfo.BattleEntryList);
                _formHandler.SetLastPlayAccountId(resMoveBattleCharacter.BattleInfo.LastPlayAccountId);
            }
        }

        /// <summary>
        ///  캐릭터 공격 요청
        /// </summary>
        public async Task AttackBattleCharacterAsync(long battleId)
        {
            try
            {
                ReqAttackBattleCharacter reqAttackBattleCharacter = new ReqAttackBattleCharacter
                {
                    Token = _sessionToken,
                    BattleId = battleId
                };

                GamePacket gamePacket = new GamePacket
                {
                    PacketType = E_PACKET_TYPE.REQ_ATTACK_BATTLE_CHARACTER,
                    PacketBody = EncUtil.EncodeBase64(reqAttackBattleCharacter)
                };

                await _bootstrapChannel.WriteAndFlushAsync(gamePacket);
            }
            catch (Exception ex)
            {
                string exMessage = $"{ex.Message}\n{ex.StackTrace}";
                _formHandler.WriteFormLog(exMessage);
                FLogManager.Get().ServiceLog.AppendErrorLog(exMessage);
            }
        }

        /// <summary>
        ///  캐릭터 공격 응답
        /// </summary>
        private void _ResAttackBattleCharacter(string packetBody)
        {
            var resAttackBattleCharacter = EncUtil.DecodeBase64<ResAttackBattleCharacter>(packetBody);
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resAttackBattleCharacter));

            if (resAttackBattleCharacter.ResponseCode == E_RESPONSE_CODE.SUCCESS)
            {
                var hostEntry = resAttackBattleCharacter.BattleInfo.BattleEntryList
                        .FirstOrDefault(x => x.IsHost == true);
                bool isHost = (hostEntry.AccountId == _accountId);

                var myEntry = hostEntry;
                if (!isHost)
                {
                    myEntry = resAttackBattleCharacter.BattleInfo.BattleEntryList
                        .FirstOrDefault(x => x.IsHost == false);
                }

                _formHandler.SetLP(myEntry.LP);
                _formHandler.SetLastPlayAccountId(resAttackBattleCharacter.BattleInfo.LastPlayAccountId);
                _formHandler.SetBattleLP(isHost, resAttackBattleCharacter.BattleResult, resAttackBattleCharacter.BattleInfo.BattleEntryList);
            }
            else
            {
                FLogManager.Get().ServiceLog.AppendErrorLog(JsonConvert.SerializeObject(resAttackBattleCharacter));
            }
        }

        /// <summary>
        ///  캐릭터 공격 알림
        /// </summary>
        private void _PsAttackBattleCharacter(string packetBody)
        {
            ResAttackBattleCharacter resAttackBattleCharacter = EncUtil.DecodeBase64<ResAttackBattleCharacter>(packetBody);
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resAttackBattleCharacter));

            if (resAttackBattleCharacter != null)
            {
                var hostEntry = resAttackBattleCharacter.BattleInfo.BattleEntryList
                        .FirstOrDefault(x => x.IsHost == true);
                bool isHost = (hostEntry.AccountId == _accountId);

                var myEntry = hostEntry;
                if (!isHost)
                {
                    myEntry = resAttackBattleCharacter.BattleInfo.BattleEntryList
                        .FirstOrDefault(x => x.IsHost == false);
                }

                _formHandler.SetLP(myEntry.LP);
                _formHandler.SetLastPlayAccountId(resAttackBattleCharacter.BattleInfo.LastPlayAccountId);
                _formHandler.SetBattleLP(isHost, resAttackBattleCharacter.BattleResult, resAttackBattleCharacter.BattleInfo.BattleEntryList);
            }
        }

        /// <summary>
        ///  대전 플레이 중지 요청
        /// </summary>
        public async Task ExitBattleJoinAsync(long battleId)
        {
            try
            {
                ReqExitBattleJoin reqExitBattleJoin = new ReqExitBattleJoin
                {
                    Token = _sessionToken,
                    BattleId = battleId
                };

                GamePacket gamePacket = new GamePacket
                {
                    PacketType = E_PACKET_TYPE.REQ_EXIT_BATTLE_JOIN,
                    PacketBody = EncUtil.EncodeBase64(reqExitBattleJoin)
                };

                await _bootstrapChannel.WriteAndFlushAsync(gamePacket);
            }
            catch (Exception ex)
            {
                string exMessage = $"{ex.Message}\n{ex.StackTrace}";
                _formHandler.WriteFormLog(exMessage);
                FLogManager.Get().ServiceLog.AppendErrorLog(exMessage);
            }
        }

        /// <summary>
        ///  대전 플레이 중지 응답
        /// </summary>
        private void _ResExitBattleJoin(string packetBody)
        {
            var resExitBattleJoin = EncUtil.DecodeBase64<ResExitBattleJoin>(packetBody);
            _formHandler.WriteFormLog(JsonConvert.SerializeObject(resExitBattleJoin));

            _formHandler.SetBattleGameOver();
        }

        /// <summary>
        ///  대전 플레이 중지 알림
        /// </summary>
        private void _PsExitBattleJoin(string packetBody)
        {
            ResExitBattleJoin resExitBattleJoin = EncUtil.DecodeBase64<ResExitBattleJoin>(packetBody);

            _formHandler.SetBattleGameOver();
        }
        #endregion

        #region For Packet Encoder/Decoder TEST
        /// <summary>
        ///  For Packet Encoder/Decoder TEST 요청
        /// </summary>
        private async Task _DataTestAsync()
        {
            var sampleWordList = SampleData.GetWordList();
            foreach (string sampleWord in sampleWordList)
            {
                try
                {
                    GamePacket gamePacket = new GamePacket
                    {
                        PacketType = E_PACKET_TYPE.REQ_DATA_TEST,
                        PacketBody = sampleWord
                    };

                    await _bootstrapChannel.WriteAndFlushAsync(gamePacket);
                }
                catch (Exception ex)
                {
                    string exMessage = $"{ex.Message}\n{ex.StackTrace}";
                    _formHandler.WriteFormLog(exMessage);
                    FLogManager.Get().ServiceLog.AppendErrorLog(exMessage);
                }
            }
        }

        /// <summary>
        ///  For Packet Encoder/Decoder TEST 응답
        /// </summary>
        private void _ResDataTest(string packetBody)
        {
            _formHandler.WriteFormLog(packetBody);
        }
        #endregion
    }
}
