﻿using Snowpipe;

namespace CheckerboardClient.Handlers
{
    public interface IDispatcherHandler
    {
        public delegate void ClientDispatch(GamePacket gamePacket);
    }
}
