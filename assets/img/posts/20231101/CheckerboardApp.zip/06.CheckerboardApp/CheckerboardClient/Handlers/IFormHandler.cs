﻿using CheckerboardClient.Data;
using Snowpipe;

namespace CheckerboardClient.Handlers
{
    public interface IFormHandler
    {
        public void WriteFormLog(string logMessage);

        public string ReadUserNickname();

        public void ShowHideGroupBox(E_UI ui);

        public void ShowAlertMessage(string message);

        public void NotifyMessage(string message);

        public void GenerateBoard(bool isHost, List<BattleEntry> battleEntryList);

        public void DrawBoard(bool isHost, List<BattleEntry> battleEntryList);

        public void InitWaitingList(List<UserInfo> waitingList);

        public void AddWaitting(UserInfo newWaitting);

        public void RemoveWaitting(long hostAccountId);

        public void SetBattleId(long battleId);

        public void SetLastPlayAccountId(long accountId);

        public void SetBattleLP(bool isHost, E_BATTLE_RESULT battleResult, List<BattleEntry> battleEntryList);

        public void SetLP(int lp);

        public void SetBattleGameOver();
    }
}
