﻿using DotNetty.Buffers;
using DotNetty.Codecs;
using DotNetty.Transport.Channels;
using System.Text;
using System.Text.RegularExpressions;

namespace Snowpipe
{
    public class PacketDecoder : MessageToMessageDecoder<IByteBuffer>
    {
        private readonly Encoding _encoding;
        private int _bodySize = 0;
        private GamePacket _receivedPacket;

        public PacketDecoder() : this(Encoding.UTF8)
        {

        }

        public PacketDecoder(Encoding encoding)
        {
            _encoding = encoding ?? throw new NullReferenceException("decoder encoding");
        }

        private void _CombineStream(string packetBody)
        {
            if (_receivedPacket != null)
            {
                _receivedPacket.PacketBody += packetBody.Replace("\r\n", "");
            }
        }

        protected override void Decode(
            IChannelHandlerContext context
            , IByteBuffer message
            , List<object> output
            )
        {
            var receivedText = message.ToString(_encoding);
            FLogManager.Get().ServiceLog.AppendInfoLog(receivedText);

            // 서버에서는 GamePacket을 하나씩 WriteAndFlushAsync 해서 보냈지만,
            // 여러개의 GamePacket이 뭉쳐서 한번에 수신되기도 하고, 
            // 하나의 패킷이 너무 길어서 N번에 걸쳐 끊어서 수신되기도 함
            string[] packetList = receivedText.Split("*");
            string text, pattern;
            int startindex = 0, chunkIndex;
            for (int i = 0; i < packetList.Length; i++)
            {
                chunkIndex = receivedText.IndexOf("*", startindex);
                if (chunkIndex < 0)
                {
                    chunkIndex = receivedText.Length - 1;
                }
                chunkIndex += 1;    // 종결문자 "*" 포함시킴

                text = receivedText.Substring(startindex, chunkIndex - startindex);
                if (string.IsNullOrEmpty(text))
                {
                    break;
                }
                startindex = chunkIndex;

                // 한번에 전체패킷이 다 들어왔는지 체크
                pattern = @"(?<PacketType>\w+)\|(?<BodySize>\d+)\|(?<PacketBody>\w+=*)\*$";
                //string pattern = @"(?<PacketType>\w+)\|(?<BodySize>\d+)\|(?<PacketBody>\w+=*)[\r\n]$";
                Match match = Regex.Match(text, pattern, RegexOptions.IgnoreCase | RegexOptions.Compiled);

                if (match.Success)
                {
                    // 한번에 전체패킷을 다 받은 경우

                    if (Enum.TryParse(match.Groups["PacketType"].Value, out E_PACKET_TYPE packetType))
                    {
                        GamePacket gamePacket = new GamePacket
                        {
                            PacketType = packetType,
                            PacketBody = match.Groups["PacketBody"].Value

                        };
                        output.Add(gamePacket);
                    }
                }
                else
                {
                    // 두번이상 나눠받은 경우

                    // 첫번째 수신인지 체크
                    pattern = @"(?<PacketType>\w+)\|(?<BodySize>\d+)\|(?<PacketBody>\w+=*)\*?$";
                    //pattern = @"(?<PacketType>\w+)\|(?<BodySize>\d+)\|(?<PacketBody>\w+=*)[\r\n]?$";
                    match = Regex.Match(text, pattern, RegexOptions.IgnoreCase | RegexOptions.Compiled);

                    if (match.Success)
                    {
                        // 첫번째 받은 스트림인 경우

                        if (Enum.TryParse(match.Groups["PacketType"].Value, out E_PACKET_TYPE packetType))
                        {
                            if (Int32.TryParse(match.Groups["BodySize"].Value, out _bodySize))
                            {
                                _receivedPacket = new GamePacket
                                {
                                    PacketType = packetType,
                                    PacketBody = match.Groups["PacketBody"].Value
                                };
                            }
                            else
                            {
                                FLogManager.Get().ServiceLog.AppendErrorLog($"[PacketDecoder-1st] Fail to parser PacketSize -> {text} receivedText -> {receivedText}");
                            }
                        }
                        else
                        {
                            FLogManager.Get().ServiceLog.AppendErrorLog($"[PacketDecoder-1st] Fail to parser PacketType -> {text} receivedText -> {receivedText}");
                        }
                    }
                    else
                    {
                        // N번째 받은 스트림인 경우

                        // 마지막 수신인지 체크
                        pattern = @"(?<PacketBody>\w+=*)\*$";
                        //pattern = @"(?<PacketBody>\w+=*)[\r\n]$";
                        match = Regex.Match(text, pattern, RegexOptions.IgnoreCase | RegexOptions.Compiled);

                        _CombineStream(match.Groups["PacketBody"].Value);

                        if (match.Success)
                        {
                            // 마지막 스트림인 경우

                            output.Add(_receivedPacket);
                            _receivedPacket = null;
                            _bodySize = 0;
                        }
                        else
                        {
                            FLogManager.Get().ServiceLog.AppendErrorLog($"[PacketDecoder-2st] completed to receive for PacketSize -> {text} receivedText -> {receivedText}");
                        }
                    }
                }
            }
        }

        public override bool IsSharable => true;
    }
}
