﻿using DotNetty.Buffers;
using DotNetty.Codecs;
using DotNetty.Transport.Channels;
using System.Text;

namespace Snowpipe
{
    public class PacketEncoder : MessageToMessageEncoder<GamePacket>
    {
        private readonly Encoding _encoding;

        public PacketEncoder() : this(Encoding.UTF8)
        {

        }

        public PacketEncoder(Encoding encoding)
        {
            _encoding = encoding ?? throw new NullReferenceException("encoder encoding");
        }

        protected override void Encode(
            IChannelHandlerContext context
            , GamePacket gamePacket
            , List<object> output
            )
        {
            if (gamePacket == null || gamePacket.PacketType == E_PACKET_TYPE.NONE)
            {
                FLogManager.Get().ServiceLog.AppendErrorLog("[PacketEncoder] gamePacket is invaild");
                return;
            }

            var message = gamePacket.ConvertToString();
            output.Add(ByteBufferUtil.EncodeString(context.Allocator, message, _encoding));
        }

        public override bool IsSharable => true;
    }
}
