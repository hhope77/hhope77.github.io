﻿namespace CheckerboardLib.Common;

public static class ServerDateTime
{
    private static DateTime _customServerDateTimeStamp;
    private static DateTime _originServerDateTimeStamp;
    private static bool _isIgnoredCustomDateTime = false;

    static ServerDateTime()
    {
        Reset();
    }

    public static DateTime Now
    {
        get
        {
            if (_isIgnoredCustomDateTime)
            {
                return DateTime.Now;
            }

            var diff = DateTime.Now - _originServerDateTimeStamp;
            return _customServerDateTimeStamp.AddMilliseconds(diff.TotalMilliseconds);
        }
    }

    public static void SetIgnoreCustomDateTime(bool isIgnoredCustomDateTime)
    {
        _isIgnoredCustomDateTime = isIgnoredCustomDateTime;
    }

    public static void Reset()
    {
        SetServerDateTime(DateTime.Now);
    }

    public static void SetServerDateTime(DateTime newServerDateTime)
    {
        if (_isIgnoredCustomDateTime)
        {
            return;
        }

        _customServerDateTimeStamp = newServerDateTime;
        _originServerDateTimeStamp = DateTime.Now;
    }
}
