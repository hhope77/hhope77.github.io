﻿using System.Collections;

namespace CheckerboardLib.Data
{
    public class SampleData
    {
        /// <summary>
        ///  total count 116
        /// </summary>
        public static ArrayList GetWordList()
        {
            ArrayList _sampleWords = new ArrayList();

            // count : 3
            _sampleWords.Add("0123456789");
            _sampleWords.Add("abcdefghijklmnopqrstuvwxyz");
            _sampleWords.Add("ABCDEFGHIJKLMNOPQRSTUVWXYZ");

            // count : 26
            _sampleWords.Add("abuse");
            _sampleWords.Add("background");
            _sampleWords.Add("ceremony");
            _sampleWords.Add("department");
            _sampleWords.Add("elementary");
            _sampleWords.Add("flashlight");
            _sampleWords.Add("government");
            _sampleWords.Add("handshake");
            _sampleWords.Add("independent");
            _sampleWords.Add("journey");
            _sampleWords.Add("kindergarten");
            _sampleWords.Add("laundry");
            _sampleWords.Add("magazine");
            _sampleWords.Add("necessary");
            _sampleWords.Add("otherwise");
            _sampleWords.Add("photographer");
            _sampleWords.Add("quarter");
            _sampleWords.Add("refrigerator");
            _sampleWords.Add("sophomore");
            _sampleWords.Add("thermometer");
            _sampleWords.Add("understand");
            _sampleWords.Add("vegetable");
            _sampleWords.Add("wonderful");
            _sampleWords.Add("xylophone");
            _sampleWords.Add("yell");
            _sampleWords.Add("zoo");

            // count : 25
            _sampleWords.Add("_1_able_2_absent_3_abuse_4_accept_5_accident_6_ache_7_activity_8_actually_9_add_10_address_11_admiral_12_adult_13_adventure_14_advice_15_affair_16_afraid_17_afterward_18_agree_19_ahead_20_airport_21_alarm_22_alive_23_allow_24_almost_25_alone_26_along_27_alphabet_28_altogether_29_amateur_30_amazing_31_amount_32_amuse_33_ancestor_34_ancient_35_angle_36_angry_37_answer_38_anxious_39_anyway_40_apart_41_appear_42_appetite_43_appointment_44_area_45_army_46_arrest_47_arrive_48_art_49_astonish_50_athlete_51_atom_52_attend_53_attract");
            _sampleWords.Add("_54_background_55_badly_56_balance_57_bar_58_base_59_basement_60_bathroom_61_battle_62_bay_63_beach_64_bean_65_bear_66_beast_67_beat_68_beauty_69_become_70_bedside_71_beef_72_beer_73_beg_74_beggar_75_behave_76_behind_77_believe_78_belong_79_below_80_belt_81_bend_82_besides_83_bet_84_beyond_85_bike_86_bill_87_biology_88_birth_89_bit_90_bite_91_blanket_92_bless_93_blind_94_blood_95_blow_96_board_97_body_98_bone_99_bookstore_100_booth_101_boring_102_borrow_103_bother_104_bottle_105_bottom_106_bound_107_bow_108_bowl_109_brain_110_branch_111_break_112_breathe_113_bridge_114_bright_115_bring_116_british_117_brown_118_bubble_119_build_120_burden_121_burn_122_bury_123_bush_124_business_125_busy_126_butterfly");
            _sampleWords.Add("_127_cage_128_calm_129_canal_130_candle_131_capital_132_captain_133_care_134_carry_135_carve_136_cash_137_castle_138_cause_139_ceiling_140_celebrate_141_cemetery_142_center_143_century_144_ceremony_145_certain_146_chain_147_chance_148_change_149_charge_150_charming_151_chase_152_cheap_153_check_154_cheek_155_chest_156_chief_157_choose_158_chopstick_159_circle_160_clap_161_clean_162_clear_163_cleave_164_clerk_165_clever_166_climate_167_climb_168_close_169_closet_170_cloth_171_cloudy_172_clue_173_coal_174_coast_175_coeducation_176_coil_177_coin_178_collect_179_college_180_colorful_181_comb_182_comedy_183_comfort_184_common_185_communication_186_company_187_comparison_188_competent_189_competition_190_complain_191_complete_192_composer_193_compulsory_194_concert_195_contest_196_continent_197_continue_198_contrary_199_control_200_cookie_201_cool_202_corn_203_correctly_204_cost_205_cotton_206_cough_207_count_208_couple_209_course_210_cousin_211_cover_212_crack_213_crash_214_crazy_215_create_216_creek_217_crew_218_cricket_219_crop_220_crowded_221_crown_222_culture_223_curious_224_custom");
            _sampleWords.Add("_225_damage_226_danger_227_dark_228_data_229_date_230_daughter_231_dawn_232_deal_233_dear_234_death_235_debt_236_decide_237_deck_238_declare_239_decrease_240_deep_241_deer_242_degree_243_delicious_244_delight_245_democracy_246_department_247_depend_248_describe_249_desert_250_deserve_251_design_252_destroy_253_detective_254_devil_255_dialogue_256_diary_257_dictionary_258_different_259_difficult_260_dig_261_diligent_262_dinning_263_direction_264_dirty_265_disappoint_266_discuss_267_dish_268_ditch_269_dive_270_doll_271_dollar_272_downtown_273_drag_274_draw_275_dream_276_drop_277_drown_278_drugstore_279_drum_280_dry_281_dull_282_dumb_283_dye");
            _sampleWords.Add("_284_early_285_earnings_286_earth_287_edge_288_education_289_effect_290_effort_291_either_292_elder_293_election_294_electricity_295_elementary_296_else_297_empty_298_enemy_299_energy_300_engage_301_engineer_302_enjoy_303_enough_304_entire_305_envelope_306_equal_307_eraser_308_error_309_especially_310_event_311_evil_312_exactly_313_examination_314_example_315_excellent_316_except_317_exchange_318_excited_319_excuse_320_exercise_321_exit_322_expect_323_expensive_324_experience_325_explain_326_explode_327_explore_328_expressway");
            _sampleWords.Add("_329_fact_330_factory_331_fail_332_fair_333_famous_334_fare_335_fat_336_fault_337_favorite_338_fear_339_feast_340_feather_341_feed_342_fence_343_fever_344_fierce_345_fight_346_figure_347_fill_348_finally_349_firm_350_flame_351_flashlight_352_flat_353_flight_354_float_355_flood_356_flow_357_flute_358_fog_359_folk_360_follow_361_foolish_362_force_363_foreign_364_forest_365_fortunately_366_forward_367_foundation_368_fountain_pen_369_frankly_370_french_371_fresh_372_frighten_373_frog_374_front_375_fruit_376_fun_377_funeral_378_fur_379_furniture_380_further_381_future");
            _sampleWords.Add("_382_gain_383_gallery_384_garage_385_gather_386_gay_387_gaze_388_general_389_German_390_gesture_391_giant_392_gift_393_giraffe_394_glory_395_goal_396_god_397_government_398_grab_399_grade_400_graduate_401_grain_402_grammar_403_grand_404_grass_405_grave_406_gray_407_greedy_408_greeting_409_ground_410_group_411_guard_412_guess_413_guest_414_guide_415_gun");
            _sampleWords.Add("_416_habit_417_halt_418_hand_419_handle_420_handshake_421_handsome_422_hang_423_happen_424_hardly_425_harmful_426_harvest_427_haste_428_hate_429_hawk_430_hay_431_health_432_heart_433_heat_434_heaven_435_heavy_436_hero_437_hesitate_438_hide_439_history_440_hit_441_hobby_442_hold_443_hole_444_holiday_445_hollow_446_homesick_447_hometown_448_honest_449_honour_450_hop_451_horizon_452_horn_453_hospital_454_however_455_howl_456_huge_457_hunger_458_hunter_459_hurray_460_hurry_461_hurt_462_husband_463_hut_464_hydrogen");
            _sampleWords.Add("_465_iceberg_466_idea_467_imagine_468_immediately_469_import_470_important_471_include_472_increase_473_indeed_474_independent_475_industrial_476_information_477_inner_478_inning_479_insect_480_instead_481_instrument_482_interest_483_interesting_484_international_485_intimate_486_introduce_487_invader_488_invent_489_invite_490_ivy");
            _sampleWords.Add("_491_jar_492_jean_493_jewel_494_job_495_join_496_joke_497_journey_498_joy_499_judge_500_junior");
            _sampleWords.Add("_501_kind_502_kindergarten_503_knee");
            _sampleWords.Add("_504_label_505_lamb_506_language_507_lantern_508_later_509_laundry_510_lay_511_lead_512_leak_513_leap_514_least_515_lend_516_lesson_517_letter_518_liberty_519_library_520_license_521_life_522_lift_523_limit_524_list_525_living_526_load_527_loaf_528_locate_529_lock_530_log_531_lonely_532_lose_533_loud_534_low_535_luck");
            _sampleWords.Add("_536_machine_537_magazine_538_mail_539_main_540_mammal_541_mankind_542_marble_543_march_544_marry_545_mars_546_master_547_match_548_math_549_matter_550_maybe_551_mayor_552_meat_553_memory_554_mention_555_merchant_556_merry_557_metal_558_method_559_might_560_mild_561_mile_562_million_563_mind_564_miss_565_mistake_566_modern_567_moment_568_monk_569_monument_570_mostly_571_mouse_572_museum_573_musician_574_mystery");
            _sampleWords.Add("_575_nail_576_nation_577_nature_578_navy_579_nearly_580_necessary_581_need_582_neighbor_583_neigher_584_nephew_585_nickname_586_niece_587_noble_588_nod_589_noise_590_none_591_normal_592_nuclear_593_nurse");
            _sampleWords.Add("_594_oath_595_obey_596_object_597_obtain_598_occur_599_ocean_600_offer_601_office_602_officer_603_once_604_operator_605_opinion_606_order_607_ostrich_608_otherwise_609_overhear_610_owe_611_owl_612_own");
            _sampleWords.Add("_613_paint_614_pair_615_pal_616_palace_617_parade_618_pardon_619_pass_620_passenger_621_passport_622_past_623_patient_624_pause_625_peaceful_626_pepper_627_perhaps_628_pet_629_petal_630_photographer_631_pick_632_piece_633_pigeon_634_pilgrim_635_pill_636_pilot_637_pitch_638_plane_639_planet_640_plant_641_plate_642_pleasant_643_plenty_644_poet_645_politely_646_pollution_647_pop_648_popular_649_population_650_port_651_possible_652_post_653_potato_654_powder_655_practice_656_prairie_657_pray_658_precious_659_prepare_660_present_661_president_662_press_663_pretend_664_pretty_665_price_666_primary_667_prince_668_principal_669_prison_670_private_671_prize_672_probably_673_problem_674_produce_675_project_676_promise_677_pronunciation_678_properly_679_protect_680_proud_681_prove_682_proverb_683_public_684_pull_685_pulse_686_pumpkin_687_puritan_688_purpose_689_push_690_puzzle");
            _sampleWords.Add("_691_quarter_692_quiet_693_quite");
            _sampleWords.Add("_694_race_695_raise_696_rapidly_697_rat_698_rate_699_rather_700_reach_701_rear_702_reason_703_receive_704_recently_705_record_706_refrigerator_707_refuse_708_regular_709_rein_710_relative_711_relay_712_religious_713_remain_714_remember_715_remind_716_remove_717_repeat_718_replace_719_reply_720_report_721_republic_722_resources_723_respect_724_rest_725_restaurant_726_return_727_review_728_revival_729_revolution_730_rid_731_riddle_732_ride_733_roar_734_robber_735_roll_736_rope_737_route_738_row_739_rub_740_rudely_741_ruin_742_rule");
            _sampleWords.Add("_743_sad_744_safely_745_sail_746_sale_747_salt_748_sample_749_sand_750_save_751_saw_752_saying_753_scar_754_scare_755_scene_756_schedule_757_scholar_758_science_759_score_760_scratch_761_scream_762_sculpture_763_search_764_seat_765_secretary_766_section_767_seed_768_seldom_769_select_770_semester_771_senior_772_sentence_773_series_774_serious_775_servant_776_settler_777_several_778_shade_779_shadow_780_shake_781_shape_782_sharp_783_sheep_784_sheet_785_shell_786_shine_787_shock_788_shoot_789_shore_790_short_791_shoulder_792_shout_793_shower_794_shrug_795_shut_796_sick_797_sigh_798_sight_799_sign_800_silent_801_silk_802_silly_803_similar_804_simple_805_since_806_sincerely_807_single_808_sink_809_site_810_situation_811_skill_812_slave_813_sleep_814_slide_815_slip_816_smart_817_smell_818_smoke_819_snake_820_sniff_821_social_822_solar_823_soldier_824_solution_825_sometime_826_sophomore_827_sore_828_sound_829_source_830_sow_831_space_832_spade_833_special_834_speech_835_spend_836_spirit_837_spot_838_square_839_squirrel_840_stadium_841_stage_842_stair_843_stare_844_state_845_statue_846_stay_847_steady_848_steal_849_stem_850_step_851_stethoscope_852_stomach_853_stone_854_store_855_stormy_856_straight_857_strange_858_stream_859_stress_860_stripe_861_struggle_862_stupid_863_subject_864_suburb_865_subway_866_successful_867_such_868_suck_869_suddenly_870_suffer_871_sugar_872_suitcase_873_sunrise_874_sunshine_875_superstition_876_supply_877_suppose_878_surface_879_surprise_880_surround_881_survive_882_sweet_883_swing_884_sword_885_symbol_886_system");
            _sampleWords.Add("_887_tail_888_taste_889_tax_890_tear_891_teenager_892_telephone_893_temperature_894_temple_895_terrible_896_theater_897_thermometer_898_thief_899_thin_900_thirsty_901_though_902_throat_903_throw_904_thumb_905_ticket_906_tie_907_tightly_908_tiny_909_together_910_tomb_911_tongue_912_tool_913_tooth_914_torch_915_touch_916_tough_917_tourist_918_toward_919_towel_920_tower_921_town_922_track_923_tradition_924_traffic_925_travel_926_treasure_927_treat_928_trick_929_trip_930_triumph_931_trouble_932_trousers_933_trumpet_934_trust_935_turkey_936_turn_937_turtle_938_twice_939_twin_940_type");
            _sampleWords.Add("_941_umbrella_942_understand_943_uniform_944_unity_945_universe_946_unless_947_unlike_948_upset_949_upside_950_useless_951_usually");
            _sampleWords.Add("_952_vacation_953_vain_954_valley_955_valuable_956_various_957_vegetable_958_view_959_village_960_voice_961_vote_962_voyage");
            _sampleWords.Add("_963_wagon_964_wake_965_war_966_warn_967_waste_968_watch_969_weak_970_wealth_971_wear_972_weather_973_wedding_974_weight_975_wet_976_whether_977_while_978_whisker_979_whisper_980_whistle_981_whole_982_wide_983_wild_984_win_985_wink_986_wise_987_wish_988_without_989_wolf_990_wonderful_991_wood_992_wool_993_word_994_worry_995_worth_996_wound_997_wrap_998_wrong");
            _sampleWords.Add("_999_xylophone");
            _sampleWords.Add("_1000_yell");

            // count : 23
            _sampleWords.Add("_1001_Do_you_have_any_recommendations");
            _sampleWords.Add("_1002_How_much_is_this");
            _sampleWords.Add("_1003_I_would_like_this");
            _sampleWords.Add("_1004_Can_I_try_this_on");
            _sampleWords.Add("_1005_Do_you_speak_English");
            _sampleWords.Add("_1006_I_have_a_reservation");
            _sampleWords.Add("_1007_Could_I_have_some_more_water");
            _sampleWords.Add("_1008_Do_you_take_credit_cards");
            _sampleWords.Add("_1009_This_is_not_what_I_ordered");
            _sampleWords.Add("_1010_Could_we_have_the_menu_please");
            _sampleWords.Add("_1011_Could_you_give_me_a_discount");
            _sampleWords.Add("_1012_I_would_like_a_cheaper_price");
            _sampleWords.Add("_1013_Where_is_the_nearest_bus_stop");
            _sampleWords.Add("_1014_Could_you_take_a_picture_of_me__please");
            _sampleWords.Add("_1015_I_am_allergic_to");
            _sampleWords.Add("_1016_Is_the_WiFi_free");
            _sampleWords.Add("_1017_Can_I_use_the_WiFi_free_of_charge");
            _sampleWords.Add("_1018_I_would_like_to_have_a_non_smoking_seat_please");
            _sampleWords.Add("_1019_Could_I_get_a_map");
            _sampleWords.Add("_1020_Could_I_have_the_check");
            _sampleWords.Add("_1021_Where_is_the_bathroom");
            _sampleWords.Add("_1022_Excuse_me_Can_you_tell_me_where_the_bathroom_is");
            _sampleWords.Add("_1023_Is_this_train_for_busan");

            // count : 40
            _sampleWords.Add("_1024_How_was_your_day");
            _sampleWords.Add("_1025_What_is_the_weather_like");
            _sampleWords.Add("_1026_What_are_you_going_to_do");
            _sampleWords.Add("_1027_Take_your_time_please");
            _sampleWords.Add("_1028_That_is_what_I_am_saying");
            _sampleWords.Add("_1029_Is_there_a_hotel_in_this_area");
            _sampleWords.Add("_1030_I_do_not_know_what_to_say");
            _sampleWords.Add("_1031_I_am_about_to_leave");
            _sampleWords.Add("_1032_Did_you_clean_up_in_here");
            _sampleWords.Add("_1033_Have_you_heard_of_it");
            _sampleWords.Add("_1034_Please_take_me_to_the_market");
            _sampleWords.Add("_1035_Why_are_you_dressed_up");
            _sampleWords.Add("_1036_Who_is_your_favorite_movie_stars");
            _sampleWords.Add("_1037_Would_you_like_to_have_some_coffee");
            _sampleWords.Add("_1038_You_seem_to_be_tired");
            _sampleWords.Add("_1039_I_am_in_good_shape");
            _sampleWords.Add("_1040_I_think_we_need_to_talk_about_it");
            _sampleWords.Add("_1041_I_would_rather_not_do_that");
            _sampleWords.Add("_1042_Hear_me_out");
            _sampleWords.Add("_1043_I_am_free_today");
            _sampleWords.Add("_1044_Can_I_take_this_on_the_plane");
            _sampleWords.Add("_1045_I_would_like_to_book_a_flight_to_Paris");
            _sampleWords.Add("_1046_I_left_my_key_in_the_room");
            _sampleWords.Add("_1047_What_is_the_fare_to_the_hotel");
            _sampleWords.Add("_1048_Keep_the_change");
            _sampleWords.Add("_1049_Excuse_me_We_are_ready_to_order");
            _sampleWords.Add("_1050_Can_I_get_a_to_go_box");
            _sampleWords.Add("_1051_Where_can_I_find_a_taxi");
            _sampleWords.Add("_1052_Do_you_offer_student_discounts");
            _sampleWords.Add("_1053_Let_is_take_a_picture_together");
            _sampleWords.Add("_1054_Where_is_the_information_center");
            _sampleWords.Add("_1055_It_was_really_fun");
            _sampleWords.Add("_1056_How_much_is_the_admission_fee");
            _sampleWords.Add("_1057_What_are_opening_hours");
            _sampleWords.Add("_1058_Take_the_shortest_way_please");
            _sampleWords.Add("_1059_What_should_I_bring");
            _sampleWords.Add("_1060_I_need_tourist_information");
            _sampleWords.Add("_1061_Is_there_a_free_restroom_around_here");
            _sampleWords.Add("_1062_Can_I_film_this");
            _sampleWords.Add("_1063_Where_do_they_sell_cosmetics");

            return _sampleWords;
        }
    }
}
