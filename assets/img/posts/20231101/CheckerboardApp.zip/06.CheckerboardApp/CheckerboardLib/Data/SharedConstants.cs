﻿namespace Snowpipe
{
    public class Constants
    {
        public const int BATTLE_LP_GAUGE = 30;
        public const int BOARD_SCALE_W = 14;
        public const int BOARD_SCALE_H = 8;
    }

    public enum E_PACKET_TYPE
    {
        NONE = 0,
        REQ_DATA_TEST = 1,
        RES_DATA_TEST = 2,

        REQ_USER_LOGIN = 10,
        RES_USER_LOGIN = 11,

        REQ_ENTER_BATTLE_PLAY = 20,
        RES_ENTER_BATTLE_PLAY = 21,
        REQ_CREATE_BATTLE_ROOM = 22,
        RES_CREATE_BATTLE_ROOM = 23,
        REQ_EXIT_BATTLE_ROOM = 24,
        RES_EXIT_BATTLE_ROOM = 25,
        REQ_JOIN_BATTLE_ROOM = 26,
        RES_JOIN_BATTLE_ROOM = 27,
        REQ_MOVE_BATTLE_CHARACTER = 28,
        RES_MOVE_BATTLE_CHARACTER = 29,
        REQ_ATTACK_BATTLE_CHARACTER = 30,
        RES_ATTACK_BATTLE_CHARACTER = 31,
        REQ_EXIT_BATTLE_JOIN = 32,
        RES_EXIT_BATTLE_JOIN = 33,

        PS_USER_LOGIN = 100,
        PS_CREATE_BATTLE_ROOM = 101,
        PS_EXIT_BATTLE_ROOM = 102,
        PS_JOIN_BATTLE_ROOM = 103,
        PS_MOVE_BATTLE_CHARACTER = 104,
        PS_ATTACK_BATTLE_CHARACTER = 105,
        PS_EXIT_BATTLE_JOIN = 106,
    }

    public enum E_DATA_TABLE_TYPE
    {
        ALL = 0,
        CHAR_BASIC = 1
    }

    //public enum E_LOGIN_PLATFORM_TYPE
    //{
    //    DEFAULT = 0,
    //    GOOGLE = 1,
    //    APPLE = 2,
    //    FACEBOOK = 3,
    //    TWITTER = 4
    //}

    public enum E_RESPONSE_CODE
    {
        DEFAULT = 0,
        SUCCESS = 1,

        // channel
        INVALID_CHANNEL_ATTR = 101,

        // packet
        INVALID_PARAMETER = 201,
        FAIL_DESERIALIZE = 202,
        REQ_PARAM_INVALID_CHARACTER_ID = 203,
        REQ_PARAM_INVALID_ACCOUNT_ID = 204,
        REQ_PARAM_INVALID_BATTLE_ID = 205,
        REQ_PARAM_INVALID_DEST_COORD = 206,

        // session
        INVALID_SESSION = 301,
        NOT_EXIST_SESSION = 302,
        EXPIRED_SESSION = 303,
        DEUPLCATE_LOGIN = 304,

        // user
        NOT_EXIST_USER = 401,
        OFFLINE_USER = 402,

        // datatable
        INVALID_DATA_TABLE = 501,

        // game
        NOT_PLAYING = 601,
        ALREADY_EXIST_ROOM = 602,
        ALREADY_PLAYING_BATTLE = 603,
        NOT_MY_TURN = 603,
        INVALID_DEST = 604,
        NOT_ENOUGH_BATTLE_LP = 605,
    }

    public enum E_BROADCAST_TYPE
    {
        NONE = 0,
        EVERYONE = 1,
        EVERYONE_BUT_ME = 2,
        SERVER = 3,
        USER_LIST = 4,
        USER = 5,
    }

    public enum E_CHAR_RACE
    {
        NONE = 0,
        DWARF = 1,
        HUMAN = 2,
        HALFLING = 3,
    }

    public enum E_CHAR_CLASS
    {
        NONE = 0,
        FIGHTER = 1,
        CLERIC = 2,
        THIEF = 3,
        MAGIC_USER = 4,
    }

    public enum E_BATTLE_RESULT
    {
        NONE = 0,
        NORMAL = 1,
        GAME_OVER = 2,
    }
}