﻿namespace Snowpipe
{
    public abstract class BaseDT
    {
        public virtual void DataSetting()
        {

        }
    }
}
