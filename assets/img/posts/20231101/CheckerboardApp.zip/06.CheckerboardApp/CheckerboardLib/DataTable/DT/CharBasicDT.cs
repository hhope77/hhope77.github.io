﻿namespace Snowpipe
{
    public class CharBasicDT : BaseDT
    {
        public int Id { get; set; }                 // 아이디
        public string Name { get; set; }            // 이름
        public E_CHAR_RACE Race { get; set; }       // 종족
        public E_CHAR_CLASS Class { get; set; }     // 직업
        public int AC { get; set; }                 // 아머클래스
        public int HP { get; set; }                 // 히트포인트
        public int Movement { get; set; }           // 이동거리(피트)
        public int Level { get; set; }              // 현재레벨
        public int XP { get; set; }                 // 현재경험치
        public int Money { get; set; }              // cp 기준 돈
    }
}
