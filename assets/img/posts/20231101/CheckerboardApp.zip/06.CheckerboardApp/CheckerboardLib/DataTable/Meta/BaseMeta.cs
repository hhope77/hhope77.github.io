﻿namespace Snowpipe
{
    public abstract class BaseMeta
    {
        public virtual void Load()
        {

        }

        public virtual void CheckDataValidation()
        {

        }
    }
}
