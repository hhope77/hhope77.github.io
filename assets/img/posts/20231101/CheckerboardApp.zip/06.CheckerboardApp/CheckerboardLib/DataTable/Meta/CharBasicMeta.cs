﻿namespace Snowpipe
{
    public class CharBasicMeta : BaseMeta
    {
        private Dictionary<int, CharBasicDT> _dicData;

        public Dictionary<int, CharBasicDT> DicData { get { return _dicData; } }

        public override void Load()
        {
            try
            {
                List<CharBasicDT> resultList = FileUtil.LoadTableFile<CharBasicDT>("CharBasic.json");
                _dicData = resultList.OrderBy(c => c.Id).ToDictionary(k => k.Id, v => { v.DataSetting(); return v; });

                CheckDataValidation();
            }
            catch (Exception ex)
            {
                FLogManager.Get().ServiceLog.AppendFatalLog("[CharBasicMeta] Policy Error", ex);
            }
        }
    }
}
