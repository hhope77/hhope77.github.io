﻿namespace Snowpipe
{
    public class TableManager
    {
        private static readonly Dictionary<E_DATA_TABLE_TYPE, BaseMeta> _dtMetaDic = new Dictionary<E_DATA_TABLE_TYPE, BaseMeta>();

        public static CharBasicMeta CharBasicMetaData = new CharBasicMeta();

        public static void Load()
        {
            _dtMetaDic.Clear();

            _dtMetaDic.Add(E_DATA_TABLE_TYPE.CHAR_BASIC, CharBasicMetaData);


            foreach (BaseMeta table in _dtMetaDic.Values)
            {
                table.Load();
            }
        }
    }
}
