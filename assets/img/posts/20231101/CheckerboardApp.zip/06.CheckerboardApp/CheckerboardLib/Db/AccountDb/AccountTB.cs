﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CheckerboardLib.Db;

[Table("account")]
public class AccountTB
{
    [Key]
    [Column("id")]
    public long AccountId { get; set; }      // 유저 ID

    [Column("nickname")]
    public string Nickname { get; set; }    // 유저 닉네임

    [Column("level")]
    public int Level { get; set; }          // 유저 레벨

    [Column("reg_dt")]
    public DateTime RegDt { get; set; }     //유저 등록 날짜 
}
