﻿using DotNetty.Common.Utilities;
using DotNetty.Transport.Channels;

namespace CheckerboardLib.Extensions;

public static class ChannelExtensions
{
    public static readonly AttributeKey<string> CN_ATTR_ACCOUNT_ID = AttributeKey<string>.ValueOf("accountId");
    public static readonly AttributeKey<string> CN_ATTR_SERVER_ID = AttributeKey<string>.ValueOf("serverId");

    public static long GetAttrAccountId(this IChannel channel)
    {
        string attrAccountId = channel.GetAttribute(CN_ATTR_ACCOUNT_ID).Get();
        if (Int64.TryParse(attrAccountId, out long accountId))
        {
            return accountId;
        }

        return 0;
    }

    public static void SetAttrAccountId(this IChannel channel, long accountId)
    {
        channel.GetAttribute(CN_ATTR_ACCOUNT_ID).Set(accountId.ToString());
    }

    public static int GetAttrServerId(this IChannel channel)
    {
        string attrServerId = channel.GetAttribute(CN_ATTR_SERVER_ID).Get();
        if (Int32.TryParse(attrServerId, out int serverId))
        {
            return serverId;
        }

        return 0;
    }

    public static void SetAttrServerId(this IChannel channel, int serverId)
    {
        channel.GetAttribute(CN_ATTR_SERVER_ID).Set(serverId.ToString());
    }
}
