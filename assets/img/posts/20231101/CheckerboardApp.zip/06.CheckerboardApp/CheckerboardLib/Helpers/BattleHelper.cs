﻿namespace Snowpipe
{
    public class BattleHelper
    {
        /// <summary>
        ///  캐릭터 좌표를 중심으로 이동가능영역 좌표조회
        /// </summary>
        public static List<(int, int)> GetAvailableArea(BattleEntry entry)
        {
            var characterDt = DataTableHelper.GetCharacter(entry.CharacterId);
            if (characterDt != null)
            {
                return GetVerticalArea(entry.CoordR, entry.CoordC, characterDt.Movement / 10);
            }

            return default;
        }

        /// <summary>
        ///  캐릭터 좌표를 중심으로 수직영역 좌표조회
        /// </summary>
        /// <param name="coordR">캐릭터좌표 행값</param>
        /// <param name="coordC">캐릭터좌표 열값</param>
        /// <param name="movement">캐릭터 이동크기</param>
        private static List<(int, int)> GetVerticalArea(int coordR, int coordC, int movement)
        {
            List<(int, int)> list = new List<(int, int)>();

            int startR = coordR - movement;
            if (startR < 0)
            {
                startR = 0;
            }

            int endR = coordR + movement;
            if (endR >= Constants.BOARD_SCALE_H)
            {
                endR = Constants.BOARD_SCALE_H - 1;
            }

            int horizonMovement;
            List<(int, int)> horizonList;
            for (int r = startR; r <= endR; r++)
            {
                list.Add((r, coordC));
                horizonMovement = movement - Math.Abs(r - coordR);
                if (horizonMovement > 0)
                {
                    horizonList = GetHorizontalArea(r, coordC, horizonMovement);
                    if (horizonList.Count > 0)
                    {
                        list.AddRange(horizonList);
                    }
                }
            }

            // 중복제거
            list = list.Distinct().ToList();

            return list;
        }

        /// <summary>
        ///  수직영역 좌표를 중심으로 수평영역 좌표조회
        /// </summary>
        /// <param name="coordR">수직영영좌표 행값</param>
        /// <param name="coordC">수직영영좌표 열값</param>
        /// <param name="movement">이동크기</param>
        private static List<(int, int)> GetHorizontalArea(int coordR, int coordC, int movement)
        {
            List<(int, int)> list = new List<(int, int)>();

            int startC = coordC - movement;
            if (startC < 0)
            {
                startC = 0;
            }

            int endC = coordC + movement;
            if (endC >= Constants.BOARD_SCALE_W)
            {
                endC = Constants.BOARD_SCALE_W - 1;
            }

            for (int c = startC; c <= endC; c++)
            {
                list.Add((coordR, c));
            }

            return list;
        }
    }
}
