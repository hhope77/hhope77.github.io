﻿using Microsoft.Extensions.Configuration;
using System.Net;

namespace Snowpipe
{
    public static class ConfigHelper
    {
        public static IConfigurationRoot Configuration { get; }

        public static string ProcessDirectory
        {
            get
            {
                return AppContext.BaseDirectory;
            }
        }

        public static bool IsSSL { get; private set; }
        public static string ServerIP { get; private set; }
        public static IPAddress ServerIPAddress { get; private set; }
        public static int ServerPort { get; private set; }

        static ConfigHelper()
        {
            Configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("config/settings.json")
                .Build();
        }

        public static void Load()
        {
            string ssl = ConfigHelper.Configuration["SocketServerInfo:Ssl"];
            IsSSL = !string.IsNullOrEmpty(ssl) && bool.Parse(ssl);

            ServerIP = ConfigHelper.Configuration["SocketServerInfo:Ip"] ?? "127.0.0.1";
            ServerIPAddress = IPAddress.Parse(ServerIP);

            string port = ConfigHelper.Configuration["SocketServerInfo:Port"] ?? "0";
            ServerPort = int.Parse(port);
        }
    }
}


