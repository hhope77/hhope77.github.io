﻿namespace Snowpipe
{
    public class DataTableHelper
    {
        /// <summary>
        ///  캐릭터 아이디로 캐릭터 테이블조회
        /// </summary>
        public static CharBasicDT GetCharacter(int characterId)
        {
            if (TableManager.CharBasicMetaData.DicData.ContainsKey(characterId))
            {
                return TableManager.CharBasicMetaData.DicData[characterId];
            }

            return null;
        }

        /// <summary>
        ///  캐릭터 아이디로 캐릭터 이름조회
        /// </summary>
        public static string GetCharacterName(int characterId)
        {
            var charBasicDt = GetCharacter(characterId);
            if (charBasicDt != null)
            {
                return charBasicDt.Name;
            }

            return "";
        }
    }
}
