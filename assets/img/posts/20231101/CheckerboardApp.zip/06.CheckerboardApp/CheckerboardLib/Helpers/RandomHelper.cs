﻿using CheckerboardLib.Common;

namespace CheckerboardLib.Helpers;

public static class RandomHelper
{
    private static int _randomSeed = 0;
    private static Random _globalRandom = null;

    public static void SetRandomSeed(int randomSeed)
    {
        _randomSeed = randomSeed;
        _globalRandom = new Random(_randomSeed);
    }

    public static Random GetRandom()
    {
        if (_globalRandom == null)
        {
            var seed = (int)(((DateTimeOffset)ServerDateTime.Now).ToUnixTimeMilliseconds() + ServerDateTime.Now.Ticks);
            _globalRandom = new Random(seed);
        }

        return _globalRandom;
    }
}
