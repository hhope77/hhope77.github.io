﻿using DotNetty.Common.Internal.Logging;
using Microsoft.Extensions.Logging;

namespace CheckerboardLib.Log.ConsoleLog;

public static class CLogManager
{
    public static void SetConsoleLogger() => InternalLoggerFactory.DefaultFactory = LoggerFactory.Create(builder => builder.AddConsole());
}
