﻿using log4net;

namespace Snowpipe
{
    public class FLog
    {
        private static readonly object _locker = new object();

        private readonly ILog _fLog = null;
        private readonly string _logDelimiter = "--------------------------------------------------";

        public FLog(string log)
        {
            _fLog = log4net.LogManager.GetLogger(log);
        }

        /// <summary>
        /// 치명적 장애 발생시 Log Append
        /// </summary>
        public void AppendFatalLog(string message, Exception ex = null)
        {
            if (ex != null)
            {
                message = string.Format(
                    "{1}{0}{2}{0}{3}{0}{4}{0}{5}",
                    Environment.NewLine, _logDelimiter, message,
                    ex.Message, ex.InnerException != null ? ex.InnerException.Message : ex.Message, ex.StackTrace
                );
            }

            lock (_locker)
            {
                if (_fLog.IsFatalEnabled)
                {
                    _fLog.Fatal(message);
                }
            }
        }

        /// <summary>
        /// 일반적 장애 발생시 Log Append
        /// </summary>
        public void AppendErrorLog(string message)
        {
            lock (_locker)
            {
                if (_fLog.IsErrorEnabled)
                {
                    message = string.Format("{1}{0}{2}", Environment.NewLine, _logDelimiter, message);
                    _fLog.Error(message);
                }
            }
        }

        /// <summary>
        /// 경고 Log Append
        /// </summary>
        public void AppendWarnLog(string message)
        {
            lock (_locker)
            {
                if (_fLog.IsWarnEnabled)
                {
                    message = string.Format("{1}{0}{2}", Environment.NewLine, _logDelimiter, message);
                    _fLog.Warn(message);
                }
            }
        }

        /// <summary>
        /// 정보 Log Append
        /// </summary>
        public void AppendInfoLog(string message)
        {
            lock (_locker)
            {
                if (_fLog.IsInfoEnabled)
                {
                    message = string.Format("{1}{0}{2}", Environment.NewLine, _logDelimiter, message);
                    _fLog.Info(message);
                }
            }
        }

        /// <summary>
        /// 디버그 TRACE용 Log Append
        /// </summary>
        public void AppendDebugLog(string message)
        {
            lock (_locker)
            {
                if (_fLog.IsDebugEnabled)
                {
                    message = string.Format("{1}{0}{2}", Environment.NewLine, _logDelimiter, message);
                    _fLog.Debug(message);
                }
            }
        }
    }

}

