﻿namespace Snowpipe
{
    public class ReqAttackBattleCharacter : ReqBase
    {
        public long BattleId { get; set; }
    }

    public class ResAttackBattleCharacter : ResBase
    {
        public E_BATTLE_RESULT BattleResult { get; set; }
        public BattleInfo BattleInfo { get; set; }

        public ResAttackBattleCharacter() : base()
        {

        }
    }
}
