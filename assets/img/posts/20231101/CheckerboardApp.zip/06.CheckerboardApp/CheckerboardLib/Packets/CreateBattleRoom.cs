﻿namespace Snowpipe
{
    public class ReqCreateBattleRoom : ReqBase
    {
        public int CharacterId { get; set; }
    }

    public class ResCreateBattleRoom : ResBase
    {
        public UserInfo WaitingUser { get; set; }

        public ResCreateBattleRoom() : base()
        {

        }
    }
}
