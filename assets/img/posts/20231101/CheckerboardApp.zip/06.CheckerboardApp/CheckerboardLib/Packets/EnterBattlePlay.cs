﻿namespace Snowpipe
{
    public class ReqEnterBattlePlay : ReqBase
    {
        public int CharacterId { get; set; }
    }

    public class ResEnterBattlePlay : ResBase
    {
        public CharacterInfo Character { get; set; }
        public List<UserInfo> WaitingList { get; set; }

        public ResEnterBattlePlay() : base()
        {

        }
    }
}
