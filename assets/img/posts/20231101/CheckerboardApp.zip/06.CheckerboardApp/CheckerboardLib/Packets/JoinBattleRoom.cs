﻿namespace Snowpipe
{
    public class ReqJoinBattleRoom : ReqBase
    {
        public long HostAccountId { get; set; }
        public long OpponentAccountId { get; set; }
        public int OpponentCharacterId { get; set; }
    }

    public class ResJoinBattleRoom : ResBase
    {
        public BattleInfo BattleInfo { get; set; }

        public ResJoinBattleRoom() : base()
        {

        }
    }
}
