﻿namespace Snowpipe
{
    public class ReqMoveBattleCharacter : ReqBase
    {
        public long BattleId { get; set; }
        public int DestCoordR { get; set; }
        public int DestCoordC { get; set; }
    }

    public class ResMoveBattleCharacter : ResBase
    {
        public BattleInfo BattleInfo { get; set; }

        public ResMoveBattleCharacter() : base()
        {

        }
    }
}
