﻿using CheckerboardLib.Helpers;

namespace Snowpipe
{
    public class BattleEntry
    {
        public long AccountId { get; set; }
        public int CharacterId { get; set; }
        public int BattleLp { get; set; }
        public int LP { get; set; }
        public bool IsHost { get; set; }
        public int CoordR { get; set; }
        public int CoordC { get; set; }

        public BattleEntry()
        {

        }

        public BattleEntry(long accountId, int characterId, int lp, bool isHost)
        {
            this.AccountId = accountId;
            this.CharacterId = characterId;
            this.BattleLp = Constants.BATTLE_LP_GAUGE;
            this.LP = lp;
            this.IsHost = isHost;
            CoordR = RandomHelper.GetRandom().Next(0, Constants.BOARD_SCALE_H / 2);
            if (isHost)
            {
                CoordC = RandomHelper.GetRandom().Next(0, Constants.BOARD_SCALE_W / 3);
            }
            else
            {
                CoordC = RandomHelper.GetRandom().Next(Constants.BOARD_SCALE_W * 2 / 3, Constants.BOARD_SCALE_W);
            }
        }
    }
}
