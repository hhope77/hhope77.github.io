﻿namespace Snowpipe
{
    public class BattleInfo
    {
        public long BattleId { get; set; }
        public long LastPlayAccountId { get; set; }
        public List<BattleEntry> BattleEntryList { get; set; }

        public BattleInfo()
        {
            BattleEntryList = new List<BattleEntry> { };
        }
    }
}
