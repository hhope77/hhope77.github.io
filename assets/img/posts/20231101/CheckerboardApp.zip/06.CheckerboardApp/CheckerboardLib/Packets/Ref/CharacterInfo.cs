﻿namespace Snowpipe
{
    public class CharacterInfo
    {
        public int CharacterId { get; set; }
        public int LP { get; set; }  // 생명포인트 
    }
}
