﻿namespace Snowpipe
{
    public class UserInfo
    {
        public long AccountId { get; set; }
        public string NIckName { get; set; }
        public int Level { get; set; }
        public CharacterInfo Character { get; set; }

        public UserInfo Clone()
        {
            UserInfo copyUserInfo = new UserInfo
            {
                AccountId = this.AccountId,
                NIckName = this.NIckName,
                Level = this.Level,
                Character = this.Character
            };
            return copyUserInfo;
        }
    }
}
