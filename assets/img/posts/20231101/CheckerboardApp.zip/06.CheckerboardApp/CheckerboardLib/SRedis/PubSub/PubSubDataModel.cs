﻿using Snowpipe;

namespace CheckerboardLib.SRedis.PubSub;

public class PubSubDataModel
{
    public E_BROADCAST_TYPE BroadcastType { get; set; }
    public object BroadcastTarget { get; set; }

    public GamePacket PubGamePacket { get; set; }

    public PubSubDataModel()
    {

    }

    public PubSubDataModel(
        E_BROADCAST_TYPE broadcastType, object broadcastTarget,
        GamePacket pubGamePacket
        )
    {
        BroadcastType = broadcastType;
        BroadcastTarget = broadcastTarget;
        PubGamePacket = pubGamePacket;
    }
}