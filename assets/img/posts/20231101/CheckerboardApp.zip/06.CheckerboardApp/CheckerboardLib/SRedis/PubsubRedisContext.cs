﻿using Snowpipe;
using StackExchange.Redis;

namespace CheckerboardLib.SRedis;

public class PubsubRedisContext
{
    private static Lazy<ConnectionMultiplexer> _lazyConnection;
    private static readonly object _connectLocker = new object();
    private static readonly object _reconnectLocker = new object();
    private readonly string _connectionString;
    public ConnectionMultiplexer Connection { get { return _lazyConnection.Value; } }

    public PubsubRedisContext(string connectionString)
    {
        _connectionString = connectionString;
        CreateConnection();
    }

    public void CreateConnection()
    {
        lock (_connectLocker)
        {
            if (_lazyConnection == null)
            {
                _lazyConnection = new Lazy<ConnectionMultiplexer>(() => ConnectionMultiplexer.Connect(_connectionString));
            }
        }
    }

    public void ForceReconnect()
    {
        lock (_reconnectLocker)
        {
            this.CloseConnection();
            this.CreateConnection();
        }
    }

    public void CloseConnection()
    {
        if (_lazyConnection != null)
        {
            try
            {
                _lazyConnection.Value.Close();
            }
            catch (Exception ex)
            {
                FLogManager.Get().ServiceLog.AppendFatalLog("[PubsubRedisContext] ConnectionMultiplexer Close error", ex);
            }
        }
    }
}
