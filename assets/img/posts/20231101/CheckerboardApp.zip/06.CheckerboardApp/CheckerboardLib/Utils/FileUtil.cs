﻿using Newtonsoft.Json;

namespace Snowpipe
{
    public class FileUtil
    {
        public static List<T> LoadTableFile<T>(string jsonFileName)
        {
            try
            {
                string subFolderPath = $"DataTable{Path.DirectorySeparatorChar}Json{Path.DirectorySeparatorChar}";
                string jsonFilePath = Path.Combine(ConfigHelper.ProcessDirectory, subFolderPath, jsonFileName);
                return JsonConvert.DeserializeObject<List<T>>(File.ReadAllText(jsonFilePath));
            }
            catch (ArgumentException ex)
            {
                FLogManager.Get().ServiceLog.AppendFatalLog($"[JsonFileLoad-{jsonFileName}] Loading Json File Error", ex);
            }

            return default;
        }
    }
}
