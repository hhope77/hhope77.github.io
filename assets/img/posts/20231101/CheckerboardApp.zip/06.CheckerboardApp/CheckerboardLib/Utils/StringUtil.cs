﻿namespace Snowpipe;

public static class StringUtil
{
    public static string ToCamelCase<T>(this T enumType)
    {
        return enumType.ToString().ToLower()
            .Split(new[] { "_" }, StringSplitOptions.RemoveEmptyEntries)
            .Select(s => char.ToUpperInvariant(s[0]) + s.Substring(1))
            .Aggregate(string.Empty, (s1, s2) => s1 + s2);
    }
}
