﻿using CheckerboardLib.Data;
using CheckerboardLib.SRedis;
using CheckerboardLib.SRedis.PubSub;
using CheckerboardServer.Channel;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Snowpipe;

namespace CheckerboardServer.Handlers;

public class PubSubHandler
{
    private readonly IServiceProvider _serviceProvider;
    private PubsubRedisContext _pubsubRedisContext;

    public PubSubHandler(IServiceProvider serviceProvider)
    {
        _serviceProvider = serviceProvider;
        _pubsubRedisContext = serviceProvider.GetRequiredService<PubsubRedisContext>();
    }

    //public void CreateRedisContext()
    //{
    //    _pubsubRedisContext = new PubsubRedisContext(ConfigHelper.Configuration["ConnectionStrings:PubSubRedisDB"]);
    //}

    public void StartSubscribe()
    {
        //if (_pubsubRedisContext == null)
        //{
        //    this.CreateRedisContext();
        //}

        if (_pubsubRedisContext.Connection == null)
        {
            _pubsubRedisContext.ForceReconnect();
        }

        var listen = _pubsubRedisContext.Connection.GetSubscriber();
        listen
            .Subscribe(RedisKeyConstants.PubSubData)
            .OnMessage(message =>
            {
                string pubsubData = message.Message;
                Console.WriteLine($"subscriber ===> {pubsubData}");
                _SubscribeDispatch(pubsubData);
            });
    }

    private void _SubscribeDispatch(string pubsubData)
    {
        var pubsubDataPacket = JsonConvert.DeserializeObject<PubSubDataModel>(pubsubData);

        if (pubsubDataPacket != null)
        {
            if (pubsubDataPacket.BroadcastType == E_BROADCAST_TYPE.EVERYONE)
            {
                ChannelManager.SendToEveryone(pubsubDataPacket.PubGamePacket);
            }
            else if (pubsubDataPacket.BroadcastType == E_BROADCAST_TYPE.EVERYONE_BUT_ME)
            {
                long accuntId = Convert.ToInt64(pubsubDataPacket.BroadcastTarget);
                ChannelManager.SendToEveryoneButMe(accuntId, pubsubDataPacket.PubGamePacket);
            }
            else if (pubsubDataPacket.BroadcastType == E_BROADCAST_TYPE.SERVER)
            {
                int serverId = Convert.ToInt32(pubsubDataPacket.BroadcastTarget);
                ChannelManager.SendToServer(serverId, pubsubDataPacket.PubGamePacket);
            }
            else if (pubsubDataPacket.BroadcastType == E_BROADCAST_TYPE.USER_LIST)
            {
                IEnumerable<long> userList = pubsubDataPacket.BroadcastTarget as IEnumerable<long>;
                ChannelManager.SendToUserList(userList, pubsubDataPacket.PubGamePacket);
            }
            else if (pubsubDataPacket.BroadcastType == E_BROADCAST_TYPE.USER)
            {
                long accuntId = Convert.ToInt64(pubsubDataPacket.BroadcastTarget);
                ChannelManager.SendToUser(accuntId, pubsubDataPacket.PubGamePacket);
            }
        }
    }
}