﻿using CheckerboardLib.Data;
using CheckerboardLib.Db;
using CheckerboardLib.Extensions;
using CheckerboardLib.SRedis;
using CheckerboardLib.SRedis.PubSub;
using CheckerboardServer.Channel;
using DotNetty.Transport.Channels;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Snowpipe;
using System.Reflection;

namespace CheckerboardServer.Handlers;

public partial class ServerPacketHandler
{
    private Dictionary<long/* AccountId */, UserInfo> _UserDB = new Dictionary<long, UserInfo>();
    private Dictionary<long/* AccountId */, UserInfo> _battleWaitingDB = new Dictionary<long, UserInfo>();
    private Dictionary<long/* BattleId */, BattleInfo> _battleGameDB = new Dictionary<long, BattleInfo>();

    private readonly AccountDbContext _accountDbContext;
    private readonly SessionRedisContext _sessionRedisContext;
    private readonly PubsubRedisContext _pubsubRedisContext;
    private int _serverId;

    public ServerPacketHandler(IServiceProvider serviceProvider)
    {
        _sessionRedisContext = serviceProvider.GetRequiredService<SessionRedisContext>();
        _pubsubRedisContext = serviceProvider.GetRequiredService<PubsubRedisContext>();
        _accountDbContext = serviceProvider.GetRequiredService<AccountDbContext>();

        SetServerId();
    }

    private void SetServerId()
    {
        // TODO
        // 웹서버와 소켓서버를 함께사용하면 웹서버에서 ServerId를 할당
        // 웹서버없이 소켓서버만으로 사용한다면 로그인용 서버와 게임소켓서버를 분리 후
        // 로그인시 CCU가 가장 적은 게임서버를 할당하고 로그인서버는 연결종료
        // 현재는 임시 할당
        _serverId = 123;
    }

    private void _ServerDispatch(IChannelHandlerContext context, GamePacket reqGamePacket)
    {
        string methodName = "_" + reqGamePacket.PacketType.ToCamelCase();
        MethodInfo dynMethod = this.GetType().GetMethod(methodName, BindingFlags.NonPublic | BindingFlags.Instance);
        if (dynMethod != null)
        {
            dynMethod.Invoke(this, new object[] { context, reqGamePacket.PacketBody });
        }
    }

    #region 레디스 데이터 관련
    /// <summary>
    ///  세션토큰 생성
    ///  TODO - jwt webtoken 을 받아서 세션토큰으로 사용하는걸 검토!
    /// </summary>
    private string _SetRedisUserSession(AccountTB accountDto)
    {
        // session token
        string tokenData = $"{accountDto.AccountId}-{accountDto.Nickname}";
        string token = EncUtil.EncodeBase64(tokenData);

        _sessionRedisContext.SetSessionToken(accountDto.AccountId, token);

        return token;
    }

    /// <summary>
    ///  세션체크
    /// </summary>
    private E_RESPONSE_CODE _CheckSession(long accountId, string token)
    {
        if (accountId == 0)
        {
            return E_RESPONSE_CODE.INVALID_SESSION;
        }

        if (!_sessionRedisContext.CheckSessionToken(accountId, token))
        {
            return E_RESPONSE_CODE.EXPIRED_SESSION;
        }

        // 세션 타임아웃 연장
        _sessionRedisContext.UpdateSessionTokenExpiry(accountId);

        return E_RESPONSE_CODE.SUCCESS;
    }

    /// <summary>
    ///  레디스 퍼블리시
    /// </summary>
    private void _MessagePublish(
        E_BROADCAST_TYPE broadcastType, object broadcastTarget,
        E_PACKET_TYPE pubsubPacketType, GamePacket resGamePacket
        )
    {
        var pubsubPacket = resGamePacket.Clone();
        pubsubPacket.PacketType = pubsubPacketType;
        var pubsubData = new PubSubDataModel(broadcastType, broadcastTarget, pubsubPacket);
        var pubsubDataJson = JsonConvert.SerializeObject(pubsubData);

        var listen = _pubsubRedisContext.Connection.GetSubscriber();
        listen.Publish(RedisKeyConstants.PubSubData, pubsubDataJson);
    }
    #endregion

    #region 로그인관련
    /// <summary>
    ///  유저로그인
    /// </summary>
    private void _ReqUserLogin(IChannelHandlerContext context, string packetBody)
    {
        GamePacket resPacket = new GamePacket(E_PACKET_TYPE.RES_USER_LOGIN);
        ResUserLogin resUserLogin = new ResUserLogin();

        if (string.IsNullOrEmpty(packetBody))
        {
            resUserLogin.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resUserLogin);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        ReqUserLogin reqUserLogin = EncUtil.DecodeBase64<ReqUserLogin>(packetBody);
        if (reqUserLogin == null)
        {
            resUserLogin.ResponseCode = E_RESPONSE_CODE.FAIL_DESERIALIZE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resUserLogin);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // 닉네임으로 계정조회
        var accountDto = _accountDbContext.SelectAccount(reqUserLogin.NickName);
        if (accountDto == null)
        {
            long accountId = _accountDbContext.InsertAccount(reqUserLogin.NickName);
            accountDto = _accountDbContext.SelectAccount(accountId);
        }

        // UserInfo 생성
        var userInfo = new UserInfo
        {
            AccountId = accountDto.AccountId,
            NIckName = accountDto.Nickname,
            Level = 1
        };

        if (_UserDB.ContainsKey(accountDto.AccountId))
        {
            _UserDB[accountDto.AccountId] = userInfo;
        }
        else
        {
            _UserDB.Add(accountDto.AccountId, userInfo);
        }

        // 세션토큰 생성
        string userToken = _SetRedisUserSession(accountDto);

        // 채널추가정보 저장
        context.Channel.SetAttrAccountId(accountDto.AccountId);
        context.Channel.SetAttrServerId(_serverId);
        ChannelManager.AddUserChannel(context, accountDto.AccountId);
        ChannelManager.AddServerChannel(context, _serverId);

        // 응답
        resUserLogin = new ResUserLogin
        {
            ResponseCode = E_RESPONSE_CODE.SUCCESS,
            AccountId = accountDto.AccountId,
            Token = userToken,
            NickName = accountDto.Nickname
        };

        resPacket.PacketBody = EncUtil.EncodeBase64(resUserLogin);
        ChannelManager.SendToUser(accountDto.AccountId, resPacket);

        // 중복세션 종료
        ChannelManager.RemoveDuplcatedChannel();

        // publish
        _MessagePublish(
            E_BROADCAST_TYPE.EVERYONE, null,
            E_PACKET_TYPE.PS_USER_LOGIN, resPacket
            );
    }
    #endregion

    #region 대전플레이 관련
    /// <summary>
    ///  대전중인지 체크
    /// </summary>
    private BattleInfo _GetPlayingBattle(long accountId)
    {
        return _battleGameDB.Values.FirstOrDefault(v => v.BattleEntryList.Where(d => d.AccountId == accountId).Count() > 0);
    }

    /// <summary>
    ///  대전유니크키 생성
    /// </summary>
    private long _GenerateBattleId()
    {
        if (_battleGameDB.Count > 0)
        {
            return _battleGameDB.Keys.Max() + 1;
        }

        return 1;
    }

    /// <summary>
    ///  대전 초기화
    /// </summary>
    private BattleInfo _InitBattleGame(long hostAccountId, long opponentAccountId)
    {
        // 게임중인 체크
        if (_battleGameDB.Values.Where(v => v.BattleEntryList.Where(d => d.AccountId == hostAccountId || d.AccountId == opponentAccountId).Count() > 0).Count() > 0)
        {
            return null;
        }

        // 호스트 UserInfo 체크
        if (_UserDB.TryGetValue(hostAccountId, out var hostUserInfo) == false)
        {
            return null;
        }

        // 상대 UserInfo 체크
        if (_UserDB.TryGetValue(opponentAccountId, out var opponentUserInfo) == false)
        {
            return null;
        }

        long battleId = _GenerateBattleId();
        List<BattleEntry> battleEntryList = new List<BattleEntry>
        {
            new BattleEntry(hostAccountId, hostUserInfo.Character.CharacterId, hostUserInfo.Character.LP, true),
            new BattleEntry(opponentAccountId, opponentUserInfo.Character.CharacterId, opponentUserInfo.Character.LP, false)
        };

        BattleInfo battleInfo = new BattleInfo
        {
            BattleId = battleId,
            LastPlayAccountId = opponentAccountId,    // 호스트 먼저 시작하므로 상대정보로 세팅
            BattleEntryList = battleEntryList
        };
        _battleGameDB.Add(battleId, battleInfo);

        return battleInfo;
    }

    /// <summary>
    ///  대전플레이 입장
    /// </summary>
    private void _ReqEnterBattlePlay(IChannelHandlerContext context, string packetBody)
    {
        GamePacket resPacket = new GamePacket(E_PACKET_TYPE.RES_ENTER_BATTLE_PLAY);
        ResEnterBattlePlay resEnterBattlePlay = new ResEnterBattlePlay();

        if (string.IsNullOrEmpty(packetBody))
        {
            resEnterBattlePlay.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resEnterBattlePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        ReqEnterBattlePlay reqEnterBattlePlay = EncUtil.DecodeBase64<ReqEnterBattlePlay>(packetBody);
        if (reqEnterBattlePlay == null)
        {
            resEnterBattlePlay.ResponseCode = E_RESPONSE_CODE.FAIL_DESERIALIZE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resEnterBattlePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        if (reqEnterBattlePlay.CharacterId == 0)
        {
            resEnterBattlePlay.ResponseCode = E_RESPONSE_CODE.REQ_PARAM_INVALID_CHARACTER_ID;
            resPacket.PacketBody = EncUtil.EncodeBase64(resEnterBattlePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        if (!TableManager.CharBasicMetaData.DicData.ContainsKey(reqEnterBattlePlay.CharacterId))
        {
            resEnterBattlePlay.ResponseCode = E_RESPONSE_CODE.INVALID_DATA_TABLE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resEnterBattlePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }
        CharBasicDT charBasicData = TableManager.CharBasicMetaData.DicData[reqEnterBattlePlay.CharacterId];

        long accountId = context.Channel.GetAttrAccountId();
        if (accountId == 0)
        {
            resEnterBattlePlay.ResponseCode = E_RESPONSE_CODE.INVALID_CHANNEL_ATTR;
            resPacket.PacketBody = EncUtil.EncodeBase64(resEnterBattlePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // userinfo check 
        if (_UserDB.TryGetValue(accountId, out var userInfo) == false)
        {
            resEnterBattlePlay.ResponseCode = E_RESPONSE_CODE.NOT_EXIST_USER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resEnterBattlePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // session check
        E_RESPONSE_CODE sessionResult = _CheckSession(accountId, reqEnterBattlePlay.Token);
        if (sessionResult != E_RESPONSE_CODE.SUCCESS)
        {
            resEnterBattlePlay.ResponseCode = sessionResult;
            resPacket.PacketBody = EncUtil.EncodeBase64(resEnterBattlePlay);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // UserInfo.Character 생성
        CharacterInfo character = new CharacterInfo
        {
            CharacterId = reqEnterBattlePlay.CharacterId,
            LP = 100
        };
        _UserDB[accountId].Character = character;

        // 응답
        resEnterBattlePlay = new ResEnterBattlePlay
        {
            ResponseCode = E_RESPONSE_CODE.SUCCESS,
            Character = character,
            WaitingList = _battleWaitingDB.Values.ToList()
        };

        resPacket.PacketBody = EncUtil.EncodeBase64(resEnterBattlePlay);
        ChannelManager.SendToUser(accountId, resPacket);
    }

    /// <summary>
    ///  대기방 생성
    /// </summary>
    private void _ReqCreateBattleRoom(IChannelHandlerContext context, string packetBody)
    {
        GamePacket resPacket = new GamePacket(E_PACKET_TYPE.RES_CREATE_BATTLE_ROOM);
        ResCreateBattleRoom resCreateBattleRoom = new ResCreateBattleRoom();

        if (string.IsNullOrEmpty(packetBody))
        {
            resCreateBattleRoom.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resCreateBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        ReqCreateBattleRoom reqCreateBattleRoom = EncUtil.DecodeBase64<ReqCreateBattleRoom>(packetBody);
        if (reqCreateBattleRoom == null)
        {
            resCreateBattleRoom.ResponseCode = E_RESPONSE_CODE.FAIL_DESERIALIZE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resCreateBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        if (reqCreateBattleRoom.CharacterId == 0)
        {
            resCreateBattleRoom.ResponseCode = E_RESPONSE_CODE.REQ_PARAM_INVALID_CHARACTER_ID;
            resPacket.PacketBody = EncUtil.EncodeBase64(resCreateBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        if (!TableManager.CharBasicMetaData.DicData.ContainsKey(reqCreateBattleRoom.CharacterId))
        {
            resCreateBattleRoom.ResponseCode = E_RESPONSE_CODE.INVALID_DATA_TABLE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resCreateBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }
        CharBasicDT charBasicData = TableManager.CharBasicMetaData.DicData[reqCreateBattleRoom.CharacterId];

        long accountId = context.Channel.GetAttrAccountId();
        int serverId = context.Channel.GetAttrServerId();
        if (accountId == 0 || serverId == 0)
        {
            resCreateBattleRoom.ResponseCode = E_RESPONSE_CODE.INVALID_CHANNEL_ATTR;
            resPacket.PacketBody = EncUtil.EncodeBase64(resCreateBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // session check
        E_RESPONSE_CODE sessionResult = _CheckSession(accountId, reqCreateBattleRoom.Token);
        if (sessionResult != E_RESPONSE_CODE.SUCCESS)
        {
            resCreateBattleRoom.ResponseCode = sessionResult;
            resPacket.PacketBody = EncUtil.EncodeBase64(resCreateBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // UserInfo check
        if (_UserDB.TryGetValue(accountId, out var userInfo) == false)
        {
            resCreateBattleRoom.ResponseCode = E_RESPONSE_CODE.NOT_EXIST_USER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resCreateBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        if (_battleWaitingDB.ContainsKey(accountId))
        {
            resCreateBattleRoom.ResponseCode = E_RESPONSE_CODE.ALREADY_EXIST_ROOM;
            resPacket.PacketBody = EncUtil.EncodeBase64(resCreateBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        var newWaitting = userInfo.Clone();
        _battleWaitingDB.Add(accountId, newWaitting);

        resCreateBattleRoom = new ResCreateBattleRoom
        {
            ResponseCode = E_RESPONSE_CODE.SUCCESS,
            WaitingUser = newWaitting
        };

        resPacket.PacketBody = EncUtil.EncodeBase64(resCreateBattleRoom);
        ChannelManager.SendToUser(accountId, resPacket);

        // publish
        _MessagePublish(
            E_BROADCAST_TYPE.SERVER, serverId,
            E_PACKET_TYPE.PS_CREATE_BATTLE_ROOM, resPacket
            );
    }

    /// <summary>
    ///  대기종료
    /// </summary>
    private void _ReqExitBattleRoom(IChannelHandlerContext context, string packetBody)
    {
        GamePacket resPacket = new GamePacket(E_PACKET_TYPE.RES_EXIT_BATTLE_ROOM);
        ResExitBattleRoom resExitBattleRoom = new ResExitBattleRoom();

        if (string.IsNullOrEmpty(packetBody))
        {
            resExitBattleRoom.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        ReqExitBattleRoom reqExitBattleRoom = EncUtil.DecodeBase64<ReqExitBattleRoom>(packetBody);
        if (reqExitBattleRoom == null)
        {
            resExitBattleRoom.ResponseCode = E_RESPONSE_CODE.FAIL_DESERIALIZE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        long accountId = context.Channel.GetAttrAccountId();
        int serverId = context.Channel.GetAttrServerId();
        if (accountId == 0 || serverId == 0)
        {
            resExitBattleRoom.ResponseCode = E_RESPONSE_CODE.INVALID_CHANNEL_ATTR;
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // session check
        E_RESPONSE_CODE sessionResult = _CheckSession(accountId, reqExitBattleRoom.Token);
        if (sessionResult != E_RESPONSE_CODE.SUCCESS)
        {
            resExitBattleRoom.ResponseCode = sessionResult;
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        UserInfo waitingUser = null;
        if (_battleWaitingDB.ContainsKey(accountId))
        {
            waitingUser = _battleWaitingDB[accountId];
            _battleWaitingDB.Remove(accountId);
        }

        resExitBattleRoom = new ResExitBattleRoom
        {
            ResponseCode = E_RESPONSE_CODE.SUCCESS,
            WaitingUser = waitingUser
        };

        resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleRoom);
        ChannelManager.SendToUser(accountId, resPacket);

        // publish
        _MessagePublish(
            E_BROADCAST_TYPE.SERVER, serverId,
            E_PACKET_TYPE.PS_EXIT_BATTLE_ROOM, resPacket
            );
    }

    /// <summary>
    ///  대전시작
    /// </summary>
    private void _ReqJoinBattleRoom(IChannelHandlerContext context, string packetBody)
    {
        GamePacket resPacket = new GamePacket(E_PACKET_TYPE.RES_JOIN_BATTLE_ROOM);
        ResJoinBattleRoom resJoinBattleRoom = new ResJoinBattleRoom();

        if (string.IsNullOrEmpty(packetBody))
        {
            resJoinBattleRoom.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resJoinBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        ReqJoinBattleRoom reqJoinBattleRoom = EncUtil.DecodeBase64<ReqJoinBattleRoom>(packetBody);
        if (reqJoinBattleRoom == null)
        {
            resJoinBattleRoom.ResponseCode = E_RESPONSE_CODE.FAIL_DESERIALIZE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resJoinBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        if (reqJoinBattleRoom.OpponentCharacterId == 0)
        {
            resJoinBattleRoom.ResponseCode = E_RESPONSE_CODE.REQ_PARAM_INVALID_CHARACTER_ID;
            resPacket.PacketBody = EncUtil.EncodeBase64(resJoinBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        if (!TableManager.CharBasicMetaData.DicData.ContainsKey(reqJoinBattleRoom.OpponentCharacterId))
        {
            resJoinBattleRoom.ResponseCode = E_RESPONSE_CODE.INVALID_DATA_TABLE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resJoinBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }
        CharBasicDT charBasicData = TableManager.CharBasicMetaData.DicData[reqJoinBattleRoom.OpponentCharacterId];

        long accountId = context.Channel.GetAttrAccountId();
        int serverId = context.Channel.GetAttrServerId();
        if (accountId == 0 || serverId == 0)
        {
            resJoinBattleRoom.ResponseCode = E_RESPONSE_CODE.INVALID_CHANNEL_ATTR;
            resPacket.PacketBody = EncUtil.EncodeBase64(resJoinBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // session check
        E_RESPONSE_CODE sessionResult = _CheckSession(accountId, reqJoinBattleRoom.Token);
        if (sessionResult != E_RESPONSE_CODE.SUCCESS)
        {
            resJoinBattleRoom.ResponseCode = sessionResult;
            resPacket.PacketBody = EncUtil.EncodeBase64(resJoinBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        if (reqJoinBattleRoom.HostAccountId <= 0 ||
            reqJoinBattleRoom.OpponentAccountId <= 0 ||
            reqJoinBattleRoom.HostAccountId == reqJoinBattleRoom.OpponentAccountId)
        {
            resJoinBattleRoom.ResponseCode = E_RESPONSE_CODE.REQ_PARAM_INVALID_ACCOUNT_ID;
            resPacket.PacketBody = EncUtil.EncodeBase64(resJoinBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        var battleInfo = _InitBattleGame(reqJoinBattleRoom.HostAccountId, reqJoinBattleRoom.OpponentAccountId);
        if (battleInfo == null)
        {
            resJoinBattleRoom.ResponseCode = E_RESPONSE_CODE.ALREADY_PLAYING_BATTLE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resJoinBattleRoom);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        long subscribeAccountId = reqJoinBattleRoom.HostAccountId;
        if (accountId == reqJoinBattleRoom.HostAccountId)
        {
            subscribeAccountId = reqJoinBattleRoom.OpponentAccountId;
        }

        // 게임이 시작됐으므로 대기목록에서 삭제
        ResExitBattleRoom resExitBattleRoom = null;
        if (_battleWaitingDB.ContainsKey(reqJoinBattleRoom.HostAccountId))
        {
            UserInfo waitingUser = _battleWaitingDB[reqJoinBattleRoom.HostAccountId];
            resExitBattleRoom = new ResExitBattleRoom
            {
                ResponseCode = E_RESPONSE_CODE.SUCCESS,
                WaitingUser = waitingUser
            };

            _battleWaitingDB.Remove(reqJoinBattleRoom.HostAccountId);
        }

        resJoinBattleRoom = new ResJoinBattleRoom
        {
            ResponseCode = E_RESPONSE_CODE.SUCCESS,
            BattleInfo = battleInfo,
        };

        resPacket.PacketBody = EncUtil.EncodeBase64(resJoinBattleRoom);
        ChannelManager.SendToUser(accountId, resPacket);

        // publish (대전시작)
        _MessagePublish(
            E_BROADCAST_TYPE.USER, subscribeAccountId,
            E_PACKET_TYPE.RES_JOIN_BATTLE_ROOM, resPacket
            );

        // publish (대기방삭제)
        if (resExitBattleRoom != null)
        {
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleRoom);

            _MessagePublish(
                E_BROADCAST_TYPE.SERVER, serverId,
                E_PACKET_TYPE.PS_EXIT_BATTLE_ROOM, resPacket
                );
        }
    }

    /// <summary>
    ///  대전 플레이 캐릭터이동
    /// </summary>
    private void _ReqMoveBattleCharacter(IChannelHandlerContext context, string packetBody)
    {
        GamePacket resPacket = new GamePacket(E_PACKET_TYPE.RES_MOVE_BATTLE_CHARACTER);
        ResMoveBattleCharacter resMoveBattleCharacter = new ResMoveBattleCharacter();

        if (string.IsNullOrEmpty(packetBody))
        {
            resMoveBattleCharacter.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resMoveBattleCharacter);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        ReqMoveBattleCharacter reqMoveBattleCharacter = EncUtil.DecodeBase64<ReqMoveBattleCharacter>(packetBody);
        if (reqMoveBattleCharacter == null)
        {
            resMoveBattleCharacter.ResponseCode = E_RESPONSE_CODE.FAIL_DESERIALIZE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resMoveBattleCharacter);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        if (reqMoveBattleCharacter.BattleId == 0)
        {
            resMoveBattleCharacter.ResponseCode = E_RESPONSE_CODE.REQ_PARAM_INVALID_BATTLE_ID;
            resPacket.PacketBody = EncUtil.EncodeBase64(resMoveBattleCharacter);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        if (reqMoveBattleCharacter.DestCoordR < 0
            || reqMoveBattleCharacter.DestCoordR >= Constants.BOARD_SCALE_H
            || reqMoveBattleCharacter.DestCoordC < 0
            || reqMoveBattleCharacter.DestCoordC >= Constants.BOARD_SCALE_W
            )
        {
            resMoveBattleCharacter.ResponseCode = E_RESPONSE_CODE.REQ_PARAM_INVALID_DEST_COORD;
            resPacket.PacketBody = EncUtil.EncodeBase64(resMoveBattleCharacter);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        if (!_battleGameDB.ContainsKey(reqMoveBattleCharacter.BattleId))
        {
            resMoveBattleCharacter.ResponseCode = E_RESPONSE_CODE.NOT_PLAYING;
            resPacket.PacketBody = EncUtil.EncodeBase64(resMoveBattleCharacter);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        long accountId = context.Channel.GetAttrAccountId();
        if (accountId == 0)
        {
            resMoveBattleCharacter.ResponseCode = E_RESPONSE_CODE.INVALID_CHANNEL_ATTR;
            resPacket.PacketBody = EncUtil.EncodeBase64(resMoveBattleCharacter);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // session check
        E_RESPONSE_CODE sessionResult = _CheckSession(accountId, reqMoveBattleCharacter.Token);
        if (sessionResult != E_RESPONSE_CODE.SUCCESS)
        {
            resMoveBattleCharacter.ResponseCode = sessionResult;
            resPacket.PacketBody = EncUtil.EncodeBase64(resMoveBattleCharacter);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        var battleInfo = _battleGameDB[reqMoveBattleCharacter.BattleId];
        if (battleInfo.LastPlayAccountId == accountId)
        {
            resMoveBattleCharacter.ResponseCode = E_RESPONSE_CODE.NOT_MY_TURN;
            resPacket.PacketBody = EncUtil.EncodeBase64(resMoveBattleCharacter);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        var myEntry = battleInfo.BattleEntryList
            .FirstOrDefault(x => x.AccountId == accountId);
        var targetEntry = battleInfo.BattleEntryList
            .FirstOrDefault(x => x.AccountId != accountId);

        List<(int, int)> areaList = BattleHelper.GetAvailableArea(myEntry);
        if (!areaList.Contains((reqMoveBattleCharacter.DestCoordR, reqMoveBattleCharacter.DestCoordC)))
        {
            resMoveBattleCharacter.ResponseCode = E_RESPONSE_CODE.INVALID_DEST;
            resPacket.PacketBody = EncUtil.EncodeBase64(resMoveBattleCharacter);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        if ((reqMoveBattleCharacter.DestCoordR == myEntry.CoordR
                && reqMoveBattleCharacter.DestCoordC == myEntry.CoordC)
            || (reqMoveBattleCharacter.DestCoordR == targetEntry.CoordR
                && reqMoveBattleCharacter.DestCoordC == targetEntry.CoordC)
            )
        {
            resMoveBattleCharacter.ResponseCode = E_RESPONSE_CODE.INVALID_DEST;
            resPacket.PacketBody = EncUtil.EncodeBase64(resMoveBattleCharacter);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        myEntry.CoordR = reqMoveBattleCharacter.DestCoordR;
        myEntry.CoordC = reqMoveBattleCharacter.DestCoordC;
        battleInfo.LastPlayAccountId = accountId;

        long subscribeAccountId = targetEntry.AccountId;

        resMoveBattleCharacter.ResponseCode = E_RESPONSE_CODE.SUCCESS;
        resMoveBattleCharacter.BattleInfo = battleInfo;

        resPacket.PacketBody = EncUtil.EncodeBase64(resMoveBattleCharacter);
        ChannelManager.SendToUser(accountId, resPacket);

        // publish
        _MessagePublish(
            E_BROADCAST_TYPE.USER, subscribeAccountId,
            E_PACKET_TYPE.PS_MOVE_BATTLE_CHARACTER, resPacket
            );
    }

    /// <summary>
    ///  대전 플레이 캐릭터공격
    /// </summary>
    private void _ReqAttackBattleCharacter(IChannelHandlerContext context, string packetBody)
    {
        GamePacket resPacket = new GamePacket(E_PACKET_TYPE.RES_ATTACK_BATTLE_CHARACTER);
        ResAttackBattleCharacter resAttackBattleCharacter = new ResAttackBattleCharacter();

        if (string.IsNullOrEmpty(packetBody))
        {
            resAttackBattleCharacter.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resAttackBattleCharacter);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        ReqAttackBattleCharacter reqAttackBattleCharacter = EncUtil.DecodeBase64<ReqAttackBattleCharacter>(packetBody);
        if (reqAttackBattleCharacter == null)
        {
            resAttackBattleCharacter.ResponseCode = E_RESPONSE_CODE.FAIL_DESERIALIZE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resAttackBattleCharacter);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        if (reqAttackBattleCharacter.BattleId == 0)
        {
            resAttackBattleCharacter.ResponseCode = E_RESPONSE_CODE.REQ_PARAM_INVALID_BATTLE_ID;
            resPacket.PacketBody = EncUtil.EncodeBase64(resAttackBattleCharacter);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        if (!_battleGameDB.ContainsKey(reqAttackBattleCharacter.BattleId))
        {
            resAttackBattleCharacter.ResponseCode = E_RESPONSE_CODE.NOT_PLAYING;
            resPacket.PacketBody = EncUtil.EncodeBase64(resAttackBattleCharacter);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        long accountId = context.Channel.GetAttrAccountId();
        if (accountId == 0)
        {
            resAttackBattleCharacter.ResponseCode = E_RESPONSE_CODE.INVALID_CHANNEL_ATTR;
            resPacket.PacketBody = EncUtil.EncodeBase64(resAttackBattleCharacter);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // session check
        E_RESPONSE_CODE sessionResult = _CheckSession(accountId, reqAttackBattleCharacter.Token);
        if (sessionResult != E_RESPONSE_CODE.SUCCESS)
        {
            resAttackBattleCharacter.ResponseCode = sessionResult;
            resPacket.PacketBody = EncUtil.EncodeBase64(resAttackBattleCharacter);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        var battleInfo = _battleGameDB[reqAttackBattleCharacter.BattleId];
        if (battleInfo.LastPlayAccountId == accountId)
        {
            resAttackBattleCharacter.ResponseCode = E_RESPONSE_CODE.NOT_MY_TURN;
            resPacket.PacketBody = EncUtil.EncodeBase64(resAttackBattleCharacter);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        var myEntry = battleInfo.BattleEntryList
            .FirstOrDefault(x => x.AccountId == accountId);
        var targetEntry = battleInfo.BattleEntryList
            .FirstOrDefault(x => x.AccountId != accountId);

        List<(int, int)> areaList = BattleHelper.GetAvailableArea(myEntry);
        if (!areaList.Contains((targetEntry.CoordR, targetEntry.CoordC)))
        {
            resAttackBattleCharacter.ResponseCode = E_RESPONSE_CODE.INVALID_DEST;
            resPacket.PacketBody = EncUtil.EncodeBase64(resAttackBattleCharacter);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        var myCharBasicDt = DataTableHelper.GetCharacter(myEntry.CharacterId);
        if (myCharBasicDt == null)
        {
            resAttackBattleCharacter.ResponseCode = E_RESPONSE_CODE.INVALID_DATA_TABLE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resAttackBattleCharacter);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        if (targetEntry.BattleLp == 0)
        {
            resAttackBattleCharacter.ResponseCode = E_RESPONSE_CODE.NOT_ENOUGH_BATTLE_LP;
            resPacket.PacketBody = EncUtil.EncodeBase64(resAttackBattleCharacter);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        //if (_UserDB.TryGetValue(targetEntry.AccountId, out var targetUserInfo) == false)
        //{
        //    resAttackBattleCharacter.ResponseCode = E_RESPONSE_CODE.NOT_EXIST_USER;
        //    resPacket.PacketBody = EncUtil.EncodeBase64(resAttackBattleCharacter);
        //    context.Channel.WriteAndFlushAsync(resPacket);
        //    return;
        //}

        // Battle LP 차감
        int hp = myCharBasicDt.HP;
        int battleLp = targetEntry.BattleLp - hp;
        if (battleLp < 0)
        {
            battleLp = 0;
            hp = targetEntry.BattleLp;
        }

        // LP 차감
        int lp = targetEntry.LP - hp;
        if (lp < 0)
        {
            lp = 0;
        }

        // 대전결과
        var battleResult = E_BATTLE_RESULT.NORMAL;
        if (battleLp == 0)
        {
            battleResult = E_BATTLE_RESULT.GAME_OVER;
        }

        targetEntry.LP = lp;
        targetEntry.BattleLp = battleLp;
        battleInfo.LastPlayAccountId = accountId;

        _UserDB[targetEntry.AccountId].Character.LP = lp;

        long subscribeAccountId = targetEntry.AccountId;

        resAttackBattleCharacter.ResponseCode = E_RESPONSE_CODE.SUCCESS;
        resAttackBattleCharacter.BattleResult = battleResult;
        resAttackBattleCharacter.BattleInfo = battleInfo;

        resPacket.PacketBody = EncUtil.EncodeBase64(resAttackBattleCharacter);
        ChannelManager.SendToUser(accountId, resPacket);

        // publish
        _MessagePublish(
            E_BROADCAST_TYPE.USER, subscribeAccountId,
            E_PACKET_TYPE.PS_ATTACK_BATTLE_CHARACTER, resPacket
            );
    }

    /// <summary>
    ///  대전 플레이 중지
    /// </summary>
    private void _ReqExitBattleJoin(IChannelHandlerContext context, string packetBody)
    {
        GamePacket resPacket = new GamePacket(E_PACKET_TYPE.RES_EXIT_BATTLE_JOIN);
        ResExitBattleJoin resExitBattleJoin = new ResExitBattleJoin();
        long subscribeAccountId = 0;

        if (string.IsNullOrEmpty(packetBody))
        {
            resExitBattleJoin.ResponseCode = E_RESPONSE_CODE.INVALID_PARAMETER;
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleJoin);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        ReqExitBattleJoin reqExitBattleJoin = EncUtil.DecodeBase64<ReqExitBattleJoin>(packetBody);
        if (reqExitBattleJoin == null)
        {
            resExitBattleJoin.ResponseCode = E_RESPONSE_CODE.FAIL_DESERIALIZE;
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleJoin);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        if (reqExitBattleJoin.BattleId == 0)
        {
            resExitBattleJoin.ResponseCode = E_RESPONSE_CODE.REQ_PARAM_INVALID_BATTLE_ID;
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleJoin);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        long accountId = context.Channel.GetAttrAccountId();
        if (accountId == 0)
        {
            resExitBattleJoin.ResponseCode = E_RESPONSE_CODE.INVALID_CHANNEL_ATTR;
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleJoin);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // session check
        E_RESPONSE_CODE sessionResult = _CheckSession(accountId, reqExitBattleJoin.Token);
        if (sessionResult != E_RESPONSE_CODE.SUCCESS)
        {
            resExitBattleJoin.ResponseCode = sessionResult;
            resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleJoin);
            context.Channel.WriteAndFlushAsync(resPacket);
            return;
        }

        // 대전정보 삭제
        if (_battleGameDB.ContainsKey(reqExitBattleJoin.BattleId))
        {
            subscribeAccountId = _battleGameDB[reqExitBattleJoin.BattleId].BattleEntryList.FirstOrDefault(d => d.AccountId != accountId).AccountId;
            _battleGameDB.Remove(reqExitBattleJoin.BattleId);
        }

        resExitBattleJoin = new ResExitBattleJoin
        {
            ResponseCode = E_RESPONSE_CODE.SUCCESS
        };

        resPacket.PacketBody = EncUtil.EncodeBase64(resExitBattleJoin);
        ChannelManager.SendToUser(accountId, resPacket);

        // publish
        if (subscribeAccountId > 0)
        {
            _MessagePublish(
                E_BROADCAST_TYPE.USER, subscribeAccountId,
                E_PACKET_TYPE.PS_EXIT_BATTLE_JOIN, resPacket
                );
        }
    }
    #endregion

    #region For Packet Encoder/Decoder TEST
    private void _ReqDataTest(IChannelHandlerContext context, string packetBody)
    {
        GamePacket resPacket = new GamePacket(E_PACKET_TYPE.RES_DATA_TEST);
        resPacket.PacketBody = packetBody;
        context.WriteAndFlushAsync(resPacket);
    }
    #endregion
}