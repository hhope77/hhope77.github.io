﻿using CheckerboardLib.Db;
using CheckerboardLib.Log.ConsoleLog;
using CheckerboardLib.SRedis;
using CheckerboardServer.Handlers;
using DotNetty.Handlers.Logging;
using DotNetty.Handlers.Tls;
using DotNetty.Transport.Bootstrapping;
using DotNetty.Transport.Channels;
using DotNetty.Transport.Channels.Sockets;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Snowpipe;
using System.Security.Cryptography.X509Certificates;

namespace CheckerboardServer
{
    internal class Program
    {
        static async Task RunServerAsync()
        {
            CLogManager.SetConsoleLogger();
            ConfigHelper.Load();

            var services = new ServiceCollection();

            // Add services to the container.
            services.AddSingleton<IServiceProvider>(services.BuildServiceProvider());

            //Add database context
            services.AddSingleton<AccountDbContext>();
            services
                .AddDbContextFactory<AccountDbContext>(options =>
                    options.UseSqlServer(ConfigHelper.Configuration["ConnectionStrings:AccountConnection"])
                    .EnableSensitiveDataLogging()
                    .EnableDetailedErrors());

            // Add redis
            services
                .AddSingleton<SessionRedisContext>(option =>
                    new SessionRedisContext(ConfigHelper.Configuration["ConnectionStrings:GameRedisDB"]))
                .AddSingleton<PubsubRedisContext>(option =>
                    new PubsubRedisContext(ConfigHelper.Configuration["ConnectionStrings:PubSubRedisDB"]));

            ////Set ignore CustomDateTime
            //Common.ServerDateTime.SetIgnoreCustomDateTime(app.Environment.IsProduction());

            //// min thread Set
            //var minWorkerThreadCount = Environment.ProcessorCount * Snowpipe.Constants.CREATE_THREAD_PER_PROCESSOR;
            //ThreadPool.GetMaxThreads(out int workerthread, out int completion);
            //if (ThreadPool.SetMinThreads(minWorkerThreadCount, completion) == true)
            //{
            //    app.Logger.LogInformation($"Set Min thread Success");
            //    app.Logger.LogInformation($"MinWorkerThreadCount[{minWorkerThreadCount}], CompletionPortCount[{completion}]");
            //}
            //else
            //{
            //    app.Logger.LogInformation($"Set Min thread Falied");
            //}

            // load datatable
            TableManager.Load();

            var serviceProvider = services.BuildServiceProvider();

            var bossGroup = new MultithreadEventLoopGroup(1);   // accepts an incoming connection, eventLoopCount 숫자만큼 스레드가 생성된다
            var workerGroup = new MultithreadEventLoopGroup();  // 공백으로 하면 CPU 코어수 * 2 만큼의 스레드가 자동 할당됨

            var packetEncoder = new PacketEncoder();
            var packtDecoder = new PacketDecoder();
            var serverHandler = new ServerPacketHandler(serviceProvider);

            X509Certificate2 tlsCertificate = null;
            if (ConfigHelper.IsSSL)
            {
                tlsCertificate = new X509Certificate2(Path.Combine(ConfigHelper.ProcessDirectory, "snowpipe.com.pfx"), "password");
            }

            try
            {
                ServerBootstrap bootstrap = new ServerBootstrap();
                bootstrap
                .Group(bossGroup, workerGroup)
                    .Channel<TcpServerSocketChannel>()
                    .Option(ChannelOption.SoBacklog, 100)
                    .Handler(new LoggingHandler(LogLevel.INFO))
                    .ChildHandler(new ActionChannelInitializer<ISocketChannel>(channel =>
                    {
                        IChannelPipeline pipeline = channel.Pipeline;

                        if (tlsCertificate != null)
                        {
                            pipeline.AddLast(TlsHandler.Server(tlsCertificate));
                        }

                        pipeline.AddLast("encoder", packetEncoder);
                        pipeline.AddLast("decoder", packtDecoder);
                        pipeline.AddLast("handler", serverHandler);
                    }));

                IChannel bootstrapChannel = await bootstrap.BindAsync(ConfigHelper.ServerIPAddress, ConfigHelper.ServerPort);
                var pubsubHandler = new PubSubHandler(serviceProvider);
                pubsubHandler.StartSubscribe();

                Console.WriteLine($"********** Started Game Server... {ConfigHelper.ServerIPAddress}:{ConfigHelper.ServerPort} **********");
                Console.ReadLine();

                await bootstrapChannel.CloseAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"!!!!!!!!!! Fail To Start Game Server... {ConfigHelper.ServerIPAddress}:{ConfigHelper.ServerPort} !!!!!!!!!!");
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                Task.WaitAll(bossGroup.ShutdownGracefullyAsync(), workerGroup.ShutdownGracefullyAsync());
            }
        }

        static void Main(string[] args) => RunServerAsync().Wait();
    }
}