﻿CREATE PROCEDURE [dbo].[usp_select_account_by_id]
    @account_id BIGINT
AS
    SET NOCOUNT ON;

    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

    SELECT a.[id], a.[nickname], a.[level], a.[reg_dt]
      FROM dbo.account AS a
     WHERE a.[id] = @account_id;
RETURN 0